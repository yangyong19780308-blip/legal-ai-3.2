/* 全量覆盖检查：哪些官方要素行在当前映射规则下"无规则可用"（既无关键词映射，也无默认值） */
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, 'src');
const app3 = fs.readFileSync(path.join(src, 'app3.js'), 'utf8');
const layoutsSrc = fs.readFileSync(path.join(src, 'official_layouts.js'), 'utf8');
const sandbox = {
  console: { log: () => {} },
  escHtml: s => String(s == null ? '' : s),
  currentDraft: { mode: 'complaint' },
  normalizeCaseType: s => String(s || ''),
  docTypeForMode: () => 'complaint',
  findTemplate: () => null
};
const api = new Function('sandbox', 'with (sandbox) { ' + layoutsSrc + '\n' + app3 +
  '\n return { OFFICIAL_LAYOUTS, elemNormKey, elemPartySide, elemDefaultForRow, ELEM_ROW_FACT_HINTS, elemRowValueFromClaims, elemRowValueFromFacts, elemRowValueGeneric, elemKeywords, fillLayoutContent, isLayoutCategoryHeader }; }')(sandbox);

const onlyComplaint = !process.argv.includes('--all');
const rows = [];
Object.keys(api.OFFICIAL_LAYOUTS).forEach(key => {
  const label = key.split('|')[1] || '';
  if (onlyComplaint && !/起诉状$/.test(label)) return;
  (api.OFFICIAL_LAYOUTS[key] || []).forEach(r => {
    if (r[0] !== 'r') return;
    const lab = String(r[1] || '');
    const n = api.elemNormKey(lab);
    const content = String(r[2] || '');
    if (api.elemPartySide(lab)) return;
    if (n === '案号' || n === '案由') return;
    if (/依据/.test(n) || /证据清单/.test(n) || /标的总额/.test(n) || /签订主体|合同主体/.test(n)) return;
    if (api.isLayoutCategoryHeader(String(r[1] || '').replace(/\n/g, ''))) return;
    // 模拟"素材里确实提到了这一项"：用行标题关键词造一条事实，看这一行能不能被填上
    const kw = api.elemKeywords(lab).join('、');
    const synth = kw + '：本案相关情况为张三与李四之间发生的事项，涉及金额10000元，时间2024年1月1日，已由双方确认。';
    const data = {
      caseType: key.split('|')[0], plaintiff: { name: '张三' }, defendant: { name: '李四' },
      claims: [synth], facts: [{ label: kw, content: synth }], evidence: [kw + '（证据材料）'], elements: null
    };
    const filledRow = api.fillLayoutContent(lab, content, data, null);
    const changed = filledRow !== content;
    if (process.env.DBG_LABEL && lab.replace(/\n/g, '').indexOf(process.env.DBG_LABEL) >= 0) {
      console.log('[dbg] ' + key + ' | ' + lab.replace(/\n/g, '') +
        '\n   content=' + JSON.stringify(content) +
        '\n   fact=' + api.elemRowValueFromFacts(lab, data) +
        '\n   claim=' + api.elemRowValueFromClaims(lab, data) +
        '\n   generic=' + String(api.elemRowValueGeneric(lab, data)).slice(0, 40) +
        '\n   default=' + api.elemDefaultForRow(lab, data) +
        '\n   out=' + JSON.stringify(filledRow));
    }
    if (!changed) rows.push([key, lab.replace(/\n/g, '')]);
  });
});
const byCase = {};
rows.forEach(([k, lab]) => { byCase[k] = byCase[k] || []; byCase[k].push(lab); });
Object.keys(byCase).sort().forEach(k => console.log(k + ' → ' + byCase[k].join('、')));
console.log('\n即使素材提到也填不上的行合计：' + rows.length);
