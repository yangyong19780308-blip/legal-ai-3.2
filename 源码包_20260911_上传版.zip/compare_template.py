"""把官方模板 docx 与网页渲染结果做逐行结构比对，检查是否与官方模板一致。"""
import re
import sys
from html.parser import HTMLParser

from docx import Document


def norm(s):
    s = str(s or '')
    s = re.sub(r'[\s\u00a0\u23ce]+', '', s)
    s = re.sub(r'[，。、；：:（）()【】\[\]\/\\·\-—]', '', s)
    return s.lower()


def official_rows(path):
    doc = Document(path)
    rows = []
    for tbl in doc.tables:
        for row in tbl.rows:
            cells = []
            seen = set()
            for c in row.cells:
                if c._tc in seen:
                    continue
                seen.add(c._tc)
                cells.append(c.text)
            if not cells:
                continue
            label = cells[0]
            content = cells[1] if len(cells) > 1 else ''
            rows.append((label, content))
    # 合并同一行被分页拆开的重复标签行
    return rows


class TableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self.cur = None
        self.cell = None
        self.depth = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'tr':
            self.cur = {'cls': a.get('class', ''), 'cells': []}
        elif tag in ('td', 'th') and self.cur is not None:
            self.cell = {'cls': a.get('class', ''), 'colspan': a.get('colspan'), 'text': ''}
        elif tag == 'br' and self.cell is not None:
            self.cell['text'] += '\n'

    def handle_endtag(self, tag):
        if tag in ('td', 'th') and self.cell is not None:
            self.cur['cells'].append(self.cell)
            self.cell = None
        elif tag == 'tr' and self.cur is not None:
            self.rows.append(self.cur)
            self.cur = None

    def handle_data(self, data):
        if self.cell is not None:
            self.cell['text'] += data


def html_rows(path):
    src = open(path, encoding='utf-8').read()
    p = TableParser()
    p.feed(src)
    rows = []
    for r in p.rows:
        cs = r['cells']
        if len(cs) >= 2 and 'lab' in cs[0]['cls']:
            rows.append((cs[0]['text'], cs[1]['text']))
        elif cs:
            rows.append((cs[0]['text'], ''))
    return rows


def boxes(s):
    return len(re.findall(r'□', s))


def main():
    docx_path, html_path = sys.argv[1], sys.argv[2]
    off = official_rows(docx_path)
    ours = html_rows(html_path)

    off_labels = [norm(l) for l, _ in off if norm(l)]
    our_labels = [norm(l) for l, _ in ours if norm(l)]

    print('官方行数 {0}，渲染行数 {1}'.format(len(off_labels), len(our_labels)))
    missing = []
    for i, lab in enumerate(off_labels):
        if not any(lab and (lab in o or o in lab) for o in our_labels):
            missing.append(off[i][0].replace('\n', ''))
    print('官方有、渲染缺失的行 {0} 个：{1}'.format(len(missing), '、'.join(missing[:20])))

    # 选项框数量对比（模板完整度：勾选项是否都在）
    off_boxes = sum(boxes(c) for _, c in off)
    our_boxes = sum(boxes(c) for _, c in ours)
    print('勾选框数量：官方 {0}，渲染 {1}'.format(off_boxes, our_boxes))

    # 逐行：渲染结果是否包含官方该行文字骨架
    mismatch = []
    for lab, content in off:
        nl = norm(lab)
        if not nl:
            continue
        cand = [(l, c) for l, c in ours if nl and (nl in norm(l) or norm(l) in nl)]
        if not cand:
            continue
        _, our = cand[0]
        core = norm(content)
        if core and len(core) > 6:
            keep = sum(1 for ch in set(core) if ch in norm(our)) / max(1, len(set(core)))
            if keep < 0.8:
                mismatch.append((lab.replace('\n', ''), round(keep, 2)))
    print('行文字骨架保留不足 80% 的行 {0} 个：{1}'.format(len(mismatch), mismatch[:10]))

    # 逐行勾选框对比
    print('--- 逐行勾选框对比（只列不一致） ---')
    diff_rows = 0
    for lab, content in off:
        nl = norm(lab)
        if not nl:
            continue
        cand = [(l, c) for l, c in ours if nl in norm(l) or norm(l) in nl]
        if not cand:
            continue
        _, our = cand[0]
        ob, mb = boxes(content), boxes(our)
        # 渲染时勾选会把 □ 变成 ☑，所以渲染的 □ 只会更少；多了说明模板项被重复
        if mb > ob:
            diff_rows += 1
            print('  {0}: 官方□{1} 渲染□{2}'.format(lab.replace('\n', '')[:24].ljust(24), ob, mb))
    if not diff_rows:
        print('  全部一致（渲染勾选框不多于官方模板）')


if __name__ == '__main__':
    main()
