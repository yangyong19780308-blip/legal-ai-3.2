/* 校验导出的 Word(.doc) 版式：列宽比例、字体、是否有溢出 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const FILE = process.argv[2];
if (!FILE) { console.error('用法: node verify_doc.js <导出的.doc 路径>'); process.exit(1); }
const PORT = 9433;
const PROFILE = fs.mkdtempSync(path.join(os.tmpdir(), 'vfy-'));
const chrome = spawn(CHROME, [
  '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-extensions',
  `--remote-debugging-port=${PORT}`, `--user-data-dir=${PROFILE}`, 'about:blank'
], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main() {
  let wsUrl = null;
  for (let i = 0; i < 80 && !wsUrl; i++) {
    try {
      const j = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
      const p = (j || []).find(t => t.type === 'page');
      wsUrl = p && p.webSocketDebuggerUrl;
    } catch (e) {}
    if (!wsUrl) await sleep(250);
  }
  const ws = new WebSocket(wsUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pend = new Map();
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.rej(new Error(m.error.message)) : p.res(m.result); }
  };
  const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
  const ev = async expr => {
    const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails).slice(0, 400));
    return r.result.value;
  };
  await send('Page.enable'); await send('Runtime.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 900, height: 1200, deviceScaleFactor: 1, mobile: false });
  await send('Page.navigate', { url: 'file:///' + FILE.replace(/\\/g, '/') });
  await sleep(1500);
  const probeExpr = `JSON.stringify((() => {
    const tbl = document.querySelector('table.elem-official');
    if (!tbl) return { error: '未找到表格' };
    const tds = tbl.querySelectorAll('tr:not(.sec-full) > td');
    const first = tbl.querySelector('tr:not(.sec-full)');
    const lab = first && first.querySelector('td.lab');
    const val = first && first.querySelector('td.val');
    const title = document.querySelector('.elem-official-title');
    const note = tbl.querySelector('tr.note td, tr.sec-full td');
    const overflow = Array.from(tbl.querySelectorAll('td')).filter(td => td.scrollWidth > td.clientWidth + 2).length;
    return {
      tableWidth: Math.round(tbl.getBoundingClientRect().width),
      labRatio: lab ? +(lab.getBoundingClientRect().width / tbl.getBoundingClientRect().width).toFixed(3) : null,
      valRatio: val ? +(val.getBoundingClientRect().width / tbl.getBoundingClientRect().width).toFixed(3) : null,
      rows: tbl.querySelectorAll('tr').length,
      titleFont: title ? getComputedStyle(title).fontSize : null,
      bodyFont: getComputedStyle(tbl).fontSize,
      noteFont: note ? getComputedStyle(note).fontSize : null,
      sectionFont: (function(){ var s = tbl.querySelector('tr.sec-full.sec-ct td') || tbl.querySelector('tr.sec td, tr.sec-ct td'); return s ? getComputedStyle(s).fontSize : null; })(),
      sectionAlign: (function(){ var s = tbl.querySelector('tr.sec-full.sec-ct td'); return s ? getComputedStyle(s).textAlign : null; })(),
      sectionInlineStyle: (function(){ var s = tbl.querySelector('tr.sec-full.sec-ct td'); return s ? (s.getAttribute('style') || '') : null; })(),
      sectionCount: tbl.querySelectorAll('tr.sec-full.sec-ct').length,
      border: getComputedStyle(tbl.querySelector('td')).borderTopWidth,
      overflowCells: overflow,
      textLen: tbl.innerText.length
    };
  })())`;
  let out = await ev(probeExpr);
  for (let i = 0; i < 6 && String(out).indexOf('未找到表格') >= 0; i++) {
    await sleep(1000);
    await send('Page.navigate', { url: 'file:///' + FILE.replace(/\\/g, '/') });
    await sleep(1500);
    out = await ev(probeExpr);
  }
  console.log(FILE);
  console.log(out);
  const pdf = await send('Page.printToPDF', { printBackground: true, preferCSSPageSize: true });
  const outPdf = FILE.replace(/\.(doc|html)$/, '') + '.pdf';
  fs.writeFileSync(outPdf, Buffer.from(pdf.data, 'base64'));
  console.log('PDF 预览: ' + outPdf);
  ws.close();
}

main().then(() => { chrome.kill(); process.exit(0); }).catch(e => { console.error('ERR', e.message); chrome.kill(); process.exit(1); });
