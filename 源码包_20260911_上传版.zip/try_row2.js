/* 单行调试（带案由数据）：node try_row2.js "<案由>" "<行标签>" */
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, 'src');
const app3 = fs.readFileSync(path.join(src, 'app3.js'), 'utf8');
const layoutsSrc = fs.readFileSync(path.join(src, 'official_layouts.js'), 'utf8');
const sandbox = {
  console,
  escHtml: s => String(s == null ? '' : s),
  currentDraft: { mode: 'complaint' },
  normalizeCaseType: s => String(s || ''),
  docTypeForMode: () => 'complaint',
  findTemplate: () => null
};
const api = new Function('sandbox', 'with (sandbox) { ' + layoutsSrc + '\n' + app3 +
  '\n return { layoutRowsFor, fillLayoutContent, elemRowValueFromFacts, elemRowValueFromClaims, elemDefaultForRow, elemElementValue, elemApplyRowValue }; }')(sandbox);

const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'out', 'tmp_divorce_data.json'), 'utf8'));
const caseType = process.argv[2] || '离婚纠纷';
const want = process.argv[3] || '';
const layout = api.layoutRowsFor(caseType, 'complaint');
layout.forEach(r => {
  if (r[0] !== 'r') return;
  const label = String(r[1]).replace(/\n/g, '');
  if (want && label.indexOf(want) < 0) return;
  const fact = api.elemRowValueFromFacts(label, data);
  const claim = api.elemRowValueFromClaims(label, data);
  const def = api.elemDefaultForRow(label, data);
  const out = api.fillLayoutContent(label, r[2] || '', data, null);
  console.log('【' + label + '】');
  console.log('   fact=' + (fact ? fact.slice(0, 60) : '(无)') + ' ｜ claim=' + (claim ? claim.slice(0, 60) : '(无)') + ' ｜ default=' + (def || '(无)'));
  console.log('   out=' + String(out).replace(/\n/g, ' / ').slice(0, 160));
});
