/* 渲染器单元测试：直接加载 app3.js，用样例数据检查官方要素表逐行映射 */
const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, 'src');
const app3 = fs.readFileSync(path.join(src, 'app3.js'), 'utf8');
const layoutsSrc = fs.readFileSync(path.join(src, 'official_layouts.js'), 'utf8');

const sandbox = {
  console,
  escHtml: s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'),
  currentDraft: { mode: 'complaint' },
  normalizeCaseType: s => String(s || '').replace(/\s/g, ''),
  docTypeForMode: () => 'complaint',
  findTemplate: (dt, caseType) => ({ caseType: caseType, docType: dt, canonicalKey: caseType, tpl: { title: '民事起诉状', t: '民事起诉状' } }),
  elemOfficialFind: null
};

const factory = new Function(
  'sandbox',
  'with (sandbox) { ' + layoutsSrc + '\n' + app3 + '\n return { buildOfficialElemDoc, fillLayoutRows, layoutRowsFor, layoutRowsToHtml, elemOfficialRowList, officialRowAudit, elemDefaultForRow, elemRowValueFromFacts, elemApplyRowValue, elemApplyChoice, fillLayoutContent }; }'
);
const api = factory(sandbox);

const caseType = process.argv[2] || '民间借贷纠纷';
const data = {
  caseType: caseType,
  plaintiff: { name: '张三', gender: '男', birth: '1980年1月1日', nation: '汉族', idNo: '342124198001011234', addr: '安徽省涡阳县义门镇XX村', phone: '13800000000' },
  defendant: { name: '李四', gender: '男', birth: '1979年2月2日', nation: '汉族', idNo: '342124197902021234', addr: '安徽省涡阳县陈大镇YY村', phone: '13900000000' },
  claims: ['判令被告偿还借款本金50000元', '判令被告支付利息（以50000元为基数，自2024年6月1日起按年利率13.8%计至实际清偿之日止）', '本案诉讼费用由被告承担'],
  evidence: ['借条（原件）', '银行转账记录'],
  facts: [
    { label: '原被告关系', content: '朋友关系' },
    { label: '借款时间地点金额', content: '2023年6月10日，安徽省涡阳县，借款50000元' },
    { label: '借款用途', content: '经营周转' },
    { label: '还款约定', content: '约定月息1分，2024年6月1日到期一次性还本付息' },
    { label: '逾期情况', content: '到期后未偿还，多次催收无果' },
    { label: '标的总额', content: '本金50000元及利息' },
    { label: '请求依据', content: '《民法典》第六百六十七条、第六百七十五条' }
  ],
  court: '涡阳县人民法院',
  signerName: '张三',
  signDate: '2026年9月11日'
};

if (caseType === '--blank') {
  const ct = process.argv[3] || '民间借贷纠纷';
  const layout = api.layoutRowsFor(ct, process.argv[4] || 'complaint');
  const doc = layout ? { html: api.layoutRowsToHtml(ct, layout, {}) } : null;
  const file = 'out/blank_' + ct + '.html';
  fs.writeFileSync(file, doc ? doc.html : '', 'utf8');
  console.log('已生成空白模板渲染: ' + file);
  process.exit(0);
}

if (caseType === '--sweep') {
  const keys = [];
  const probe = new Function('sandbox', 'with (sandbox) { ' + layoutsSrc + '\n return Object.keys(OFFICIAL_LAYOUTS); }');
  keys.push(...probe(sandbox));
  let bad = 0;
  const rows = [];
  keys.forEach(k => {
    const ct = k.split('|')[0];
    try {
      const d = Object.assign({}, data, { caseType: ct });
      const lay = api.layoutRowsFor(ct, 'complaint') || api.layoutRowsFor(ct, 'admin_complaint') || api.layoutRowsFor(ct, 'criminal_complaint');
      if (!lay) { rows.push([ct, '无版式', '']); return; }
      const f = api.fillLayoutRows(lay, d);
      const empty = f.filter(r => r[0] === 'r' && !String(r[2] || '').trim()).length;
      const changed = f.filter((r, i) => r[0] === 'r' && String(r[2] || '') !== String(lay[i][2] || '')).length;
      const aud = api.officialRowAudit(ct, null, d);
      rows.push([ct + '|' + k.split('|')[1], '行' + lay.length, '填充' + changed, '空行' + empty, '审计缺' + aud.missing.length]);
    } catch (e) {
      bad++;
      rows.push([ct, 'ERR', String(e.message).slice(0, 90)]);
    }
  });
  rows.forEach(r => console.log(r.join(' | ')));
  console.log('总版式:', keys.length, '异常:', bad);
  process.exit(0);
}

const doc = api.buildOfficialElemDoc(data);
if (!doc) { console.log('无官方模板命中'); process.exit(1); }

const layout = api.layoutRowsFor(caseType, 'complaint');
const filled = api.fillLayoutRows(layout, data);
const audit = api.officialRowAudit(caseType, null, data);

console.log('案由:', caseType, '| 模板行数:', layout.length, '| 未填行:', audit.missing.length);
console.log('--- 逐行 ---');
filled.forEach(r => {
  if (r[0] === 'r') {
    console.log('[' + String(r[1]).replace(/\n/g, '') + '] => ' + String(r[2]).replace(/\n/g, ' ⏎ '));
  }
});
if (audit.missing.length) console.log('未填: ' + audit.missing.join('、'));
