/* 冒烟测试：加载页面，切换各文书类型与案由，检查控制台异常 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PAGE = process.env.PROBE_PAGE
  ? (/^https?:/i.test(process.env.PROBE_PAGE) ? process.env.PROBE_PAGE : 'file:///' + process.env.PROBE_PAGE.replace(/\\/g, '/'))
  : 'file:///' + path.join(__dirname, 'out', 'index.html').replace(/\\/g, '/');
const PORT = 9449;
const PROFILE = fs.mkdtempSync(path.join(os.tmpdir(), 'smoke-'));
const chrome = spawn(CHROME, ['--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-extensions',
  `--remote-debugging-port=${PORT}`, `--user-data-dir=${PROFILE}`, 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main() {
  let wsUrl = null;
  for (let i = 0; i < 80 && !wsUrl; i++) {
    try { const j = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); const p = (j || []).find(t => t.type === 'page'); wsUrl = p && p.webSocketDebuggerUrl; } catch (e) {}
    if (!wsUrl) await sleep(250);
  }
  const ws = new WebSocket(wsUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pend = new Map(); const errors = [];
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.method === 'Runtime.exceptionThrown') errors.push(JSON.stringify(m.params.exceptionDetails).slice(0, 200));
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push('console.error: ' + JSON.stringify(m.params.args).slice(0, 200));
    if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.rej(new Error(m.error.message)) : p.res(m.result); }
  };
  const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
  const ev = async expr => {
    const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) return 'EXC:' + JSON.stringify(r.exceptionDetails).slice(0, 300);
    return r.result.value;
  };
  await send('Page.enable'); await send('Runtime.enable');
  await send('Page.navigate', { url: PAGE });
  // 等页面脚本真正就绪（线上 1.4MB，首次加载可能较慢）
  let ready = '';
  for (let i = 0; i < 40; i++) {
    await sleep(500);
    ready = await ev(`(document.readyState + '|' + (typeof setDraftMode) + '|' + (typeof OFFICIAL_LAYOUTS !== 'undefined' ? Object.keys(OFFICIAL_LAYOUTS).length : -1))`);
    if (String(ready).indexOf('function') >= 0) break;
  }
  console.log('页面就绪状态: ' + ready);

  const modes = ['complaint', 'answer', 'exec', 'petition', 'change', 'generic'];
  for (const m of modes) {
    const r = await ev(`(function(){ try { setDraftMode('${m}'); return 'ok'; } catch(e) { return 'ERR:' + e.message; } })()`);
    if (String(r).indexOf('ok') < 0) errors.push('setDraftMode(' + m + ') -> ' + r);
  }
  const tabChecks = await ev(`(function(){ try { ['cases','draft','evidence','research','govern','settings'].forEach(t=>goTab(t)); goTab('draft'); return 'ok'; } catch(e) { return 'ERR:' + e.message; } })()`);
  if (String(tabChecks).indexOf('ok') < 0) errors.push('goTab -> ' + tabChecks);

  const layouts = await ev(`(function(){
    const out = {};
    out.layoutKeys = (typeof OFFICIAL_LAYOUTS !== 'undefined') ? Object.keys(OFFICIAL_LAYOUTS).length : -1;
    out.rowLabelsLoan = (typeof elemOfficialRowLabels === 'function') ? elemOfficialRowLabels('民间借贷纠纷','complaint').length : -1;
    out.rowLabelsExec = (typeof elemOfficialRowLabels === 'function') ? elemOfficialRowLabels('强制执行','exec').length : -1;
    out.defaults = (typeof elemDefaultForRow === 'function') ? elemDefaultForRow('3.是否要求提前还款或解除合同', {claims:['判处罚款'],facts:[]}) : 'n/a';
    return JSON.stringify(out);
  })()`);
  console.log('结构检查: ' + layouts);
  console.log(errors.length ? '发现异常:\n' + errors.join('\n') : '✅ 无控制台异常');
  ws.close();
}

main().then(() => { chrome.kill(); process.exit(0); }).catch(e => { console.error('ERR', e.message); chrome.kill(); process.exit(1); });
