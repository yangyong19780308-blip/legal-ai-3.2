/* 真实模型端到端：用真实 API Key 跑「材料 → 分析回填 → 生成官方要素式文书」
 * 用法: node real_run.js "<案由>" <mode> "<素材文本>"   （Key 从环境变量读取，不打印）
 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PAGE = process.env.PROBE_PAGE
  ? (/^https?:/i.test(process.env.PROBE_PAGE) ? process.env.PROBE_PAGE : 'file:///' + process.env.PROBE_PAGE.replace(/\\/g, '/'))
  : 'file:///' + path.join(__dirname, 'out', 'index.html').replace(/\\/g, '/');
const PORT = 9471;
const PROFILE = fs.mkdtempSync(path.join(os.tmpdir(), 'real-'));
const KEY = process.env.DEEPSEEK_API_KEY || '';
const CASE_TYPE = process.argv[2] || '民间借贷纠纷';
const MODE = process.argv[3] || 'complaint';
const DEFAULT_MATERIAL = {
  complaint: '原告张三，2023年6月10日借给被告李四5万元，约定月息1分，2024年6月1日到期未还，多次催收无果，有借条和银行转账记录。原告张三，男，1980年1月1日生，汉族，住安徽省涡阳县义门镇XX村，身份证342124198001011234，电话13800000000。被告李四，男，1979年2月2日生，汉族，住安徽省涡阳县陈大镇YY村，身份证342124197902021234。请求判令被告偿还本金50000元及利息（自2024年6月1日起按年利率13.8%计至实际清偿之日止），诉讼费由被告承担。',
  answer: '案由：买卖合同纠纷。原告涡阳县惠农商贸有限公司诉被告张三买卖合同纠纷一案，原告主张被告欠付货款86000元及利息、违约金。被告张三答辩：双方2024年1月签订购销合同，约定货到付款；原告交付的第三批货物存在质量不符合约定情形（已由双方技术人员确认），被告已于2024年3月支付货款60000元，剩余26000元因质量异议未付，不存在恶意拖欠；被告从未承诺支付利息和违约金，且原告主张的利息计算标准没有合同依据。被告请求法院依法驳回原告除26000元以外的诉讼请求，并主张对质量问题另行处理。被告张三，男，1980年1月1日生，汉族，住安徽省涡阳县陈大镇YY村，身份证342124197902021234，电话13900000000。',
  exec: '申请执行人张三与被执行人李四民间借贷纠纷一案，涡阳县人民法院于2025年6月20日作出（2025）皖1621民初1234号民事判决书，2025年8月1日生效，判决：一、被告李四于本判决生效之日起十日内偿还原告张三借款本金50000元及利息（以50000元为基数，自2024年6月1日起按年利率13.8%计算至实际清偿之日止）；二、案件受理费1050元由被告李四负担。判决生效后被执行人未履行，申请执行人申请强制执行。申请执行人张三，男，1980年1月1日生，汉族，住安徽省涡阳县义门镇XX村，身份证342124198001011234，电话13800000000；被执行人李四，男，1979年2月2日生，汉族，住安徽省涡阳县陈大镇YY村，身份证342124197902021234。被执行人名下有皖A12345号小型轿车一辆，无诉前保全。'
};
const MATERIAL = process.argv[4] || DEFAULT_MATERIAL[MODE] || DEFAULT_MATERIAL.complaint;

if (!KEY) { console.error('缺少 DEEPSEEK_API_KEY'); process.exit(1); }

const chrome = spawn(CHROME, ['--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-extensions',
  `--remote-debugging-port=${PORT}`, `--user-data-dir=${PROFILE}`, 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main() {
  let wsUrl = null;
  for (let i = 0; i < 80 && !wsUrl; i++) {
    try { const j = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); const p = (j || []).find(t => t.type === 'page'); wsUrl = p && p.webSocketDebuggerUrl; } catch (e) {}
    if (!wsUrl) await sleep(250);
  }
  const ws = new WebSocket(wsUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pend = new Map(); const errs = [];
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.method === 'Runtime.exceptionThrown') errs.push(String(m.params.exceptionDetails.text).slice(0, 120));
    if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.rej(new Error(m.error.message)) : p.res(m.result); }
  };
  const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
  const ev = async expr => {
    const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) throw new Error('页面异常: ' + JSON.stringify(r.exceptionDetails).slice(0, 400));
    return r.result.value;
  };
  await send('Page.enable'); await send('Runtime.enable');
  await send('Page.navigate', { url: PAGE });
  await sleep(2500);
  await ev(`state.keys.deepseek=${JSON.stringify(KEY)}; state.provider='deepseek'; state.models.deepseek='deepseek-chat'; saveState(); updateModelPill(); 'ok'`);
  await ev(`goTab('draft'); window.confirm = () => true; setDraftMode(${JSON.stringify(MODE)}); 'ok'`);
  await ev(`document.getElementById('draftMaterial').value=${JSON.stringify(MATERIAL)}; currentDraft.material=${JSON.stringify(MATERIAL)}; currentDraft.caseType=${JSON.stringify(CASE_TYPE)}; document.getElementById('caseTypeSel').value=${JSON.stringify(CASE_TYPE)}; onDraftCaseTypeChange(); 'ok'`);

  console.log('调用真实模型（deepseek-chat）…');
  await ev(`(async()=>{ try { await draftAnalyze(); } catch(e){ window.__err = String(e && e.message || e); } })(); 'ok'`);
  let waited = 0;
  while (waited < 180000) {
    await sleep(1000); waited += 1000;
    const done = await ev(`(typeof busy !== 'undefined' && !busy) ? 'done' : 'busy'`);
    if (done === 'done') break;
  }
  const err = await ev(`window.__err || ''`);
  if (err) console.log('分析报错：' + err);
  const prep = await ev(`(document.getElementById('draftPrepText') || {}).innerText || ''`);
  console.log('分析面板：' + String(prep).slice(0, 300).replace(/\n/g, ' | '));

  const info = await ev(`JSON.stringify((function(){
    var analysis = currentDraft.analysis || '';
    var sp = (typeof splitAnalysisJson === 'function') ? splitAnalysisJson(analysis) : { obj: null };
    var els = (sp.obj && sp.obj.elements) || {};
    var rows = (document.getElementById('elemOfficialRows') || {}).value || '';
    return {
      analysisChars: analysis.length,
      hasElements: Object.keys(els).length,
      elementKeys: Object.keys(els).slice(0, 8),
      rowsTextChars: rows.length,
      rowsFilledLines: rows.split('\\n').filter(function(l){ var v = l.slice(l.indexOf('：')+1).trim(); return v && v !== '无'; }).length,
      rowsTotal: rows.split('\\n').length,
      missing: (document.getElementById('elemMissing') || {}).innerText || ''
    };
  })())`);
  console.log('分析结果：' + info);
  const rawAnalysis = await ev(`currentDraft.analysis || ''`);
  const rawFile = path.join(__dirname, 'out', 'real_' + CASE_TYPE + '_' + MODE + '.analysis.txt');
  fs.writeFileSync(rawFile, rawAnalysis, 'utf8');
  const elsJson = await ev(`JSON.stringify((function(){
    var sp = splitAnalysisJson(currentDraft.analysis || '');
    return (sp.obj && sp.obj.elements) || {};
  })())`);
  fs.writeFileSync(path.join(__dirname, 'out', 'real_' + CASE_TYPE + '_' + MODE + '.elements.json'), elsJson, 'utf8');
  console.log('已保存分析原文与 elements');

  await ev(`(async()=>{ try { await genDraftFromElemForm(); } catch(e){ window.__err2 = String(e && e.message || e); } })(); 'ok'`);
  waited = 0;
  while (waited < 180000) {
    await sleep(1000); waited += 1000;
    const done = await ev(`(typeof busy !== 'undefined' && !busy) ? 'done' : 'busy'`);
    if (done === 'done') break;
  }
  const err2 = await ev(`window.__err2 || ''`);
  if (err2) console.log('生成报错：' + err2);

  const docs = await ev(`JSON.stringify((currentDraft.docs||[]).map(function(d){ return { name: d.name, htmlLen: (d.html||'').length }; }))`);
  console.log('生成文书：' + docs);
  const html = await ev(`(currentDraft.docs && currentDraft.docs[0] && currentDraft.docs[0].html) || ''`);
  const safe = 'real_' + CASE_TYPE + '_' + MODE;
  fs.writeFileSync(path.join(__dirname, 'out', safe + '.html'), html, 'utf8');
  console.log('已保存：out/' + safe + '.html');
  const all = await ev(`JSON.stringify((currentDraft.docs||[]).map(function(d){ return { name: d.name, html: d.html || '', text: d.text || '' }; }))`);
  try {
    JSON.parse(all).forEach((d, i) => {
      const base = path.join(__dirname, 'out', safe + '_doc' + (i + 1) + '.html');
      fs.writeFileSync(base, d.html || '', 'utf8');
      fs.writeFileSync(base.replace(/\.html$/, '.txt'), d.text || '', 'utf8');
    });
  } catch (e) { /* 忽略 */ }
  if (errs.length) console.log('控制台异常：' + errs.slice(0, 3).join(' | '));
  ws.close();
}
main().then(() => { chrome.kill(); process.exit(0); }).catch(e => { console.error('ERR', e.message); chrome.kill(); process.exit(1); });
