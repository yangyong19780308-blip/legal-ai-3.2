/* ==================== v3.3 迁移层（第一批：仅迁移，不改运行时数据结构） ==================== */
// 职责：把 localStorage['fawu32_v1'] 无损迁移为 v3.3 结构，写入 localStorage['fawu32_v3']；
// 迁移前自动备份 v1 原文。本层不改变应用运行时读取的 v1 结构（案件/文档模型切换在后续批次）。

const SCHEMA_V1_KEY = 'fawu32_v1';
const SCHEMA_V3_KEY = 'fawu32_v3';
const SCHEMA_V1_BACKUP_PREFIX = 'fawu32_v1_backup_';

function detectSchemaVersion(json) {
  if (!json || typeof json !== 'object') return 'unknown';
  if (json.schemaVersion === 'v3.3' || (json.version != null && json.version >= 2)) return 'v3';
  if (Array.isArray(json.cases) && !json.schemaVersion) return 'v1';
  return 'unknown';
}

function migrateCaseV1ToV3(c, index) {
  const id = c && c.id ? c.id : ('case_' + Date.now().toString(36) + '_' + index);
  const createdAt = (c && c.createdAt) || Date.now();
  const updatedAt = (c && c.updatedAt) || createdAt;
  const docs = Array.isArray(c && c.docs) ? c.docs : [];
  const docRefs = docs.map((d, i) => 'doc_' + id + '_' + (i + 1));
  return {
    schemaVersion: 'v3.3',
    version: 1,
    id: id,
    deletedAt: null,
    title: (c && c.title) || '未命名案件',
    status: 'draft',
    tags: [],
    caseNo: '',
    court: '',
    caseType: '',
    docType: '',
    material: (c && c.material) || '',
    parties: { plaintiffs: [], defendants: [], thirdParties: [], agents: [] },
    claims: [],
    evidence: [],
    facts: [],
    documents: docRefs,
    notes: [],
    timeline: [{ t: createdAt, event: 'created' }],
    createdAt: createdAt,
    updatedAt: updatedAt,
    closedAt: null,
    meta: { source: 'legacy' }
  };
}

function migrateDocV1ToV3(d, caseId, docId, index, ts) {
  const t = ts || 0;
  return {
    id: docId,
    caseId: caseId,
    templateId: null,
    canonicalKey: '',
    revisions: [{
      revision: 1,
      name: (d && d.name) || '文书' + (index + 1),
      status: 'generated',
      content: {
        html: (d && d.html) || null,
        text: (d && d.text) || '',
        docx: null
      },
      snapshot: {
        parties: { plaintiffs: [], defendants: [] },
        claims: [],
        evidence: [],
        facts: [],
        basis: '',
        total: '',
        court: '',
        caseType: ''
      },
      aiMeta: { provider: '', model: '', generatedAt: 0, tokens: { in: 0, out: 0 }, cost: 0 },
      checks: [],
      createdAt: t,
      updatedAt: t
    }],
    createdAt: t,
    updatedAt: t
  };
}

function migrateV1ToV3(v1) {
  const srcCases = Array.isArray(v1 && v1.cases) ? v1.cases : [];
  const documents = {};
  const cases = srcCases.map((c, ci) => {
    const caseId = (c && c.id) ? c.id : ('case_' + Date.now().toString(36) + '_' + ci);
    const ts = (c && (c.updatedAt || c.createdAt)) || 0;
    const docs = Array.isArray(c && c.docs) ? c.docs : [];
    docs.forEach((d, i) => {
      const docId = 'doc_' + caseId + '_' + (i + 1);
      documents[docId] = migrateDocV1ToV3(d, caseId, docId, i, ts);
    });
    return migrateCaseV1ToV3(Object.assign({}, c, { id: caseId }), ci);
  });
  return {
    schemaVersion: 'v3.3',
    version: 1,
    provider: (v1 && v1.provider != null) ? v1.provider : 'zhipu',
    keys: (v1 && v1.keys) || {},
    models: (v1 && v1.models) || {},
    bases: (v1 && v1.bases) || {},
    rates: (v1 && v1.rates) || {},
    cases: cases,
    documents: documents,
    ledger: Array.isArray(v1 && v1.ledger) ? v1.ledger : []
  };
}

function migrationStats(v1, v3) {
  const v1Docs = ((v1 && v1.cases) || []).reduce((s, c) => s + (Array.isArray(c && c.docs) ? c.docs.length : 0), 0);
  return {
    cases: ((v3 && v3.cases) || []).length,
    documents: Object.keys((v3 && v3.documents) || {}).length,
    v1Docs: v1Docs,
    ledger: ((v3 && v3.ledger) || []).length
  };
}

function runMigration(opts) {
  opts = opts || {};
  try {
    const v3raw = localStorage.getItem(SCHEMA_V3_KEY);
    if (v3raw && !opts.force) return { ok: true, migrated: false, reason: 'v3 已存在，跳过' };
    const v1raw = localStorage.getItem(SCHEMA_V1_KEY);
    if (!v1raw) return { ok: true, migrated: false, reason: '无 v1 数据，跳过' };
    let v1;
    try { v1 = JSON.parse(v1raw); } catch (e) { return { ok: false, error: 'v1 数据解析失败' }; }
    if (detectSchemaVersion(v1) !== 'v1') return { ok: false, reason: '非 v1 结构，跳过迁移' };
    const backupKey = SCHEMA_V1_BACKUP_PREFIX + Date.now().toString(36);
    localStorage.setItem(backupKey, v1raw);
    const v3 = migrateV1ToV3(v1);
    localStorage.setItem(SCHEMA_V3_KEY, JSON.stringify(v3));
    return { ok: true, migrated: true, backupKey: backupKey, stats: migrationStats(v1, v3) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

/* ==================== v3.3 运行时辅助（第四批：切换进运行时） ==================== */

function normalizeV3Case(c) {
  if (!c || typeof c !== 'object') return null;
  const now = Date.now();
  const base = {
    schemaVersion: 'v3.3', version: 1, id: '', deletedAt: null, title: '未命名案件',
    status: 'draft', tags: [], caseNo: '', court: '', caseType: '', docType: '',
    material: '',
    parties: { plaintiffs: [], defendants: [], thirdParties: [], agents: [] },
    claims: [], evidence: [], facts: [], documents: [], notes: [],
    timeline: [], createdAt: now, updatedAt: now, closedAt: null,
    meta: { source: 'legacy' }
  };
  const o = Object.assign({}, base, c);
  o.schemaVersion = 'v3.3';
  o.version = 1;
  if (!o.id) o.id = 'case_' + now.toString(36) + '_' + Math.floor(Math.random() * 46656).toString(36);
  if (o.deletedAt === undefined) o.deletedAt = null;
  if (o.closedAt === undefined) o.closedAt = null;
  o.parties = Object.assign({ plaintiffs: [], defendants: [], thirdParties: [], agents: [] }, o.parties || {});
  ['plaintiffs', 'defendants', 'thirdParties', 'agents'].forEach(k => { if (!Array.isArray(o.parties[k])) o.parties[k] = []; });
  ['tags', 'claims', 'evidence', 'facts', 'documents', 'notes'].forEach(k => { if (!Array.isArray(o[k])) o[k] = []; });
  if (!Array.isArray(o.timeline) || !o.timeline.length) o.timeline = [{ t: o.createdAt || now, event: 'created' }];
  if (o.meta === null || typeof o.meta !== 'object') o.meta = { source: 'legacy' };
  return o;
}

function ensureV3State(input) {
  const src = (input && typeof input === 'object') ? input : {};
  let base = src;
  if (detectSchemaVersion(src) === 'v1') base = migrateV1ToV3(src);
  return {
    schemaVersion: 'v3.3',
    version: 1,
    provider: (base.provider != null) ? base.provider : 'zhipu',
    keys: (base.keys && typeof base.keys === 'object') ? base.keys : {},
    models: (base.models && typeof base.models === 'object') ? base.models : {},
    bases: (base.bases && typeof base.bases === 'object') ? base.bases : {},
    rates: (base.rates && typeof base.rates === 'object') ? base.rates : {},
    cases: Array.isArray(base.cases) ? base.cases.map(normalizeV3Case).filter(Boolean) : [],
    documents: (base.documents && typeof base.documents === 'object' && !Array.isArray(base.documents)) ? base.documents : {},
    ledger: Array.isArray(base.ledger) ? base.ledger : []
  };
}

function createV3Case(opts) {
  opts = opts || {};
  const now = Date.now();
  const id = opts.id || ('case_' + now.toString(36));
  const c = {
    schemaVersion: 'v3.3', version: 1, id: id, deletedAt: null,
    title: opts.title || '未命名案件', status: 'draft', tags: [],
    caseNo: '', court: '', caseType: opts.caseType || '', docType: opts.docType || '',
    material: opts.material || '',
    parties: { plaintiffs: [], defendants: [], thirdParties: [], agents: [] },
    claims: [], evidence: [], facts: [], documents: [], notes: [],
    timeline: [{ t: now, event: 'created' }],
    createdAt: now, updatedAt: now, closedAt: null,
    meta: { source: opts.source || 'draft' }
  };
  return c;
}
