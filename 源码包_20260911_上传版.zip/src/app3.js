/* ==================== 官方要素式模板渲染（67类示范文本 · 外框表格） ==================== */

function elemNormKey(s) {
  // 顺带把 AI 输出里常见的转义换行（\n）与 ⏎ 记号归一掉，避免行标签对不上
  return String(s || '')
    .replace(/\\+[nrt]/g, ' ')
    .replace(/\u23ce/g, ' ')
    .replace(/[\s，。、；：:（）()【】\[\]\/\\·\-—]/g, '')
    .toLowerCase();
}

function elemOfficialFind(caseType) {
  // 第三批：docType 从现有 mode / 文书类型上下文取得（currentDraft.mode），不自行猜测
  const mode = (typeof currentDraft !== 'undefined' && currentDraft && currentDraft.mode) || 'complaint';
  const dt = docTypeForMode(mode, caseType);
  const hit = findTemplate(dt, caseType);
  return hit ? { key: hit.caseType, tpl: hit.tpl, docType: hit.docType, canonicalKey: hit.canonicalKey } : null;
}

/* 当事人身份识别：优先用 AI/表单给出的“类型”，其次名称关键词，最后兜底特征判断。
   官方模板的当事人行分「自然人」与「法人、非法人组织」两套，错判会导致整块当事人信息填不进去。 */
const ELEM_ORG_WORDS = /(公司|集团|厂|店|合作社|银行|中心|事务所|学校|医院|研究院|农场|商店|局|委员会|协会|基金会|商会|部队|机构|经营部|服务部|工作室|商行|门市|超市|酒店|宾馆|网吧|养殖场|种植场|管理处|办公室|指挥部|项目部|工程处|支行|分行|分社|联社|总社|厅|委|署|站|所|队|团|馆|园|场|部)$/;
const ELEM_ORG_KEYWORDS = /(有限责任公司|股份有限公司|有限公司|合伙企业|个体工商户|农民专业合作社|事业单位|社会团体|社会服务机构|居民委员会|村民委员会|人民政府|人民法院|人民检察院|公立医院|大学|学院|中学|小学|幼儿园)/;
const ELEM_PERSON_HINT = /(自然人|公民|个人)/;

function elemPartyTypeOf(party) {
  const p = party || {};
  const raw = String(p.type || p.partyType || p.kind || p.entityType || '').trim();
  if (!raw) return '';
  if (ELEM_PERSON_HINT.test(raw)) return 'person';
  if (/(公司|企业|法人|组织|机关|事业|团体|机构|单位|合作社|个体|合伙)/.test(raw)) return 'org';
  return '';
}

function elemIsCompany(name, party) {
  const declared = elemPartyTypeOf(party);
  if (declared) return declared === 'org';
  const n = String(name || '').trim();
  if (!n) return false;
  if (ELEM_ORG_KEYWORDS.test(n)) return true;
  if (ELEM_ORG_WORDS.test(n)) return true;
  return false;
}

function fillOfficialRows(tpl, data) {
  const p = data.plaintiff || {};
  const d = data.defendant || {};
  const hasEvidSection = tpl.rows.some(r => r[0] === 'h' && elemNormKey(r[1]).includes('证据清单'));
  const basis = (data.facts || []).find(f => elemNormKey(f.label).includes('依据'));
  const total = (data.facts || []).find(f => elemNormKey(f.label).includes('标的总额'));
  const injFacts = (data.facts || []).filter(f => {
    const n = elemNormKey(f.label);
    return n && !n.includes('依据') && !n.includes('标的总额');
  });

  let current = '';
  let lastSection = '';
  const out = [];
  const flushSection = () => {
    const sec = lastSection;
    const claimLabel = sec === '诉讼请求' ? '诉讼请求'
      : sec === '申请执行事项' ? '申请执行事项'
        : sec === '答辩事项' ? '答辩请求' : '';
    const isClaimSec = (sec === '诉讼请求' || sec === '申请执行事项' || sec === '答辩事项');
    const isFactSec = (sec === '事实与理由' || sec === '答辩事项');
    const isCombinedSec = (sec === '申请执行事项' || sec === '答辩事项');
    const isEvidSec = (sec === '证据清单');
    const claimsText = (data.claims || []).map((c, i) => (i + 1) + '. ' + c).join('；');
    if (isClaimSec && data.claims && data.claims.length && claimLabel) {
      out.push(['p', claimLabel + '（AI 提取，请核对）：' + claimsText]);
    }
    if ((isFactSec || isCombinedSec) && injFacts.length) {
      injFacts.forEach(f => {
        out.push(['p', '【' + f.label + '】' + String(f.content || '').trim()]);
      });
    }
    if (data.evidence && data.evidence.length) {
      const evText = '证据材料（AI 提取，请核对）：' + data.evidence.map((e, i) => (i + 1) + '. ' + e).join('；');
      if (isEvidSec) out.push(['p', evText]);
      else if (isFactSec && !hasEvidSection) out.push(['p', evText]);
      else if (isCombinedSec && !hasEvidSection) out.push(['p', '随附材料（AI 提取，请核对）：' + data.evidence.map((e, i) => (i + 1) + '. ' + e).join('；')]);
    }
    lastSection = '';
  };

  const partyFor = name => {
    const n = elemNormKey(name);
    const P = ['原告', '自诉人', '申请人', '申请执行人', '赔偿请求人', '被答辩人'];
    const D = ['被告', '被告人', '被申请人', '被执行人', '答辩人', '赔偿义务机关'];
    if (P.some(w => n.includes(w))) return 'P';
    if (D.some(w => n.includes(w))) return 'D';
    return '';
  };

  const roleWordOf = name => {
    const n = elemNormKey(name);
    if (!n) return '';
    const P = ['原告', '自诉人', '申请人', '申请执行人', '赔偿请求人', '被答辩人'];
    const D = ['被告', '被告人', '被申请人', '被执行人', '答辩人', '赔偿义务机关'];
    if (P.some(w => n === w)) return 'P';
    if (D.some(w => n === w)) return 'D';
    return '';
  };
  for (const raw of tpl.rows) {
    const r = raw.slice();
    const type = r[0];
    const text = r[1];
    if (type === 'h') {
      flushSection();
      lastSection = text;
      if (roleWordOf(text)) current = text;
      out.push(r);
      continue;
    }
    if (type === 'h2') {
      current = text;
      out.push(r);
      continue;
    }
    if (type === 'sub') { out.push(r); continue; }
    if (type === 'p' && roleWordOf(text)) { current = text; out.push(r); continue; }
    if (type === 'o') {
      let t = text;
      const side = partyFor(current);
      const party = side === 'P' ? p : (side === 'D' ? d : null);
      if (party && party.gender && /男□.*女□/.test(t)) {
        t = t.replace(/男□/, party.gender === '男' ? '男☑' : '男□').replace(/女□/, party.gender === '女' ? '女☑' : '女□');
      }
      out.push(['o', t]);
      continue;
    }
    if (type === 'f') {
      const ci = text.lastIndexOf('：');
      const lab = ci > 0 ? text.slice(0, ci) : text;
      const tail = ci > 0 ? text.slice(ci + 1) : '';
      const nLab = elemNormKey(lab);
      const side = partyFor(current);
      const party = side === 'P' ? p : (side === 'D' ? d : null);
      let value = '';
      if (party) {
        if (nLab.includes('姓名')) { if (!elemIsCompany(party.name)) value = party.name || ''; }
        else if (nLab.includes('出生日期')) value = party.birth || '';
        else if (nLab.includes('民族')) value = party.nation || '';
        else if (nLab.includes('联系电话')) value = party.phone || '';
        else if (nLab.includes('住所地') || nLab.includes('户籍地')) value = party.addr || '';
        else if (nLab.includes('经常居住地')) value = party.liveAddr || '';
        else if (nLab.includes('证件类型')) value = '身份证';
        else if (nLab.includes('证件号码')) value = party.idNo || '';
        else if (nLab.includes('名称')) { if (elemIsCompany(party.name)) value = party.name; }
      }
      if (!value && nLab.includes('法律规定')) value = basis ? String(basis.content || '').trim() : '';
      if (!value && nLab.includes('标的总额')) value = total ? String(total.content || '').trim() : '';
      if (!value && nLab.includes('日期')) value = data.signDate || '';
      if (!value && nLab.includes('具状人')) value = data.signerName || '';
      if (!value && (nLab.includes('签字') || nLab.includes('盖章'))) value = data.signerName || '';
      out.push(['f', lab + '：' + (value || tail)]);
      continue;
    }
    out.push(r);
  }
  flushSection();
  return out;
}

function rowsToHtml(title, rows) {
  let h = '<div class="elem-official-wrap"><div class="elem-official-title">' + escHtml(title) + '</div><table class="elem-official"><colgroup><col class="col-lab"><col class="col-val"></colgroup>';
  for (const r of rows) {
    const t = r[0], v = r[1];
    if (t === 'h') h += '<tr class="sec"><th colspan="2">' + escHtml(v) + '</th></tr>';
    else if (t === 'h2') h += '<tr class="sec2"><th colspan="2">' + escHtml(v) + '</th></tr>';
    else if (t === 'sub') h += '<tr class="sub"><td colspan="2">' + escHtml(v) + '</td></tr>';
    else if (t === 'f') {
      const i = v.lastIndexOf('：');
      const lab = i > 0 ? v.slice(0, i + 1) : v;
      const val = i > 0 ? v.slice(i + 1) : '';
      h += '<tr><td class="lab">' + escHtml(lab) + '</td><td class="val">' + escHtml(val) + '</td></tr>';
    } else if (t === 'o') {
      h += '<tr class="opt"><td colspan="2">' + escHtml(v) + '</td></tr>';
    } else {
      h += '<tr class="para"><td colspan="2">' + escHtml(v) + '</td></tr>';
    }
  }
  h += '</table></div>';
  return h;
}

function rowsToText(title, rows) {
  const lines = [title, ''];
  for (const r of rows) {
    const t = r[0], v = r[1];
    if (t === 'h') lines.push('【' + v + '】');
    else if (t === 'h2') lines.push('  ' + v);
    else if (t === 'sub') lines.push('    ' + v);
    else lines.push('  ' + v);
  }
  return lines.join('\n');
}

/* ==================== 官方版式（1:1 模板）渲染 ==================== */
function escRe(s) {
  return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function fillCellAfter(text, label, value) {
  if (value === undefined || value === null || String(value).trim() === '') return text;
  const lab = String(label || '').replace(/[：:]+\s*$/, '');
  const re = new RegExp('(' + escRe(lab) + '[：:])([ \t\u00a0]*)');
  if (!re.test(String(text))) return text;
  const val = String(value);
  return String(text).replace(re, function (m, p1, sp, offset, whole) {
    const after = whole.slice(offset + m.length).replace(/^[ \t\u00a0]+/, '');
    if (after.indexOf(val) === 0) return m; // 已填过，避免重复叠加
    return p1 + val + sp;
  });
}
function markCheck(text, from, to) {
  if (!from || !to) return text;
  const i = String(text).indexOf(from);
  if (i < 0) return text;
  return String(text).slice(0, i) + to + String(text).slice(i + from.length);
}
/* 勾选“有限责任公司□”这类带名称的选项，只勾中一个选项 */
function markNamedBox(text, keyword) {
  const k = String(keyword || '').trim();
  if (!k) return text;
  const t = String(text);
  const i = t.indexOf(k + '□');
  if (i >= 0) return t.slice(0, i) + k + '☑' + t.slice(i + k.length + 1);
  const j = t.indexOf('□' + k);
  if (j >= 0) return t.slice(0, j) + '☑' + k + t.slice(j + 1 + k.length);
  return t;
}

/* 官方模板有两种勾选写法：“是□”（框在后）与“□是”（框在前，行政类模板多见），两种都要认 */
const ELEM_BOX_CHARS = '\u25a1\u2610';   // □ ☐
function elemMarkOptionBox(content, opt) {
  const c = String(content || '');
  const o = String(opt || '').trim();
  if (!c || !o) return c;
  const esc = o.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const reAfter = new RegExp(esc + '[' + ELEM_BOX_CHARS + ']');
  if (reAfter.test(c)) return c.replace(reAfter, o + '☑');
  const reBefore = new RegExp('[' + ELEM_BOX_CHARS + ']' + esc);
  if (reBefore.test(c)) return c.replace(reBefore, '☑' + o);
  return c;
}
function fillBirthCell(text, birth) {
  if (!birth) return text;
  const t = String(text);
  const i = t.indexOf('出生日期：');
  if (i < 0) return t;
  const tail = t.slice(i + 5);
  const m = tail.match(/^\s*年\s*月\s*日/);
  if (m) return t.slice(0, i + 5) + String(birth) + tail.slice(m[0].length);
  return fillCellAfter(t, '出生日期', birth);
}
/* 把“截至　年　月　日止，尚欠本金　　元”里的空白槽换成实际值 */
function fillBlankRun(text, re, value) {
  if (value === undefined || value === null || String(value).trim() === '') return text;
  return String(text).replace(re, function (m0) {
    return m0.replace(/[ \t\u00a0]+/g, String(value));
  });
}
function elemPartySide(label) {
  const raw = String(label || '').trim();
  if (!raw) return '';
  // 官方表的当事人行是“原告（自然人）”“被告（法人、非法人组织）”这类短标签，且不带序号；
  // “15.被告应当支付的利息…”这类只是正文里提到当事人，不能被当成当事人信息行（否则会跳过内容映射）
  if (/^\d/.test(raw.replace(/\s/g, ''))) return '';
  const n = elemNormKey(raw);
  if (!n) return '';
  if (n.length > 14) return '';
  const P = ['原告', '自诉人', '申请人', '申请执行人', '赔偿请求人', '被答辩人'];
  const D = ['被告', '被告人', '被申请人', '被执行人', '答辩人', '赔偿义务机关'];
  if (P.some(w => n.includes(w))) return 'P';
  if (D.some(w => n.includes(w))) return 'D';
  return '';
}
function fillPartyLayoutCell(label, content, party) {
  let t = String(content || '');
  if (!party || !party.name) return t;
  const isCo = elemIsCompany(party.name, party);
  const n = elemNormKey(label);
  const personRow = n.includes('自然人') || n.includes('公民');
  const entityRow = n.includes('法人') || n.includes('非法人') || n.includes('机关') || n.includes('组织');
  // 部分官方模板的当事人行不标注“（自然人）/（法人）”（如离婚纠纷、部分行政/刑事自诉），
  // 此时按当事人实际身份自然人或单位填充对应字段。
  const untypedPartyRow = !personRow && !entityRow;
  const fillPerson = (personRow || untypedPartyRow) && !isCo;
  const fillEntity = (entityRow || untypedPartyRow) && isCo;
  if (fillPerson) {
    t = fillCellAfter(t, '姓名', party.name);
    if (party.gender) {
      if (party.gender === '男') t = markCheck(t, '男□', '男☑');
      else if (party.gender === '女') t = markCheck(t, '女□', '女☑');
    }
    if (party.birth) t = fillBirthCell(t, party.birth);
    t = fillCellAfter(t, '民族', party.nation);
    t = fillCellAfter(t, '工作单位', party.workUnit || party.company);
    t = fillCellAfter(t, '职务', party.position || party.title);
    t = fillCellAfter(t, '联系电话', party.phone);
    t = fillCellAfter(t, '住所地（户籍所在地）', party.addr || party.liveAddr);
    t = fillCellAfter(t, '经常居住地', party.liveAddr || (party.addr ? '同上' : ''));
    if (party.idNo) {
      t = fillCellAfter(t, '证件号码', party.idNo);
      t = fillCellAfter(t, '证件类型', '身份证');
    }
  } else if (fillEntity) {
    t = fillCellAfter(t, '名称', party.name);
    t = fillCellAfter(t, '住所地（主要办事机构所在地）', party.addr || party.orgAddr || party.liveAddr);
    t = fillCellAfter(t, '注册地/登记地', party.regAddr || party.addr || party.orgAddr);
    t = fillCellAfter(t, '法定代表人/负责人', party.legalRep || party.legalPerson);
    t = fillCellAfter(t, '职务', party.legalRepPosition || party.position);
    t = fillCellAfter(t, '联系电话', party.phone);
    t = fillCellAfter(t, '统一社会信用代码', party.creditCode);
    const orgType = String(party.orgType || party.unitType || '');
    if (orgType) {
      ['有限责任公司', '股份有限公司', '上市公司', '其他企业法人', '事业单位', '社会团体', '基金会',
        '社会服务机构', '机关法人', '农村集体经济组织法人', '城镇农村的合作经济组织法人',
        '基层群众性自治组织法人', '个人独资企业', '合伙企业'].forEach(k => {
        if (orgType.includes(k)) t = markNamedBox(t, k);
      });
      if (t.indexOf('☑') < 0 && /公司|企业/.test(orgType)) t = markNamedBox(t, '其他企业法人');
    }
    const ownership = String(party.ownership || '');
    if (ownership) {
      if (ownership.includes('国有')) t = markNamedBox(t, '国有');
      else if (ownership.includes('民营')) t = markNamedBox(t, '民营');
      else if (ownership.includes('其他')) t = markNamedBox(t, '其他');
    }
  }
  return t;
}
/* 一个 docType 可能对应多类官方文本：答辩状分民事/行政/刑事自诉/国家赔偿四种 */
const LAYOUT_DOC_LABELS = {
  complaint: ['民事起诉状'],
  admin_complaint: ['行政起诉状'],
  criminal_complaint: ['刑事（附带民事）自诉状'],
  answer: ['民事答辩状', '行政答辩状', '刑事（附带民事）自诉答辩状', '国家赔偿答辩状'],
  exec: ['申请书'],
  compensation: ['国家赔偿申请书']
};
function layoutDocTypeLabel(docType) {
  const list = LAYOUT_DOC_LABELS[docType];
  return (list && list[0]) || '';
}
/* 返回 { label: 官方文本类型, rows: 版式行 } 或 null */
function layoutMatchFor(caseType, docType) {
  if (typeof OFFICIAL_LAYOUTS === 'undefined' || !OFFICIAL_LAYOUTS) return null;
  const labels = LAYOUT_DOC_LABELS[docType];
  if (!labels || !labels.length) return null;
  const norm = (typeof normalizeCaseType === 'function') ? normalizeCaseType(caseType) : String(caseType || '');
  for (const lab of labels) {
    const suffix = '|' + lab;
    if (OFFICIAL_LAYOUTS[caseType + suffix]) return { label: lab, rows: OFFICIAL_LAYOUTS[caseType + suffix] };
    for (const k in OFFICIAL_LAYOUTS) {
      if (!k.endsWith(suffix)) continue;
      const n = k.slice(0, -suffix.length);
      const nn = (typeof normalizeCaseType === 'function') ? normalizeCaseType(n) : n;
      if (nn === norm) return { label: lab, rows: OFFICIAL_LAYOUTS[k] };
      if (nn && norm && (nn.indexOf(norm) >= 0 || norm.indexOf(nn) >= 0) && Math.min(nn.length, norm.length) >= 4) {
        return { label: lab, rows: OFFICIAL_LAYOUTS[k] };
      }
    }
  }
  return null;
}
function layoutRowsFor(caseType, docType) {
  const m = layoutMatchFor(caseType, docType);
  return m ? m.rows : null;
}
/* ==================== 官方要素行 → 内容映射 ====================
   三级来源，逐级兜底：
   ① data.elements：AI/表单按官方要素行标签给出的内容（最准，直接对应模板行）
   ② 案由要素（data.facts）+ 诉讼请求/证据/依据：按行标签关键词映射
   ③ 模板原文：以上都没有时保持官方空白模板原样（不编造）
*/
const ELEM_BOX_OPTIONS = [
  '不申请', '不同意', '不了解', '不主张', '暂不确定，想要了解更多内容',
  '连带责任保证', '一般保证', '到期一次性还本付息', '按月计息、到期一次性还本',
  '按季计息、到期一次性还本', '按年计息、到期一次性还本',
  '一般授权', '特别授权', '正式登记', '预告登记', '现金', '转账',
  '是', '否', '有', '无', '了解', '同意', '申请', '主张'
];

function elemElementValue(label, elements) {
  if (!elements) return '';
  const n = elemNormKey(label);
  if (!n) return '';
  const nShort = n.replace(/^\d+/, '');
  let loose = '';
  for (const k in elements) {
    const raw = elements[k];
    if (raw === undefined || raw === null || String(raw).trim() === '') continue;
    const nk = elemNormKey(k);
    if (!nk) continue;
    if (nk === n) return String(raw).trim();
    const kShort = nk.replace(/^\d+/, '');
    if (kShort && kShort === nShort && nShort.length >= 2) return String(raw).trim();
    if (!loose && (nk.indexOf(n) >= 0 || n.indexOf(nk) >= 0) && Math.min(n.length, nk.length) >= 3) {
      loose = String(raw).trim();
    }
  }
  return loose;
}

/* 勾选型行：把“是/否/了解/不了解/现金/转账/一般保证”等选项打勾 */
function elemApplyChoice(content, value) {
  const c = String(content || '');
  const v = String(value || '').trim();
  if (!v || c.indexOf('□') < 0) return content;
  const notBefore = { '否': '是', '无': '有', '了解': '不', '申请': '不', '主张': '不', '同意': '不' };
  let marked = c;
  for (const opt of ELEM_BOX_OPTIONS) {
    const at = v.indexOf(opt);
    if (at < 0) continue;
    const prev = at > 0 ? v[at - 1] : '';
    const next = v[at + opt.length] || '';
    if (next === '□') continue;                       // 模板原文里的未选框，不算选中
    if (prev === '不' && opt.length <= 2 && opt !== '不') continue; // 不主张/不同意/不了解
    if (notBefore[opt] && prev === notBefore[opt]) continue;        // 是否/有无/是否了解
    const next2 = elemMarkOptionBox(marked, opt);
    if (next2 !== marked) { marked = next2; break; }
  }
  // 值里说的是“是/否”，而模板用的是“有/无”（或反之）时，按极性勾对应的框
  if (marked === c) {
    const pos = /^(是|有|同意|了解|已|主张|申请|存在)/.test(v);
    const neg = /^(否|无|不|未|没有|不存在)/.test(v);
    const posWords = ['是', '有', '同意', '了解', '已', '主张', '申请', '存在'];
    const negWords = ['否', '无', '不了解', '不同意', '未', '不存在', '没有'];
    if (pos) for (const w of posWords) { const n2 = elemMarkOptionBox(marked, w); if (n2 !== marked) { marked = n2; break; } }
    if (neg && marked === c) for (const w of negWords) { const n2 = elemMarkOptionBox(marked, w); if (n2 !== marked) { marked = n2; break; } }
  }
  return marked;
}

/* 依据行内自带的选项名自动打勾：内容里“本金□／一般债务利息□／判决书□”等，
   只要 AI 给的内容提到该选项就勾上（值若只是模板原文，调用方已提前跳过）。 */
function elemAutoMarkBoxes(content, value) {
  const c = String(content || '');
  const v = String(value || '');
  if (!v || c.indexOf('□') < 0) return c;
  // 当事人角色类选项（原告/被告/其他…）不自动勾选：归属到底归谁要看逐项正文，勾错反而误导
  const roleWords = ['原告', '被告', '第三人', '申请人', '被申请人', '申请执行人', '被执行人', '赔偿请求人', '赔偿义务机关', '答辩人', '被答辩人', '甲方', '乙方', '其他'];
  let out = c;
  const re = /([\u4e00-\u9fa5A-Za-z、，/]{2,14})□/g;
  const done = {};
  let m;
  while ((m = re.exec(c)) !== null) {
    const opt = m[1];
    if (done[opt]) continue;
    if (roleWords.indexOf(opt) >= 0) continue;
    const at = v.indexOf(opt);
    if (at < 0) continue;
    if (v[at + opt.length] === '□') continue; // 值里也是未勾选的模板原文
    const boxAt = out.indexOf(opt + '□');
    if (boxAt >= 0) {
      // 命中位置若紧跟在汉字后面，说明它是更长选项的后缀（如“判决书”落在“刑事附带民事判决书□”里）→ 跳过
      const prev = out[boxAt - 1] || '';
      if (/[\u4e00-\u9fa5]/.test(prev)) continue;
    }
    const next2 = elemMarkOptionBox(out, opt);
    if (next2 !== out) { out = next2; done[opt] = 1; }
  }
  return out;
}

/* “无财产□／有财产□”“无债务□／有债务□”“无此问题□／有此问题□”这类成对选项：
   有实质内容就勾“有…”，写明“无/没有”就勾“无…” */
function elemMarkPairedChoice(content, value) {
  const c = String(content || '');
  const v = String(value || '').trim();
  if (!c || !v) return c;
  const neg = /^(无|没有|不存在|不主张)/.test(v);
  let out = c;
  [['财产', '无财产□', '有财产□'], ['债务', '无债务□', '有债务□'], ['此问题', '无此问题□', '有此问题□']].forEach(([, noBox, yesBox]) => {
    const box = neg ? noBox : yesBox;
    const word = box.slice(0, -1);
    if (out.indexOf(box) < 0 && out.indexOf('□' + word) < 0) return;
    const substantive = neg || v.replace(/[\s\u00a0]/g, '').length >= 4;
    if (!substantive) return;
    out = elemMarkOptionBox(out, word);
  });
  return out;
}

/* 行内含“标签：”空槽（如“合同约定：  法律规定：”）时，按值里的键值对回填 */
function elemFillFromPairs(content, value) {
  const t = String(content || '');
  const v = String(value || '');
  if (!v || t.indexOf('：') < 0) return content;
  let out = t;
  let touched = false;
  for (const seg of v.split(/[\n；;，,]+/)) {
    const i = seg.search(/[：:]/);
    if (i <= 0) continue;
    const lab = seg.slice(0, i).trim().replace(/^\d+[.、)]*\s*/, '');
    const val = seg.slice(i + 1).trim();
    if (!lab || !val || lab.length > 16) continue;
    const nt = fillCellAfter(out, lab, val);
    if (nt !== out) { out = nt; touched = true; }
  }
  return touched ? out : content;
}

/* 行内空白槽（“尚欠本金　　元”“截至　年　月　日止”）按值回填 */
function elemFillSlots(content, value) {
  const c = String(content || '');
  const v = String(value || '').trim();
  if (!v) return content;
  let out = c;
  const amounts = v.match(/[0-9][0-9,，.]*\s*元/g) || [];
  const dates = v.match(/\d{4}\s*年\s*\d{1,2}\s*月(?:\s*\d{1,2}\s*日)?/g)
    || v.match(/\d{4}[-\/.]\d{1,2}(?:[-\/.]\d{1,2})?/g) || [];
  if (amounts.length && /尚欠本金\s*元/.test(out)) {
    out = out.replace(/尚欠本金\s*元/, '尚欠本金' + amounts[0].replace(/\s*元$/, '') + '元');
  }
  if (amounts.length && /尚欠利息\s*元/.test(out) && /尚欠本金/.test(v) === false) {
    out = out.replace(/尚欠利息\s*元/, '尚欠利息' + amounts[0].replace(/\s*元$/, '') + '元');
  }
  if (dates.length && /截至\s*年\s*月\s*日/.test(out)) {
    out = out.replace(/截至\s*年\s*月\s*日\s*止/, '截至' + dates[0].trim() + '止');
  }
  if (dates.length && /年\s*月\s*日/.test(out)) {
    out = out.replace(/年\s*月\s*日/, dates[0].trim());
  }
  // “金额：”空槽（离婚损害赔偿／经济补偿／经济帮助等）
  if (amounts.length && /金额[：:]/.test(out)) {
    out = out.replace(/金额[：:][ \t\u00a0]*/, '金额：' + amounts[0].trim());
  }
  // “元（人民币，下同…）”这类前置空槽（给付价款行）：把金额放到“元”前面
  if (amounts.length && /^[ \t\u00a0]*元/.test(out)) {
    out = out.replace(/^[ \t\u00a0]*元/, amounts[0].trim());
  }
  if (out === c && dates.length && /是否到期/.test(out)) {
    out = out.replace(/是否到期：\s*是□/, '是否到期：是☑');
  }
  if (out === c && v.length <= 10) {
    // 通用：把“标签 　 值单位”中的空白替换成值（仅短值，避免整段事实塞进空槽）
    const slot = out.match(/([\u4e00-\u9fa5]{2,8})[ \u00a0_＿]{1,}(?=[元日年月止，。；）)])/);
    if (slot) out = out.slice(0, slot.index) + slot[1] + v + out.slice(slot.index + slot[0].length);
  }
  return out;
}

/* 复核文本里往往重复带上了模板原文：只取模板之外新增的内容 */
function elemStripPrefix(content, value) {
  const t = String(value || '');
  if (!t) return t;
  const c = String(content || '');
  if (!c.trim()) return t;
  const rw = /[\s\u00a0\u23ce]/;
  if (t.indexOf(c) === 0) return t.slice(c.length).replace(/^[\s\u00a0\u23ce]+/, '');
  const nc = c.replace(/[\s\u00a0\u23ce]/g, '');
  let i = 0, j = 0;
  while (i < t.length && j < nc.length) {
    if (rw.test(t[i])) { i++; continue; }
    if (t[i] !== nc[j]) break;
    i++; j++;
  }
  if (j === nc.length) return t.slice(i).replace(/^[\s\u00a0\u23ce]+/, '');
  // 值里把左侧标签（含括号注释）也一起返回时，从模板正文出现处截断
  const firstLine = c.split('\n')[0].trim();
  if (firstLine) {
    const idx = t.indexOf(firstLine);
    if (idx > 0) {
      const head = t.slice(0, idx).trim();
      // 只有前面的确是“标签：”这样的抬头（如“文书类型（注：…）：”）才截断，
      // 否则会把“86000元”这类正文前缀误删
      if (/[：:]$/.test(head) || /[）)]$/.test(head)) return t.slice(idx);
    }
  }
  return t;
}
function elemApplyRowValue(content, value, label) {
  const c = String(content || '');
  let v = elemStripPrefix(c, String(value || '').trim() || '').trim();
  if (!v) return c; // 复核文本只是模板原文（该行没填内容）
  const bare = s => String(s || '').replace(/[\s\u00a0]/g, '');
  const choiceLike = /^(是|否|有|无|了解|不|同意|申请|主张|一般授权|特别授权|现金|转账|正式登记|预告登记|到期一次性|按月计息|按季计息|按年计息|暂不确定)/.test(v);
  const bareC = bare(c);
  let bareV = bare(v);
  if (bareV && bareC && bareV === bareC) return c; // 与模板一致（该行没填东西）
  // 非勾选型的成段内容已在该行内时不重复叠加（“否/是”这类短勾选词除外）
  if (!choiceLike && v.length >= 4 && bareC) {
    const at = bareC.indexOf(bareV);
    // 命中处若正好是模板里的某个未勾选项（如值“民事判决书”撞上“刑事附带民事判决书□”），
    // 不算“已填写”，继续走后面的打勾逻辑
    if (at >= 0 && !/^[□☑]/.test(bareC.slice(at + bareV.length))) return c;
  }
  const n = elemNormKey(label || '');
  const hasBox = c.indexOf('□') >= 0;
  const choiceRow = hasBox && /是否|有无|了解|先行调解|授权|登记|还款方式|提供方式|类型|所有制/.test(n);
  // AI 直接给了整行成品（含勾选框且覆盖模板原文）→ 采用；否则只把它当内容，
  // 避免模型自己写个“☑ …”就把官方模板原有栏目（无财产□／有财产□…）整行顶掉
  if (/[☑]/.test(v) && v.length >= 8) {
    const uniqC = Array.from(new Set(bareC.split('')));
    const cover = uniqC.length ? uniqC.filter(ch => bareV.indexOf(ch) >= 0).length / uniqC.length : 0;
    if (cover >= 0.6) return v;
    v = v.replace(/^[☑✓√\s]+/, '').trim();
    if (!v) return c;
    bareV = bare(v);
  }
  // 值里已经覆盖模板大部分文字（例如按模板补全了空格的整句）→ 视为整行成品，直接替换
  if (!hasBox && bareC.length >= 8) {
    const uniq = Array.from(new Set(bareC.split('')));
    const hit = uniq.filter(ch => bareV.indexOf(ch) >= 0).length;
    if (bareV.length >= bareC.length * 0.6 && hit / uniq.length >= 0.85) return v;
  }
  let out = elemApplyChoice(c, v);
  out = elemAutoMarkBoxes(out, v);
  out = elemMarkPairedChoice(out, v);
  if (choiceRow) {
    const filled = elemFillSlots(out, v);
    if (filled !== c || filled !== out) return filled;
    // 选项行但素材给的是一段叙述（如还款方式、迟延情形）→ 保留官方选项，另起一行写明
    const isPolarityRow = /^(是否|有无)/.test(n.replace(/^\d+[.．、]?/, ''));
    return (!isPolarityRow && v.replace(/[☑]/g, '').length >= 6) ? out + '\n' + v : out;
  }
  const beforeSlots = out;
  out = elemFillFromPairs(out, v);
  out = elemFillSlots(out, v);
  if (!c.trim()) return out || v;
  if (bare(out).indexOf(bareV) >= 0) return out;   // 正文已经在行内
  // 行里已有“归属/明细/情况”等明细区，或金额类空槽已被填 → 保留模板再补正文；
  // 纯金额/表态行（如离婚损害赔偿）只勾选+填金额，理由写在事实与理由，避免同一段话重复
  const amountConsumed = /金额[：:]\s*\d/.test(out) && amounts(v).length > 0;
  if (amountConsumed && beforeSlots !== c) return out;
  if (hasBox || c.trim().length >= 16) return out + '\n' + v;
  return v.length >= 12 ? v : out + v;
}

function amounts(s) {
  return String(s || '').match(/[0-9][0-9,，.]*\s*(?:元|万元)/g) || [];
}

/* 表态类行只在"素材里能确认"时才勾选：确认不了就留空，由当事人自己勾。
   这些规则不接受"没提到就默认否/无"的猜测。 */
const ELEM_ROW_DEFAULTS = [
  // 素材明确提到 → 勾"是/有"；没提到 → 不动（留空）
  [/是否要求提前还款|提前还款/, (t) => (/提前还款|加速到期|解除合同/.test(t) ? '是' : '')],
  [/是否主张担保权利/, (t) => (/担保|抵押|质押|保证|优先受偿/.test(t) ? '是' : '')],
  [/是否主张实现债权的费用/, (t) => (/律师费|实现债权的费用|保全费|公告费/.test(t) ? '是' : '')],
  [/是否主张诉讼费用/, (t) => (/诉讼费|案件受理费/.test(t) ? '是' : '')],
  [/有无仲裁|法院管辖约定/, (t) => (/仲裁|管辖约定|协议管辖|约定管辖/.test(t) ? '有' : '')],
  [/是否已经诉前保全/, (t) => (/诉前保全|财产保全|保全/.test(t) ? '是' : '')],
  [/是否签订物的担保|是否最高额担保|是否办理抵押|质押登记|是否签订保证合同|其他担保方式/, (t) => (/担保|抵押|质押|保证/.test(t) ? '是' : '')],
  [/担保人|担保物/, (t) => (/担保|抵押|质押|保证/.test(t) ? '' : '')],
  [/是否存在逾期还款/, (t) => (/逾期|未还|未付|欠付|拒付|违约/.test(t) ? '是' : '')],
  [/是否存在迟延履行/, (t) => (/逾期|迟延|未付|未付款|拖欠|未按期/.test(t) ? '是' : '')],
  [/是否催促过履行/, (t) => (/催促|催告|催收|催要|催款|多次要求/.test(t) ? '是' : '')],
  [/其他请求$/, () => ''],
  [/^\d*[.．、]?\s*其他$/, () => ''],
  [/其他需要说明的内容/, () => '']
];

function elemDefaultForRow(label, data) {
  const n = elemNormKey(label);
  if (!n) return '';
  const text = [
    (data.claims || []).join(' '),
    (data.facts || []).map(f => (f.label || '') + ' ' + (f.content || '')).join(' '),
    (data.evidence || []).map(e => typeof e === 'string' ? e : (e && e.name) || '').join(' ')
  ].join(' ');
  for (const [re, fn] of ELEM_ROW_DEFAULTS) {
    if (re.test(n)) return fn(text) || '';
  }
  return '';
}

/* 行标签 → 案由要素（data.facts）关键词映射，覆盖各案由通用骨架 */
const ELEM_ROW_FACT_HINTS = [
  [/合同签订情况|签订情况|合同情况|协议情况|合同名称/, ['合同签订', '借款时间地点金额', '合同情况', '租赁合同', '签约']],
  [/签订主体|合同主体|买卖双方/, []],   // 由当事人字段直接填（出卖人/买受人、出租人/承租人…）
  /* —— 买卖合同 / 租赁等合同类案由的要素行 —— */
  [/标的物|标的|货物|商品|品名|规格|数量|单价|总价|价款|价格|货款|付款方式|支付方式/, ['标的物数量金额', '货物情况', '标的物情况', '价款', '履行情况']],
  [/交货|交付|供货|发货|验收|安装|调试|风险承担|运输|质量/, ['履行情况', '交付情况', '验收情况', '标的物数量金额']],
  [/催促|催告|催收|催要|催款/, ['催告情况', '催收情况', '履行情况', '违约情况']],
  [/违约金|定金|迟延履行|逾期/, ['被告违约情况', '违约情况', '逾期情况']],
  [/利息|赔偿金|损失/, ['损失情况', '损失', '被告违约情况']],
  [/本金|借款金额|借款数额|欠款金额|欠费|欠款|货款|金额|标的额|数额/, ['借款时间地点金额', '标的总额', '欠款', '欠费', '金额', '货款', '租金']],
  [/借款期限|租期|期限|履行期限|交货期限/, ['还款约定', '借款期限', '租赁期限', '合同约定', '履行']],
  [/借款利率|利率|利息|违约金|滞纳金/, ['还款约定', '利息', '利率', '违约金', '逾期']],
  [/借款提供时间|提供时间|交付时间|付款时间|支付情况/, ['借款时间地点金额', '交付', '支付', '付款']],
  [/还款方式|还款情况|履行情况|已还/, ['还款约定', '还款情况', '履行情况', '还款']],
  [/逾期|违约/, ['逾期情况', '违约情况', '违约', '逾期']],
  [/担保|保证|抵押|质押/, ['担保情况', '抵押', '质押', '保证']],
  [/保全/, ['保全情况', '保全']],
  [/仲裁|管辖|约定/, ['管辖', '仲裁']],
  [/调解|和解/, ['调解', '和解']],
  [/其他需要说明|其他需要列明|其他情况/, ['其他', '需要说明']],
  /* —— 婚姻家庭 / 财产 / 债务 / 抚养 / 赔偿类要素行（离婚、婚约财产、共有物分割等案由的骨架） —— */
  [/财产|房产|房屋|门面|商铺|不动产|存款|车辆|汽车|股权|股票|基金|债权|分割/, ['共同财产分割请求', '夫妻共同财产', '财产情况', '共同财产', '房屋信息', '标的物情况']],
  [/债务|欠款|负债/, ['共同债务情况', '夫妻共同债务', '债务情况', '债务']],
  [/抚养|子女|探望|监护/, ['子女抚养/抚养费/探望权', '子女情况', '抚养']],
  [/赔偿|补偿|帮助|损害/, ['赔偿/补偿/帮助', '赔偿', '补偿', '损失情况', '损失']],
  [/解除婚姻|婚姻关系解除/, []],                          // 解除婚姻关系行：用诉讼请求里的原文，不套用结婚时间等事实
  [/婚姻|结婚|感情|分居|离婚事由/, ['结婚时间地点', '夫妻感情破裂原因', '分居情况', '婚姻关系']],
  [/事实经过|事实与理由|纠纷发生|事情经过/, ['事实', '经过', '情况']]
];

/* 案由要素对不上时，从"诉讼请求"里取对应那一项（传统诉状的请求项通常写得很完整） */
function elemRowValueFromClaims(label, data) {
  const claims = (data.claims || []).map(s => String(s || '').trim()).filter(Boolean);
  const n = elemNormKey(label);
  if (!n || !claims.length) return '';
  const groups = [
    [/财产|房产|房屋|门面|商铺|不动产|存款|车辆|汽车|股权|股票|基金|分割/, ['财产', '房产', '房屋', '门面', '商铺', '存款', '车辆', '股权', '分割', '共有']],
    [/债务|欠款|负债/, ['债务', '欠款', '借款']],
    [/抚养|子女|探望/, ['抚养', '探望', '子女']],
    [/赔偿|补偿|帮助|损害/, ['赔偿', '补偿', '帮助', '损害']],
    [/解除婚姻|婚姻关系/, ['解除婚姻关系', '解除', '婚姻']],
    [/违约金|定金/, ['违约金', '定金']],
    [/利息|损失|赔偿/, ['利息', '损失', '赔偿']],
    [/继续履行|解除合同/, ['继续履行', '解除合同']],
    [/标的物|标的|货物|交货|交付|验收|价款|货款|付款|支付/, ['货款', '价款', '货物', '交付', '验收', '支付']],
    [/诉讼费用|诉讼费/, ['诉讼费', '诉讼费用']]
  ];
  for (const [re, keys] of groups) {
    if (!re.test(n)) continue;
    const hit = claims.find(c => keys.some(k => c.indexOf(k) >= 0));
    if (hit) return hit;
  }
  return '';
}

/* —— 通用兜底：按行标题里的关键词，去案由要素/诉讼请求里找最相关的一条 ——
   各案由官方要素行叫法差异很大（医疗费、护理费、物业费、工程款、停止侵权…），
   逐个枚举不现实；这里用"行标题关键词 × 要素/请求文本"打分匹配，覆盖所有案由。 */
const ELEM_STOP_WORDS = ['是否', '有无', '情况', '相关', '内容', '其他', '以及', '或者', '包括', '列明', '填写',
  '主张', '请求', '本案', '事实', '理由', '具体', '上述', '怎么', '如何', '什么', '注明', '写明', '以下'];

function elemKeywords(label) {
  // 官方有些行标题是逐字加空格的（“合 同 的 签 订 情 况”），先合并汉字之间的空格
  let s = String(label || '').replace(/([\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])/g, '$1');
  s = s.replace(/^\s*\d+[.．、]?\s*/, '');
  s = s.replace(/[（(][^）)]*[）)]/g, ' ');
  const parts = s.split(/[\s、，,。；;：:\/]+/).filter(Boolean);
  const out = [];
  parts.forEach(p => {
    if (p.length >= 2 && ELEM_STOP_WORDS.indexOf(p) < 0) out.push(p);
    if (p.length >= 5) {
      for (let i = 0; i + 3 <= p.length; i += 2) {
        const w = p.slice(i, i + 3);
        if (ELEM_STOP_WORDS.indexOf(w) < 0) out.push(w);
      }
    }
  });
  return out.filter((w, i) => out.indexOf(w) === i && w.length >= 2);
}

function elemRowValueGeneric(label, data) {
  const keys = elemKeywords(label);
  if (!keys.length) return '';
  const pool = [];
  (data.facts || []).forEach(f => {
    const text = String(f.content || '').trim();
    if (text) pool.push({ lab: String(f.label || ''), text: text });
  });
  (data.claims || []).forEach(c => {
    const text = String(c || '').trim();
    if (text) pool.push({ lab: '', text: text });
  });
  (data.evidence || []).forEach(e => {
    const text = typeof e === 'string' ? e : (e && e.name) || '';
    if (text) pool.push({ lab: '', text: String(text), weak: true });
  });
  let best = null;
  pool.forEach(it => {
    const hay = it.lab + ' ' + it.text;
    let score = 0;
    keys.forEach(k => { if (hay.indexOf(k) >= 0) score += k.length * (it.weak ? 0.5 : 1); });
    if (score > 0 && (!best || score > best.score)) best = { score: score, text: it.text };
  });
  // 行标题本身很短、只有一两个专有名词（本金、医疗费、物业费、理赔款…）时，命中一个即可；
  // 长标题要求至少两个词命中，避免误扣
  const need = keys.length <= 2 ? 2 : 4;
  if (best && best.score >= need) return best.text;
  return '';
}

function elemRowValueFromFacts(label, data) {
  const facts = (data.facts || []).filter(f => f && String(f.content || '').trim());
  const n = elemNormKey(label);
  if (!n || !facts.length) return '';
  for (const [re, keys] of ELEM_ROW_FACT_HINTS) {
    if (!re.test(n)) continue;
    if (!keys.length) return '';
    for (const key of keys) {
      const nk = elemNormKey(key);
      const hit = facts.find(f => elemNormKey(f.label || '').indexOf(nk) >= 0);
      if (hit) return String(hit.content || '').trim();
    }
  }
  return '';
}

function fillLayoutContent(label, content, data, elements) {
  const side = elemPartySide(label);
  let t = String(content || '');
  const basis = (data.facts || []).find(f => elemNormKey(f.label).indexOf('依据') >= 0);
  const total = (data.facts || []).find(f => elemNormKey(f.label).indexOf('标的总额') >= 0);
  const n = elemNormKey(label);
  const pl = data.plaintiff || {};
  const df = data.defendant || {};
  // 官方表头的“案号 / 案由”行：案由自动带上本案案由，案号留空由法院/当事人填写
  if (n === '案由') {
    const ct = String(data.caseType || '').trim();
    if (ct && !t.trim()) t = ct;
    return t;
  }
  if (n === '案号') return t;
  // 结构化字段（当事人、标的总额、请求依据、证据清单、签订主体）填好后不再叠加 AI 整段文字，
  // 否则真实模型会把同一行内容写两遍（例如当事人自然人行后面再跟一句“姓名：张…，身份证号…”）。
  let ownFilled = false;
  if (side === 'P') { t = fillPartyLayoutCell(label, t, pl); ownFilled = !!(pl.name || pl.creditCode); }
  else if (side === 'D') { t = fillPartyLayoutCell(label, t, df); ownFilled = !!(df.name || df.creditCode); }
  if (n.includes('标的总额') && total) {
    const v = String(total.content || '').trim();
    if (v) { t = v; ownFilled = true; }
  }
  if (n.includes('依据')) {   // 请求依据／答辩依据／请求承担责任的依据…都用同一处法律依据
    if (basis) {
      const v = String(basis.content || '').trim();
      if (v) { t = t.replace(/(法律规定：)\s*/, '$1' + v); ownFilled = true; }
    }
  }
  if (n.includes('证据清单') && data.evidence && data.evidence.length) {
    const lines = data.evidence.map((e, i) => (i + 1) + '. ' + (typeof e === 'string' ? e : (e.name || JSON.stringify(e))));
    t = t && t.trim() ? t + '\n' + lines.join('\n') : lines.join('\n');
    ownFilled = true;
  }
  if (n.includes('签订主体')) {
    ownFilled = !!(pl.name || df.name);
  }
  if (n.includes('签订主体') || n.includes('合同主体')) {
    // 官方各行叫法不一：出卖人（卖方）/买受人（买方）、出租人/承租人、出借人/借款人…
    ['出卖人（卖方）', '出卖人', '卖方', '出租人', '出借人', '发包人', '甲方', '委托人'].forEach(lab => {
      t = fillCellAfter(t, lab, pl.name || '');
    });
    ['买受人（买方）', '买受人', '买方', '承租人', '借款人', '承包人', '乙方', '受托人'].forEach(lab => {
      t = fillCellAfter(t, lab, df.name || '');
    });
    ownFilled = ownFilled || !!(pl.name || df.name);
  }
  // ① 官方要素行内容（AI 提取 / 表单填写）② 案由要素按行关键词兜底 ③ 未提及行的常规默认勾选
  const elemVal = elemElementValue(label, elements);
  const factVal = elemVal ? '' : elemRowValueFromFacts(label, data);
  const claimsVal = (elemVal || factVal) ? '' : elemRowValueFromClaims(label, data);
  const genericVal = (elemVal || factVal || claimsVal) ? '' : elemRowValueGeneric(label, data);
  let value = elemVal || factVal || claimsVal || genericVal;
  // “是否催促过履行”行：素材里没有“催”的事实就不要把交货日期等塞进催促时间
  if (value && /催促|催告/.test(n) && !/催/.test(value)) value = '';
  if (value && !ownFilled) {
    const applied = elemApplyRowValue(t, value, label);
    if (applied && applied.trim() !== t.trim()) t = applied;
  }
  const def = elemDefaultForRow(label, data);
  if (def) {
    const applied = elemApplyRowValue(t, def, label);
    if (applied && applied.trim() !== t.trim()) t = applied;
    else if (!t.trim()) t = def;
  }
  // 说明：表态类行（是否…/有无…）不再做"没提到就默认否/无"的猜测——
  // 素材里能确认的才勾选，确认不了的保持空白，由当事人自己勾。
  // 利息行：请求支付至实际清偿之日止的勾选
  if (/利息/.test(n) && /是否请求支付至实际清偿之日止/.test(t)) {
    const all = [(data.claims || []).join(' '), (data.facts || []).map(f => f.content || '').join(' ')].join(' ');
    if (/实际清偿之日|清偿之日|付清之日|实际给付之日/.test(all)) {
      t = t.replace(/是否请求支付至实际清偿之日止：\s*是□/, '是否请求支付至实际清偿之日止：是☑');
    }
  }
  if (typeof process !== 'undefined' && process.env && process.env.DBG_ROW) {
    console.log('[dbg] ' + label.replace(/\n/g, '') + ' | value=' + String(value).slice(0, 30) + ' | own=' + ownFilled + ' | t=' + String(t).replace(/\n/g, '/').slice(0, 70));
  }
  return t;
}
function fillLayoutRows(rows, data) {
  const out = [];
  const elements = data.elements || null;
  const claimsTxt = (data.claims || []).map((c, i) => (i + 1) + '. ' + String(c).replace(/^\d+[.、)]*\s*/, '')).join('\n');
  const factLines = (data.facts || []).map(f => {
    const c = String(f.content || '').trim();
    if (!c) return '';
    const n = elemNormKey(f.label || '');
    if (n.includes('依据') || n.includes('标的总额')) return '';
    return (f.label ? '【' + f.label + '】' : '') + c;
  }).filter(Boolean).filter((line, idx, arr) => {
    // 同一段内容被模型重复返回（factFields 与 factReason 同时给出）时只保留一次
    const body = elemNormKey(line.replace(/^【[^】]*】/, ''));
    if (body.length < 12) return true;
    return arr.findIndex(x => elemNormKey(x).indexOf(body) >= 0) === idx;
  });
  for (const r of rows) {
    const k = r[0];
    if (k === 's') {
      const text = r[1] || '';
      const n = elemNormKey(text);
      const noteRow = /可完整表述|可概括描述/.test(n);
      if (noteRow) {
        const useFacts = /事实与理由|纠纷涉及/.test(n);
        const body = useFacts ? (factLines.join('\n') || claimsTxt) : (claimsTxt || factLines.join('\n'));
        if (body) { out.push(['s', body]); continue; }
      }
      out.push(['s', text]);
    } else if (k === 'r') {
      out.push(['r', r[1] || '', fillLayoutContent(r[1] || '', r[2] || '', data, elements)]);
    } else {
      out.push(r);
    }
  }
  return out;
}
/* 官方要素行清单：供 AI 提示、表单复核、缺失审计使用 */
function elemModeDocType(caseType, mode) {
  const m = mode || ((typeof currentDraft !== 'undefined' && currentDraft && currentDraft.mode) || 'complaint');
  const dt = (typeof docTypeForMode === 'function') ? docTypeForMode(m, caseType) : '';
  if (dt) return dt;
  if (m === 'answer') return 'answer';
  if (m === 'exec') return 'exec';
  return 'complaint';
}
function elemLayoutFor(caseType, docType) {
  const dt = docType || elemModeDocType(caseType);
  const m = layoutMatchFor(caseType, dt);
  return m ? m.rows : null;
}
function elemOfficialRowList(caseType, docType) {
  const layout = elemLayoutFor(caseType, docType);
  if (!layout || !layout.length) return [];
  const out = [];
  for (const r of layout) {
    if (r[0] !== 'r') continue;
    out.push({ label: String(r[1] || '').replace(/\n/g, ''), template: String(r[2] || '') });
  }
  return out;
}
/* 按 mode 推断 docType 后取官方要素行标签（供 AI 提示用） */
function elemOfficialRowLabels(caseType, mode) {
  const m = mode || ((typeof currentDraft !== 'undefined' && currentDraft && currentDraft.mode) || 'complaint');
  const dt = (typeof docTypeForMode === 'function') ? docTypeForMode(m, caseType) : '';
  const list = elemOfficialRowList(caseType, dt);
  const seen = {};
  const out = [];
  list.forEach(r => { if (r.label && !seen[r.label]) { seen[r.label] = 1; out.push(r.label); } });
  return out;
}
/* 供表单复核的“官方要素行：内容”文本（一行一项，换行用 ⏎ 表示） */
function officialRowsTextFromDoc(data) {
  const dt = elemModeDocType(data.caseType);
  const lm = layoutMatchFor(data.caseType, dt);
  if (!lm || !lm.rows || !lm.rows.length) return '';
  const filled = fillLayoutRows(lm.rows, data);
  return filled.filter(r => r[0] === 'r')
    .map(r => String(r[1] || '').replace(/\n/g, '') + '：' + String(r[2] || '').replace(/\n/g, ' ⏎ '))
    .join('\n');
}
function parseOfficialRowsText(text) {
  const elements = {};
  String(text || '').split('\n').forEach(line => {
    // 标签里可能自带“：”（如“文书类型（注：1.行政处罚决定…）”），只在括号外的第一个冒号处切分
    let depth = 0;
    let i = -1;
    for (let k = 0; k < line.length; k++) {
      const ch = line[k];
      if ('（(【['.indexOf(ch) >= 0) depth++;
      else if ('）)】]'.indexOf(ch) >= 0) depth = Math.max(0, depth - 1);
      else if ((ch === '：' || ch === ':') && depth === 0) { i = k; break; }
    }
    if (i <= 0) return;
    const label = line.slice(0, i).trim();
    const value = line.slice(i + 1).replace(/\s*⏎\s*/g, '\n').trim();
    if (label) elements[label] = value;
  });
  return elements;
}
/* 缺失项审计：哪些官方要素行既没有 AI 内容、也没有案由要素、模板本身还是空的 */
function officialRowAudit(caseType, docType, data) {
  const list = elemOfficialRowList(caseType, docType);
  const missing = [];
  const hasBasis = (data.facts || []).some(f => elemNormKey(f.label || '').indexOf('依据') >= 0);
  const hasTotal = (data.facts || []).some(f => elemNormKey(f.label || '').indexOf('标的总额') >= 0);
  list.forEach(row => {
    const n = elemNormKey(row.label);
    const fromElem = elemElementValue(row.label, data.elements);
    const fromFact = elemRowValueFromFacts(row.label, data);
    const hasParty = !!elemPartySide(row.label) && !!(data.plaintiff && (data.plaintiff.name || data.defendant.name));
    const templateHasText = !!String(row.template || '').trim();
    const specialFilled = (n.indexOf('标的总额') >= 0 && hasTotal)
      || (n.indexOf('依据') >= 0 && hasBasis)
      || (n.indexOf('证据清单') >= 0 && (data.evidence || []).length > 0)
      || (n.indexOf('签订主体') >= 0 && !!(data.plaintiff && data.plaintiff.name));
    if (!fromElem && !fromFact && !hasParty && !templateHasText && !specialFilled) missing.push(row.label);
  });
  return { total: list.length, missing: missing };
}
function escBr(s) {
  return escHtml(s).split('\n').join('<br>');
}
function splitOfficialTitle(title) {
  const t = String(title || '');
  const i = t.lastIndexOf('（');
  if (i > 0) return [t.slice(0, i).trim(), t.slice(i).trim()];
  return [t, ''];
}
const LAYOUT_CATEGORY_KEYS = ['当事人信息', '诉讼请求', '申请执行事项', '申请事项', '执行依据', '执行请求', '约定管辖和诉前保全',
  '事实与理由', '对纠纷解决方式的意愿', '答辩事项', '答辩请求', '证据清单', '请求事项', '赔偿请求', '赔偿事项', '复议请求',
  '对案件事实的确认或者异议'];
function isLayoutCategoryHeader(text) {
  const n = elemNormKey(text);
  if (!n || String(text).length > 40) return false;
  return LAYOUT_CATEGORY_KEYS.some(k => {
    const nk = elemNormKey(k);
    return n === nk || n.indexOf(nk) === 0;
  });
}
function flowNoteText(text) {
  const raw = String(text || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (!raw.length) return '';
  const paras = [];
  let cur = '';
  const startsNew = /^(★|（\d+[.．、]|\d+[.．、]|说明[：:])/;
  const flowLine = ln => {
    if (/^★.+★$/.test(ln) || /^说明[：:]$/.test(ln)) {
      if (cur) paras.push(cur);
      paras.push(ln);
      cur = '';
      return;
    }
    if (!cur) { cur = ln; return; }
    if (startsNew.test(ln)) { paras.push(cur); cur = ln; return; }
    cur += ln;
  };
  for (const ln of raw) flowLine(ln);
  if (cur) paras.push(cur);
  return paras.map(p => {
    if (/^★.+★$/.test(p)) return '<div class="note-star">' + escHtml(p) + '</div>';
    return '<div class="note-p">' + escHtml(p) + '</div>';
  }).join('');
}
function layoutRowsToHtml(title, rows, data) {
  const tp = splitOfficialTitle(title);
  // 内联样式：Word 打开 .doc 时对类选择器支持不稳，大项"放大+居中"必须写进单元格本身
  const TD = 'border:0.5pt solid #000;padding:2px 4px;vertical-align:top;font-size:10.5pt;font-family:仿宋,FangSong,SimSun,serif;';
  const SEC_STYLE = 'border:0.5pt solid #000;padding:4px;text-align:center;font-size:15pt;font-weight:400;font-family:方正小标宋_GBK,宋体,SimSun,serif;';
  let h = '<div class="elem-official-wrap"><div class="elem-official-title" style="text-align:center;font-size:22pt;font-weight:700;font-family:方正大标宋_GBK,宋体,SimSun,serif;">'
    + escBr(tp[0])
    + (tp[1] ? '<br><span class="elem-official-sub" style="display:inline-block;font-size:16pt;font-weight:400;font-family:方正小标宋_GBK,宋体,SimSun,serif;">' + escBr(tp[1]) + '</span>' : '')
    + '</div><table class="elem-official"><colgroup><col class="col-lab"><col class="col-val"></colgroup>';
  let signParts = [];
  for (const r of rows) {
    const k = r[0];
    if (k === 's') {
      const text = r[1] || '';
      const n = elemNormKey(text);
      const isNote = n.includes('说明') || text.indexOf('★') >= 0;
      const isNote2 = /可完整表述|可概括描述/.test(n);
      // 大项判定放宽：官方各类大项（当事人信息、诉讼请求、答辩事项、执行依据信息…）都是短整行，
      // 除说明区和"可完整表述…"提示外，20 字以内的整行按大项处理
      const isSection = !isNote && !isNote2
        && (isLayoutCategoryHeader(text) || (text.replace(/\s/g, '').length <= 20 && !/[。；;]/.test(text)));
      const cls = isNote ? 'note' : (isNote2 ? 'note2' : (isSection ? 'sec-ct' : ''));
      const body = isNote ? flowNoteText(text) : escBr(text);
      const style = isSection ? SEC_STYLE : (isNote ? (TD + 'text-align:justify;') : TD);
      h += '<tr class="sec-full ' + cls + '"><td colspan="2" style="' + style + '">' + body + '</td></tr>';
    } else if (k === 'r') {
      h += '<tr><td class="lab" style="' + TD + 'text-align:center;vertical-align:middle;">' + escBr(r[1]) + '</td>'
        + '<td class="val" style="' + TD + 'vertical-align:top;line-height:1.6;">' + escBr(r[2] || '') + '</td></tr>';
    } else if (k === 'sign') {
      signParts.push(r[1] || '');
    }
  }
  h += '</table>';
  if (signParts.length) {
    const sn = (data.signerName || '').trim();
    const sd = (data.signDate || '').trim();
    const signLabel = String(signParts[0] || '').replace(/[：:]\s*$/, '').trim() || '具状人（签字、盖章）';
    h += '<div class="elem-sign" style="padding:12px 4px 4px;font-size:15pt;line-height:1.8;text-align:left;font-family:方正小标宋_GBK,仿宋,FangSong,SimSun,serif;">'
      + '<div class="elem-sign-item">' + escHtml(signLabel) + '：' + escHtml(sn) + '</div>'
      + '<div class="elem-sign-item">日期：' + escHtml(sd) + '</div></div>';
  }
  h += '</div>';
  return h;
}
function layoutRowsToText(title, rows, data) {
  const lines = [title, ''];
  for (const r of rows) {
    const k = r[0];
    if (k === 's') lines.push((r[1] || '').split('\n').join('\n'));
    else if (k === 'r') lines.push((r[1] || '') + (r[2] ? '\n' + r[2] : ''));
    else if (k === 'sign') lines.push(r[1] || '');
  }
  if (data && data.signerName) lines.push('具状人（签字、盖章）：' + data.signerName);
  if (data && data.signDate) lines.push('日期：' + data.signDate);
  return lines.join('\n');
}

function buildOfficialElemDoc(data) {
  const hit = elemOfficialFind(data.caseType);
  const mode = (typeof currentDraft !== 'undefined' && currentDraft && currentDraft.mode) || 'complaint';
  const docType = (hit && hit.docType) || ((typeof docTypeForMode === 'function') ? docTypeForMode(mode, data.caseType) : '');
  const lm = layoutMatchFor((hit && (hit.key || data.caseType)) || data.caseType, docType);
  if (lm && lm.rows && lm.rows.length) {
    const filled = fillLayoutRows(lm.rows, data);
    const title = (hit && hit.tpl && (hit.tpl.title || hit.tpl.t)) || (lm.label + '（' + (data.caseType || '') + '）');
    return {
      html: layoutRowsToHtml(title, filled, data),
      text: layoutRowsToText(title, filled, data),
      official: true,
      layout: true,
      title: title,
      key: (hit && hit.key) || data.caseType || null,
      docType: docType || null,
      canonicalKey: (hit && hit.canonicalKey) || null
    };
  }
  if (!hit) return null;
  const rows = fillOfficialRows(hit.tpl, data);
  const title = hit.tpl.title || hit.tpl.t;
  return {
    html: rowsToHtml(title, rows),
    text: rowsToText(title, rows),
    official: true,
    title: title,
    key: hit.key || null,
    docType: hit.docType || null,
    canonicalKey: hit.canonicalKey || null
  };
}
