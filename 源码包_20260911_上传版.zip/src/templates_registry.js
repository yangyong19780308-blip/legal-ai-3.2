/* ==================== v3.3 模板注册表与匹配层（第二批） ==================== */
// 架构规则：
//   1) 全系统模板主键 canonicalKey = ${docType}:${normalizedCaseType}
//   2) 模糊匹配绝不跨 docType（exec:强制执行 与 admin_complaint:行政强制执行 完全隔离）
//   3) 国家赔偿必须走 compensation docType，禁止凭关键词决定模板类型
// 本批只做注册挂接：不重写 FACT_TEMPLATES / FACT_ALIASES / 67 案由映射 / 老工具规则；
// 不改变 53 套官方模板的渲染内容（findTemplate 返回与旧版相同的模板对象）。

const DOC_TYPE = {
  COMPLAINT: 'complaint',
  CRIMINAL: 'criminal_complaint',
  ADMIN: 'admin_complaint',
  ANSWER: 'answer',
  EXEC: 'exec',
  COMPENSATION: 'compensation',
  PETITION: 'petition',
  CHANGE: 'change',
  STATEMENT: 'statement',
  GENERIC: 'generic'
};

// 案由分组 → docType（CASE_TYPES 由构建脚本按官方索引生成）
const DOC_TYPE_GROUP_MAP = {
  '民事起诉状': DOC_TYPE.COMPLAINT,
  '刑事自诉状': DOC_TYPE.CRIMINAL,
  '行政起诉状': DOC_TYPE.ADMIN,
  '国家赔偿申请书': DOC_TYPE.COMPENSATION,
  '执行/申请类申请书': DOC_TYPE.EXEC,
  '答辩状': DOC_TYPE.ANSWER
};

// 案由分类修正：构建脚本把 2 个国家赔偿误归刑事自诉状，这里显式修正
const DOC_TYPE_OVERRIDES = {
  '刑事改判无罪赔偿': DOC_TYPE.COMPENSATION,
  '违法刑事拘留赔偿': DOC_TYPE.COMPENSATION
};

// 官方模板来源类型 → docType（最终模板补齐批次：新增执行/申请类、国家赔偿申请书、通用行政答辩状映射）
const OFFICIAL_TYPE_TO_DOC = {
  '民事起诉状': DOC_TYPE.COMPLAINT,
  '刑事（附带民事）自诉状': DOC_TYPE.CRIMINAL,
  '行政起诉状': DOC_TYPE.ADMIN,
  '强制执行申请书': DOC_TYPE.EXEC,
  '不予执行申请书': DOC_TYPE.EXEC,
  '暂时解除乘坐飞机、高铁限制措施申请书': DOC_TYPE.EXEC,
  '参与分配申请书': DOC_TYPE.EXEC,
  '执行担保申请书': DOC_TYPE.EXEC,
  '确认优先购买权申请书': DOC_TYPE.EXEC,
  '执行异议申请书': DOC_TYPE.EXEC,
  '执行复议申请书': DOC_TYPE.EXEC,
  '执行监督申请书': DOC_TYPE.EXEC,
  '国家赔偿申请书': DOC_TYPE.COMPENSATION,
  '行政答辩状': DOC_TYPE.ANSWER
};

// 应用名/常见叫法 → 官方案由名（同 docType 内显式登记，不靠模糊猜）
const NAME_ALIASES = {
  '建设工程合同纠纷': '建设工程施工合同纠纷',
  '交通事故': '机动车交通事故责任纠纷',
  '民间借贷': '民间借贷纠纷',
  '商标申请驳回复审行政纠纷': '商标申请驳回复审纠纷'
};

function normalizeCaseType(s) {
  return String(s || '').replace(/[\s，。、；：:（）()【】\[\]\/\\·\-—]/g, '').toLowerCase();
}

function docTypeOfCase(caseType) {
  const name = String(caseType || '');
  if (DOC_TYPE_OVERRIDES[name]) return DOC_TYPE_OVERRIDES[name];
  const groups = (typeof CASE_TYPES !== 'undefined' && CASE_TYPES) || [];
  for (const g of groups) {
    if (g.items && g.items.indexOf(name) >= 0) {
      return DOC_TYPE_GROUP_MAP[g.g] || DOC_TYPE.GENERIC;
    }
  }
  return DOC_TYPE.GENERIC;
}

// 从现有「mode / 文书类型」上下文取得 docType（第三批：docType 由调用上下文传入，不在匹配层猜）
// complaint 模式覆盖民事/刑事/行政起诉状，具体类别以案由归属为准（与现有下拉结构一致）
function docTypeForMode(mode, caseType) {
  const m = String(mode || 'complaint');
  if (m === 'complaint') {
    const dt = docTypeOfCase(caseType);
    return dt === DOC_TYPE.GENERIC ? DOC_TYPE.COMPLAINT : dt;
  }
  if (m === 'answer') return DOC_TYPE.ANSWER;
  if (m === 'exec') return DOC_TYPE.EXEC;
  if (m === 'petition') return DOC_TYPE.PETITION;
  if (m === 'change') return DOC_TYPE.CHANGE;
  return DOC_TYPE.GENERIC;
}

// 官方案由 → 要素表 key（elementTable 挂接，不重写 CASE_KEY_MAP）
function elementKeyOf(caseType, dt) {
  if (typeof CASE_KEY_MAP !== 'undefined' && CASE_KEY_MAP[caseType]) return CASE_KEY_MAP[caseType];
  const n = normalizeCaseType(caseType);
  if (typeof CASE_KEY_MAP !== 'undefined') {
    for (const k in CASE_KEY_MAP) {
      if (normalizeCaseType(k) === n) return CASE_KEY_MAP[k];
    }
  }
  if (dt === DOC_TYPE.ADMIN) return 'admin';
  if (dt === DOC_TYPE.CRIMINAL) return 'criminal';
  // 最终模板补齐批次：新增类型走最小要素族，避免全局模糊串位
  if (dt === DOC_TYPE.EXEC) return 'exec';
  if (dt === DOC_TYPE.COMPENSATION) return 'compensation';
  if (dt === DOC_TYPE.ANSWER) return 'answer';
  return '';
}

let _templateRegistry = null;

function templateRegistry() {
  if (_templateRegistry) return _templateRegistry;
  const reg = [];
  const appNames = [];
  ((typeof CASE_TYPES !== 'undefined' && CASE_TYPES) || []).forEach(g => (g.items || []).forEach(n => appNames.push(n)));
  for (const key in OFFICIAL_TEMPLATES) {
    const tpl = OFFICIAL_TEMPLATES[key];
    const dt = OFFICIAL_TYPE_TO_DOC[tpl.t] || DOC_TYPE.GENERIC;
    const nKey = normalizeCaseType(key);
    const appCaseTypeNames = [];
    for (const an of appNames) {
      const anNorm = normalizeCaseType(an);
      if (docTypeOfCase(an) === dt && (anNorm === nKey || anNorm.indexOf(nKey) >= 0 || nKey.indexOf(anNorm) >= 0)) {
        appCaseTypeNames.push(an);
      }
    }
    for (const src in NAME_ALIASES) {
      // 显式别名表为同类型声明：别名直接登记到目标模板，不依赖案由下拉分组
      if (NAME_ALIASES[src] === key) appCaseTypeNames.push(src);
    }
    reg.push({
      id: 'tpl_' + normalizeCaseType(key),
      docType: dt,
      caseType: key,
      canonicalKey: dt + ':' + nKey,
      name: tpl.title || key,
      title: tpl.title || key,
      priority: 100,
      aliases: [],
      appCaseTypeNames: appCaseTypeNames,
      legacyRules: null,
      elementTable: elementKeyOf(key, dt),
      tpl: tpl
    });
  }
  _templateRegistry = reg;
  return reg;
}

function pickByPriority(list) {
  let best = list[0];
  for (const e of list) if ((e.priority || 0) > (best.priority || 0)) best = e;
  const sameTop = list.filter(e => (e.priority || 0) === (best.priority || 0));
  return sameTop.length === 1 ? best : null;
}

// 六步匹配：精确 → 别名/appCaseTypeNames → 同 docType 内包含 → 歧义按 priority → 未命中 null（调用方走通用模板）
// 同 docType 内包含匹配的硬隔离：语义相反的官方案由名即使互为子串也绝不互相兜底。
const CONTAIN_EXCLUDE = [['强制执行', '行政强制执行']];
function containExcluded(a, b) {
  return CONTAIN_EXCLUDE.some(p => {
    const x = normalizeCaseType(p[0]), y = normalizeCaseType(p[1]);
    return (a === x && b === y) || (a === y && b === x);
  });
}
function findTemplate(docType, caseType) {
  const dt = String(docType || '');
  const n = normalizeCaseType(caseType);
  if (!dt || !n) return null;
  const entries = templateRegistry().filter(e => e.docType === dt && e.tpl);
  if (!entries.length) return null;
  // L1 canonicalKey 精确匹配
  const exact = entries.find(e => e.canonicalKey === dt + ':' + n);
  if (exact) return exact;
  // L2 显式别名 / appCaseTypeNames
  const aliasHits = entries.filter(e =>
    (e.aliases || []).some(a => normalizeCaseType(a) === n) ||
    (e.appCaseTypeNames || []).some(a => normalizeCaseType(a) === n));
  if (aliasHits.length === 1) return aliasHits[0];
  if (aliasHits.length > 1) return pickByPriority(aliasHits);
  // L3 同 docType 内包含匹配（绝不跨 docType）
  const cands = entries.filter(e => {
    const kn = e.canonicalKey.slice(e.canonicalKey.indexOf(':') + 1);
    return n.length >= 2 && (kn.indexOf(n) >= 0 || n.indexOf(kn) >= 0) && !containExcluded(kn, n);
  });
  if (cands.length === 1) return cands[0];
  if (cands.length > 1) return pickByPriority(cands);
  return null;
}
