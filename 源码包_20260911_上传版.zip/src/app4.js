/* ==================== 案件驾驶舱（第五批：v3 数据可视化工作台） ==================== */

let currentCockpitId = null;

const TIMELINE_LABELS = {
  created: '案件创建',
  document_saved: '文书保存',
  document_restored: '版本恢复',
  status: '状态变更',
  deleted: '移入回收站',
  restored: '从回收站恢复'
};
function timelineLabel(e) { return TIMELINE_LABELS[e] || e; }

function fmtClock(ts) { return ts ? new Date(ts).toLocaleString('zh-CN', { hour12: false }) : ''; }

function escParty(p) {
  if (!p || !p.name) return '';
  const bits = [escHtml(p.name)];
  if (p.gender) bits.push(escHtml(p.gender));
  if (p.birth) bits.push('出生 ' + escHtml(p.birth));
  if (p.nation) bits.push(escHtml(p.nation));
  if (p.idNo) bits.push('证件 ' + escHtml(p.idNo));
  if (p.phone) bits.push('电话 ' + escHtml(p.phone));
  if (p.addr) bits.push('住 ' + escHtml(p.addr));
  if (p.orgName) bits.push('名称 ' + escHtml(p.orgName));
  if (p.legalRep) bits.push('法代 ' + escHtml(p.legalRep));
  if (p.creditCode) bits.push('信用代码 ' + escHtml(p.creditCode));
  return bits.join(' · ');
}

function latestSnapshotOf(caseId) {
  const c = state.cases.find(x => x.id === caseId);
  // 兜底顺序：Case 当前字段 → 文书最新快照（不显示假数据，只做合并展示）
  const cp = (c.parties && typeof c.parties === 'object') ? c.parties : {};
  const snap = {
    parties: {
      plaintiffs: (cp.plaintiffs && cp.plaintiffs.length) ? cp.plaintiffs : [],
      defendants: (cp.defendants && cp.defendants.length) ? cp.defendants : [],
      thirdParties: (cp.thirdParties && cp.thirdParties.length) ? cp.thirdParties : [],
      agents: (cp.agents && cp.agents.length) ? cp.agents : []
    },
    claims: (c.claims && c.claims.length) ? c.claims : [],
    evidence: (c.evidence && c.evidence.length) ? c.evidence : [],
    facts: (c.facts && c.facts.length) ? c.facts : [],
    basis: '', total: '', court: c.court || '', caseType: c.caseType || ''
  };
  (c.documents || []).forEach(docId => {
    const g = state.documents[docId];
    if (!g || !g.revisions || !g.revisions.length) return;
    const s = g.revisions[g.revisions.length - 1].snapshot;
    if (!s) return;
    if (!snap.parties.plaintiffs.length && s.parties && s.parties.plaintiffs && s.parties.plaintiffs.length) snap.parties.plaintiffs = s.parties.plaintiffs;
    if (!snap.parties.defendants.length && s.parties && s.parties.defendants && s.parties.defendants.length) snap.parties.defendants = s.parties.defendants;
    if (!snap.parties.thirdParties.length && s.parties && s.parties.thirdParties && s.parties.thirdParties.length) snap.parties.thirdParties = s.parties.thirdParties;
    if (!snap.claims.length && s.claims && s.claims.length) snap.claims = s.claims;
    if (!snap.evidence.length && s.evidence && s.evidence.length) snap.evidence = s.evidence;
    if (!snap.facts.length && s.facts && s.facts.length) snap.facts = s.facts;
    if (!snap.basis && s.basis) snap.basis = s.basis;
    if (!snap.total && s.total) snap.total = s.total;
    if (!snap.court && s.court) snap.court = s.court;
    if (!snap.caseType && s.caseType) snap.caseType = s.caseType;
  });
  return snap;
}

function listOrEmpty(arr, emptyMsg) {
  if (!arr || !arr.length) return '<div class="ck-meta">' + (emptyMsg || '暂无') + '</div>';
  return arr.map((x, i) => '<div class="ck-line">' + (i + 1) + '. ' + escHtml(typeof x === 'string' ? x : (x.content ? (x.label ? '【' + x.label + '】' + x.content : x.content) : JSON.stringify(x))) + '</div>').join('');
}

function goCockpit(id) {
  const c = state.cases.find(x => x.id === id && !x.deletedAt);
  if (!c) return;
  currentCockpitId = id;
  goTab('dashboard');
  $('cockpitPanel').style.display = '';
  renderCockpit();
  $('cockpitPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function closeCockpit() {
  currentCockpitId = null;
  const p = $('cockpitPanel');
  if (p) p.style.display = 'none';
}

function closeCockpitIfCase(id) {
  if (currentCockpitId === id) closeCockpit();
}

function openCockpitDraft() {
  if (!currentCockpitId) return;
  openCase(currentCockpitId);
  toast('已在材料撰写载入案件（展示最新版本文书）');
}

function renderCockpit() {
  const id = currentCockpitId;
  const c = state.cases.find(x => x.id === id && !x.deletedAt);
  if (!c) { closeCockpit(); return; }
  $('ckTitle').textContent = c.title || '未命名案件';
  $('ckMeta').innerHTML =
    '案由：' + escHtml(c.caseType || '（未定）') + '　|　法院：' + escHtml(c.court || '（未填）') +
    '　|　案号：' + escHtml(c.caseNo || '（未填）') +
    '<br>创建：' + fmtClock(c.createdAt) + '　|　更新：' + fmtClock(c.updatedAt);
  $('ckStatusRow').innerHTML =
    '<select onchange="setCaseStatus(\'' + c.id + '\', this.value)">' +
    CASE_STATUSES.map(s => '<option value="' + s.v + '"' + (c.status === s.v ? ' selected' : '') + '>' + s.label + '</option>').join('') +
    '</select>';
  $('ckBasic').innerHTML =
    '<div class="ck-meta">以下素材为案件源数据，生成结果不反向覆盖。</div>' +
    '<div style="white-space:pre-wrap;margin-top:4px">' + escHtml((c.material || '').slice(0, 600) || '（无素材）') + '</div>';

  const snap = latestSnapshotOf(c.id);
  $('ckParties').innerHTML =
    (snap.parties.plaintiffs && snap.parties.plaintiffs.length ? snap.parties.plaintiffs.map(p => '<div class="ck-line">原告：' + escParty(p) + '</div>').join('') : '') +
    (snap.parties.defendants && snap.parties.defendants.length ? snap.parties.defendants.map(p => '<div class="ck-line">被告：' + escParty(p) + '</div>').join('') : '') +
    (snap.parties.thirdParties && snap.parties.thirdParties.length ? snap.parties.thirdParties.map(p => '<div class="ck-line">第三人：' + escParty(p) + '</div>').join('') : '') +
    ((!snap.parties.plaintiffs || !snap.parties.plaintiffs.length) && (!snap.parties.defendants || !snap.parties.defendants.length) ? '<div class="ck-meta">（暂无，生成文书时会固化快照）</div>' : '');
  $('ckClaims').innerHTML = listOrEmpty(snap.claims, '（暂无结构化诉讼请求）') + (snap.total ? '<div class="ck-line"><b>标的总额：</b>' + escHtml(snap.total) + '</div>' : '');
  $('ckEvidence').innerHTML = listOrEmpty(snap.evidence, '（暂无结构化证据）');
  $('ckFacts').innerHTML = listOrEmpty(snap.facts, '（暂无要素事实）') + (snap.basis ? '<div class="ck-line"><b>请求依据：</b>' + escHtml(snap.basis) + '</div>' : '');
  $('ckTimeline').innerHTML = (c.timeline || []).slice().reverse().map(ev =>
    '<div class="ck-line">' + fmtClock(ev.t) + ' · ' + escHtml(timelineLabel(ev.event)) + (ev.note ? '（' + escHtml(ev.note) + '）' : '') + '</div>'
  ).join('') || '<div class="ck-meta">暂无时间轴记录</div>';

  renderCockpitDocs(c);
  $('ckViewer').style.display = 'none';
}

function renderCockpitDocs(c) {
  const box = $('ckDocs');
  if (!c.documents || !c.documents.length) {
    box.innerHTML = '<div class="ck-meta">该案件还没有文书。到「材料撰写」生成后点“存入案件档案”。</div>';
    return;
  }
  const html = c.documents.map(docId => {
    const g = state.documents[docId];
    if (!g || !g.revisions || !g.revisions.length) return '';
    const revs = g.revisions.slice().reverse();
    const last = g.revisions[g.revisions.length - 1];
    const lastSnap = last.snapshot || {};
    const docCaseType = lastSnap.caseType || c.caseType || '';
    const gDocType = g.canonicalKey ? g.canonicalKey.split(':')[0] : (docCaseType ? docTypeOfCase(docCaseType) : '');
    const rows = revs.map(rv => {
      const isCur = rv === g.revisions[g.revisions.length - 1];
      const ai = rv.aiMeta || {};
      const aiLine = (ai.provider || ai.model)
        ? 'AI：' + escHtml((ai.provider || '') + (ai.model ? ' / ' + ai.model : '')) + ' · tokens ' + (ai.tokens ? ai.tokens.in + '/' + ai.tokens.out : '-') + ' · ¥' + (ai.cost || 0).toFixed(4)
        : '本地模板生成';
      return '<div class="ck-rev' + (isCur ? ' cur' : '') + '">' +
        '<div class="t">第 ' + rv.revision + ' 版' + (isCur ? ' <span class="ck-tag">当前</span>' : '') + (rv.status === 'restored' ? ' <span class="ck-tag">已恢复</span>' : '') + '</div>' +
        '<div class="ck-meta">' + fmtClock(rv.updatedAt || rv.createdAt) + ' · ' + escHtml(rv.name || '文书') + '</div>' +
        '<div class="ck-meta">' + aiLine + '</div>' +
        '<div class="btnrow" style="margin-top:4px">' +
        '<button class="btn btn-primary btn-sm" onclick="viewRevision(\'' + g.id + '\',' + rv.revision + ')">👁 查看</button>' +
        '<button class="btn btn-ghost btn-sm" onclick="restoreRevision(\'' + g.id + '\',' + rv.revision + ')">↩ 恢复此版本</button>' +
        '</div></div>';
    }).join('');
    return '<div style="margin:10px 0 4px"><b>' + escHtml(last.name || g.id) + '</b>' +
      '<div class="ck-meta">docType ' + escHtml(gDocType || '—') +
      ' · caseType ' + escHtml(docCaseType || '—') +
      ' · canonicalKey ' + escHtml(g.canonicalKey || '—') +
      ' · 共 ' + g.revisions.length + ' 版 · 当前第 ' + last.revision + ' 版 · 更新 ' + fmtClock(g.updatedAt) + '</div></div>' + rows;
  }).join('');
  box.innerHTML = html;
}

function snapshotHtml(s) {
  if (!s || typeof s !== 'object') return '';
  const lines = [];
  if (s.parties) {
    (s.parties.plaintiffs || []).forEach(p => lines.push('原告：' + (p.name || JSON.stringify(p))));
    (s.parties.defendants || []).forEach(p => lines.push('被告：' + (p.name || JSON.stringify(p))));
    (s.parties.thirdParties || []).forEach(p => lines.push('第三人：' + (p.name || JSON.stringify(p))));
  }
  (s.claims || []).forEach((x, i) => lines.push('请求 ' + (i + 1) + '：' + x));
  (s.evidence || []).forEach((x, i) => lines.push('证据 ' + (i + 1) + '：' + (typeof x === 'string' ? x : (x.name || JSON.stringify(x)))));
  (s.facts || []).forEach(f => lines.push((f.label ? '【' + f.label + '】' : '') + (f.content || JSON.stringify(f))));
  if (s.basis) lines.push('请求依据：' + s.basis);
  if (s.total) lines.push('标的总额：' + s.total);
  if (s.court) lines.push('受理法院：' + s.court);
  if (s.caseType) lines.push('案由：' + s.caseType);
  if (!lines.length) return '';
  return '<div style="margin-top:8px"><b>生成快照（冻结数据）</b><pre style="white-space:pre-wrap;font-family:inherit;background:#f7f7f7;border-radius:6px;padding:8px;font-size:12px">' + escHtml(lines.join('\n')) + '</pre></div>';
}

function viewRevision(groupId, revNo) {
  const g = state.documents[groupId];
  const rv = g && g.revisions.find(r => r.revision === revNo);
  if (!rv) return;
  const v = $('ckViewer');
  v.style.display = '';
  v.innerHTML = '<b>查看：' + escHtml(rv.name || '文书') + ' · 第 ' + revNo + ' 版</b>（' + fmtClock(rv.updatedAt || rv.createdAt) + '）<hr style="border:none;border-top:1px solid var(--line)">' +
    (rv.content && rv.content.html ? rv.content.html : '<pre style="white-space:pre-wrap;font-family:inherit">' + escHtml((rv.content && rv.content.text) || '') + '</pre>') +
    snapshotHtml(rv.snapshot);
  v.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function restoreRevision(groupId, revNo) {
  const c = state.cases.find(x => x.id === currentCockpitId && !x.deletedAt);
  const g = state.documents[groupId];
  const rv = g && g.revisions.find(r => r.revision === revNo);
  if (!c || !g || !rv) return;
  const now = Date.now();
  const content = { html: (rv.content && rv.content.html) || null, text: (rv.content && rv.content.text) || '', docx: null };
  const snap = rv.snapshot ? JSON.parse(JSON.stringify(rv.snapshot)) : null;
  g.revisions.push({
    revision: g.revisions.length + 1,
    name: rv.name,
    status: 'restored',
    content: content,
    snapshot: snap,
    aiMeta: { provider: '', model: '', generatedAt: now, tokens: { in: 0, out: 0 }, cost: 0 },
    checks: [],
    createdAt: now,
    updatedAt: now
  });
  g.updatedAt = now;
  c.updatedAt = now;
  c.timeline.push({ t: now, event: 'document_restored', note: rv.name + ' 恢复为第 ' + revNo + ' 版' });
  saveState();
  renderCases();
  renderCockpit();
  toast('已恢复为第 ' + revNo + ' 版（新增为第 ' + g.revisions.length + ' 版）');
}

function setCaseStatus(id, status) {
  const c = state.cases.find(x => x.id === id && !x.deletedAt);
  if (!c || !CASE_STATUSES.some(s => s.v === status)) return;
  const now = Date.now();
  c.status = status;
  c.updatedAt = now;
  c.timeline.push({ t: now, event: 'status', note: statusLabel(status) });
  saveState();
  renderCases();
  if (currentCockpitId === id) renderCockpit();
  toast('案件状态已改为：' + statusLabel(status));
}

function renderTrash() {
  const box = $('caseTrash');
  const dead = state.cases.filter(c => c.deletedAt);
  if (!dead.length) { box.innerHTML = '无已删除案件'; return; }
  box.innerHTML = dead.map(c =>
    '<div class="case-card">' +
    '<div><div class="tt">' + escHtml(c.title) + '</div>' +
    '<div class="mt">删除于 ' + fmtTime(c.deletedAt) + '</div></div>' +
    '<button class="btn btn-primary btn-sm" onclick="restoreCase(\'' + c.id + '\')">♻ 恢复</button></div>'
  ).join('');
}

function restoreCase(id) {
  const c = state.cases.find(x => x.id === id && x.deletedAt);
  if (!c) return;
  const now = Date.now();
  c.deletedAt = null;
  c.updatedAt = now;
  c.timeline.push({ t: now, event: 'restored' });
  saveState();
  renderCases();
  toast('案件已恢复');
}
