/* ===== 法务AI 3.2 · 核心逻辑（二） ===== */

/* ==================== 证据分析 ==================== */
async function evidenceRun() {
  if (!tryLock()) return;
  const material = $('evMaterial').value.trim();
  if (!material) { unlock(); toast('请先粘贴案情和证据'); return; }
  const box = $('evResult');
  box.innerHTML = '';
  const btn = $('btnEvRun');
  btn.disabled = true;
  showLoading(box, 'AI 正在整理证据清单与分析…');
  try {
    const r = await callLLM([
      { role: 'system', content: SYS },
      { role: 'user', content: '请对下面的案情与证据做证据分析，按此结构输出（用纯文本，不用表格）：\n一、证据清单：每条一行“序号｜证据名称｜来源/形式｜是否原件｜证明内容｜证明目的”\n二、质证意见：对方可能提出的质疑及应对\n三、补充证据建议：还缺什么证据、怎么补\n四、风险提示\n素材：\n' + material }
    ], { temp: 0.3, note: '证据分析' });
    hideLoading();
    showDocResult(box, '🧾 证据分析报告', r.text);
  } catch (e) {
    hideLoading();
    if (e.needSetup) goTab('settings');
    box.innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    btn.disabled = false;
    unlock();
  }
}

/* ==================== 法律研究 ==================== */
async function researchRun() {
  if (!tryLock()) return;
  const q = $('rsQ').value.trim();
  if (!q) { unlock(); toast('请输入要研究的问题'); return; }
  const box = $('rsResult');
  box.innerHTML = '';
  const btn = $('btnRsRun');
  btn.disabled = true;
  showLoading(box, 'AI 正在检索相关法律规定…');
  try {
    const r = await callLLM([
      { role: 'system', content: SYS_RESEARCH },
      { role: 'user', content: '请研究这个问题：' + q }
    ], { temp: 0.3, note: '法律研究' });
    hideLoading();
    showDocResult(box, '📚 研究结果', r.text);
  } catch (e) {
    hideLoading();
    if (e.needSetup) goTab('settings');
    box.innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    btn.disabled = false;
    unlock();
  }
}
document.querySelectorAll('#tab-research .chip').forEach(ch => {
  ch.addEventListener('click', () => {
    $('rsQ').value = ch.dataset.q;
    researchRun();
  });
});

/* ==================== 通用结果查看器 ==================== */
function showDocResult(el, title, text) {
  curDocText = text;
  el.innerHTML = '<div class="card">' +
    '<h2>' + escHtml(title) + '</h2>' +
    '<div class="doc-body">' + escHtml(text) + '</div>' +
    '<div class="btnrow">' +
    '<button class="btn btn-green" onclick="copyDoc()">📋 复制全文</button>' +
    '<button class="btn btn-gold" onclick="exportDoc()">📥 导出 Word</button>' +
    '<button class="btn btn-primary" onclick="printDoc()">🖨 打印</button>' +
    '</div></div>';
  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ==================== 基层治理场景 ==================== */
const GOVERN = [
  { id: 'zhai', ic: '🏠', name: '宅基地纠纷', out: '民事起诉状（双版）',
    fields: [
      { k: 'party', label: '当事人信息（双方姓名、身份、住址）' },
      { k: 'land', label: '宅基地位置、面积、权属情况' },
      { k: 'facts', label: '纠纷经过（谁、何时、何事）' },
      { k: 'claim', label: '诉求' }
    ] },
  { id: 'chengbao', ic: '🌾', name: '土地承包纠纷', out: '民事起诉状（双版）',
    fields: [
      { k: 'party', label: '当事人信息' },
      { k: 'land', label: '承包地位置、面积、承包期限' },
      { k: 'facts', label: '纠纷经过（流转、征收、权属等）' },
      { k: 'claim', label: '诉求' }
    ] },
  { id: 'linli', ic: '🏡', name: '邻里纠纷', out: '民事起诉状（双版）',
    fields: [
      { k: 'party', label: '当事人信息' },
      { k: 'facts', label: '纠纷经过（通行/排水/噪音/采光等）' },
      { k: 'claim', label: '诉求' }
    ] },
  { id: 'shanyang', ic: '👵', name: '赡养纠纷', out: '民事起诉状（双版）',
    fields: [
      { k: 'old', label: '老人信息（姓名、年龄、住址）' },
      { k: 'child', label: '子女信息（各子女姓名、住址、赡养情况）' },
      { k: 'facts', label: '不赡养的事实经过' },
      { k: 'claim', label: '诉求（赡养费标准、方式等）' }
    ] },
  { id: 'caili', ic: '💍', name: '彩礼返还纠纷', out: '民事起诉状（双版）',
    fields: [
      { k: 'party', label: '当事人信息' },
      { k: 'facts', label: '订婚/结婚、彩礼金额与支付方式、现状' },
      { k: 'claim', label: '诉求' }
    ] },
  { id: 'qianxin', ic: '💼', name: '农民工欠薪', out: '民事起诉状（双版）＋仲裁提示',
    fields: [
      { k: 'worker', label: '务工人员信息（姓名、工种）' },
      { k: 'boss', label: '欠薪方信息（单位/包工头）' },
      { k: 'facts', label: '工作期间、欠薪金额、约定与催要经过' },
      { k: 'claim', label: '诉求' }
    ] },
  { id: 'cunwu', ic: '📢', name: '村务公开/信访', out: '信访反映材料',
    fields: [
      { k: 'party', label: '反映人信息' },
      { k: 'target', label: '被反映单位/人员' },
      { k: 'facts', label: '反映事项与事实经过' },
      { k: 'claim', label: '诉求' }
    ] },
  { id: 'zhengming', ic: '📄', name: '村委会证明/情况说明', out: '情况说明',
    fields: [
      { k: 'who', label: '为谁出具（姓名、身份证号、住址）' },
      { k: 'what', label: '要证明/说明的事项（时间、地点、经过）' },
      { k: 'use', label: '用途（用于什么手续）' }
    ] }
];

let currentGovern = null;
function renderGovernGrid() {
  $('governGrid').innerHTML = GOVERN.map(s =>
    '<button class="scenario" onclick="governPick(\'' + s.id + '\')">' +
    '<div class="sic">' + s.ic + '</div><div class="snm">' + escHtml(s.name) + '</div>' +
    '<div class="sds">' + escHtml(s.out) + '</div></button>'
  ).join('');
}
function governPick(id) {
  const s = GOVERN.find(x => x.id === id);
  if (!s) return;
  currentGovern = s;
  $('governFormTitle').textContent = s.ic + ' ' + s.name + '（生成：' + s.out + '）';
  $('governFields').innerHTML = s.fields.map(f =>
    '<label class="fld">' + escHtml(f.label) + '</label>' +
    '<textarea id="gf_' + f.k + '" placeholder="' + escHtml(f.label) + '"></textarea>'
  ).join('');
  $('governForm').style.display = '';
  $('governResult').innerHTML = '';
  window.scrollTo({ top: $('governForm').offsetTop - 90, behavior: 'smooth' });
}
function governBack() {
  currentGovern = null;
  $('governForm').style.display = 'none';
  $('governResult').innerHTML = '';
}
async function governRun() {
  if (!tryLock()) return;
  if (!currentGovern) { unlock(); return; }
  const vals = {};
  currentGovern.fields.forEach(f => { vals[f.k] = $('gf_' + f.k).value.trim(); });
  if (currentGovern.fields.every(f => !vals[f.k])) { toast('请至少填写一项内容'); return; }
  const box = $('governResult');
  box.innerHTML = '';
  const btn = $('btnGovernRun');
  btn.disabled = true;
  showLoading(box, 'AI 正在根据场景要素生成文书…');
  try {
    const desc = currentGovern.fields.map(f => f.label + '：' + (vals[f.k] || '（未提供）')).join('\n');
    let r, docs;
    if (currentGovern.id === 'zhengming') {
      r = await callLLM([
        { role: 'system', content: SYS },
        { role: 'user', content: '请生成一份村委会《情况说明/证明》草稿：用语客观、事实清楚、落款留空（村委会名称、日期留空），并附一行提示“需加盖村委会公章”。\n要素：\n' + desc }
      ], { temp: 0.3, note: '基层治理·' + currentGovern.name });
      docs = [{ name: currentGovern.name + '·成稿', text: r.text.trim() }];
    } else if (currentGovern.id === 'cunwu') {
      r = await callLLM([
        { role: 'system', content: SYS },
        { role: 'user', content: '请生成规范的《信访反映材料》：反映人信息、被反映单位/人员、反映事项、事实经过、诉求、联系方式（缺失写待补充）。\n要素：\n' + desc }
      ], { temp: 0.3, note: '基层治理·' + currentGovern.name });
      docs = [{ name: currentGovern.name + '·成稿', text: r.text.trim() }];
    } else {
      // 起诉状类场景：双引擎——AI 提取结构化要素，要素式本地生成，传统式 AI 独立生成
      const obj = await extractGovernElements(desc, currentGovern.name);
      const caseType = obj.caseType || currentGovern.name;
      const key = elemKeyOf(caseType);
      const title = elemTitleOf(key, caseType);
      const facts = [];
      if (obj.factFields && typeof obj.factFields === 'object') {
        Object.keys(obj.factFields).forEach(k => {
          const v = String(obj.factFields[k] || '').trim();
          if (v) facts.push({ label: k, content: v });
        });
      }
      if (String(obj.factReason || '').trim()) facts.push({ label: '', content: String(obj.factReason).trim() });
      const p = obj.plaintiff || {}, df = obj.defendant || {};
      const data = {
        caseType: caseType,
        key: key,
        plaintiff: p,
        defendant: df,
        claims: obj.claims || [],
        evidence: obj.evidence || [],
        facts: facts,
        court: obj.court || '',
        signerName: p.name || '',
        signDate: today()
      };
      const elemText = buildElemTextLines({
        title: title,
        pName: p.name, pGender: p.gender, pBirth: p.birth, pNation: p.nation, pPhone: p.phone, pAddr: p.addr, pIdNo: p.idNo, pLive: p.liveAddr || '',
        dName: df.name, dGender: df.gender, dBirth: df.birth, dNation: df.nation, dPhone: df.phone, dAddr: df.addr, dIdNo: df.idNo, dLive: df.liveAddr || '',
        claims: data.claims, evidences: data.evidence, facts: data.facts,
        court: data.court || '（待补充）', signerName: data.signerName, signDate: data.signDate,
        serviceAddr: p.addr, servicePhone: p.phone
      }).join('\n');
      r = await callLLM([
        { role: 'system', content: SYS },
        { role: 'user', content: buildTradPrompt(data) }
      ], { temp: 0.3, maxTokens: 6000, note: '基层治理·' + currentGovern.name });
      const tradText = stripMarkdown(r.text);
      docs = [
        { name: '要素式起诉状', text: elemText },
        { name: '传统式起诉状', text: tradText }
      ];
    }
    hideLoading();
    currentDraft.docs = docs;
    currentDraft.material = desc;
    currentDraft.caseId = null;
    showDocResult(box, '✍️ ' + currentGovern.name + ' · 成稿', docs.map(d => d.name + '\n' + d.text).join('\n\n'));
    box.querySelector('.btnrow').insertAdjacentHTML('beforeend', '<button class="btn btn-ghost" onclick="saveDraftToCase()">💾 存入案件档案</button>');
  } catch (e) {
    hideLoading();
    if (e.needSetup) goTab('settings');
    box.innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    btn.disabled = false;
    unlock();
  }
}

async function extractGovernElements(desc, scenario) {
  const prompt = '你是法律文书要素提取专家。请从下面的基层治理场景素材中提取撰写民事起诉状所需的全部要素，只输出一个 JSON 对象（不要 Markdown 代码块，不要解释）。\n' +
    '场景：' + scenario + '\n' +
    'JSON 结构：{"caseType":"案由名称","plaintiff":{"name":"","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":""},"defendant":{"name":"","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":""},"claims":["诉讼请求1"],"evidence":["证据1"],"factFields":{"要素标签":"内容"},"factReason":"","court":""}\n' +
    '要求：素材未提及的字段一律为空字符串或空数组，绝不编造；诉讼请求可多条。\n素材：\n' + desc;
  const r = await callLLM([
    { role: 'system', content: SYS },
    { role: 'user', content: prompt }
  ], { temp: 0.1, maxTokens: 4000, note: '基层治理·要素提取' });
  return parseJsonStrict(r.text);
}

/* ==================== 模型与费用 ==================== */
const PRESET_MODELS = {
  deepseek: [['deepseek-chat', 'deepseek-chat（通用，便宜）'], ['deepseek-reasoner', 'deepseek-reasoner（深度思考）']],
  zhipu: [['glm-4.7-flash', 'glm-4.7-flash（免费）'], ['glm-4.7', 'glm-4.7（最强）'], ['glm-4.6', 'glm-4.6'], ['glm-4.5', 'glm-4.5'], ['glm-4-flash', 'glm-4-flash（免费）']],
  qwen: [['qwen-plus', 'qwen-plus'], ['qwen-turbo', 'qwen-turbo（快）'], ['qwen-max', 'qwen-max（强）'], ['qwen-long', 'qwen-long（长文本）']],
  custom: []
};
function populateModelPreset() {
  const sel = $('setModelPreset');
  const p = state.provider;
  const current = state.models[p] || PROVIDERS[p].model;
  sel.innerHTML = '<option value="">— 选择常用模型（也可手动输入）—</option>' +
    (PRESET_MODELS[p] || []).map(x => '<option value="' + escHtml(x[0]) + '">' + escHtml(x[1]) + '</option>').join('');
  sel.value = (PRESET_MODELS[p] || []).some(x => x[0] === current) ? current : '';
}
function applyModelPreset() {
  const v = $('setModelPreset').value;
  if (v) {
    $('setModel').value = v;
    toast('已选择：' + v);
  }
}
function syncSettingsUI() {
  $('setProvider').value = state.provider;
  const p = state.provider;
  $('setKey').value = state.keys[p] || '';
  $('setModel').value = state.models[p] || PROVIDERS[p].model;
  $('setBase').value = state.bases[p] || '';
  const r = state.rates[p] || DEFAULT_STATE.rates[p];
  $('setRateIn').value = r.in;
  $('setRateOut').value = r.out;
  $('keyHint').textContent = PROVIDERS[p].hint;
  populateModelPreset();
  $('typeRow').style.display = (currentDraft.mode === 'complaint' || currentDraft.mode === 'answer' || currentDraft.mode === 'generic') ? '' : 'none';
}
$('setProvider').addEventListener('change', function () {
  state.provider = this.value;   // 先记住用户选中的服务商，再刷新界面
  syncSettingsUI();
});

function saveSettings() {
  const p = $('setProvider').value;
  state.provider = p;
  state.keys[p] = $('setKey').value.trim();
  state.models[p] = $('setModel').value.trim() || PROVIDERS[p].model;
  state.bases[p] = $('setBase').value.trim();
  state.rates[p] = {
    in: parseFloat($('setRateIn').value) || 0,
    out: parseFloat($('setRateOut').value) || 0
  };
  saveState();
  updateModelPill();
  toast('设置已保存');
}
function updateModelPill() {
  const p = state.provider;
  const model = (state.models && state.models[p]) || PROVIDERS[p].model;
  const key = state.keys && state.keys[p];
  $('modelPill').textContent = key ? (PROVIDERS[p].label + ' · ' + model) : '未设置密钥 · ' + PROVIDERS[p].label;
}
async function testConnection() {
  if (!tryLock()) return;
  saveSettings();
  const btn = event.target;
  btn.disabled = true;
  btn.textContent = '测试中…';
  try {
    const r = await callLLM([
      { role: 'system', content: '你是连接测试助手。' },
      { role: 'user', content: '请只回复四个字：连接成功' }
    ], { temp: 0, maxTokens: 50, note: '连接测试' });
    toast('连接成功：' + r.text.slice(0, 30));
  } catch (e) {
    if (e.needSetup) goTab('settings');
    toast('测试失败：' + e.message.slice(0, 60));
  } finally {
    btn.disabled = false;
    btn.textContent = '🔌 测试连接';
    unlock();
  }
}

function renderLedger() {
  const body = $('ledgerBody');
  if (!state.ledger.length) {
    body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--muted)">暂无调用记录</td></tr>';
    return;
  }
  body.innerHTML = state.ledger.slice(0, 100).map(e =>
    '<tr><td>' + fmtTime(e.t) + '</td><td>' + escHtml(e.model || e.provider) + '</td>' +
    '<td>' + (e.in || 0) + '</td><td>' + (e.out || 0) + '</td>' +
    '<td>' + (e.cost ? e.cost.toFixed(4) : '0') + '</td><td>' + escHtml(e.note || '') + '</td></tr>'
  ).join('');
}
function updateStats() {
  const calls = state.ledger.length;
  const tokens = state.ledger.reduce((s, e) => s + (e.in || 0) + (e.out || 0), 0);
  const cost = state.ledger.reduce((s, e) => s + (e.cost || 0), 0);
  $('statCalls').textContent = calls;
  $('statTokens').textContent = tokens.toLocaleString();
  $('statCost').textContent = '¥' + cost.toFixed(4);
}
function clearLedger() {
  if (!confirm('确定清空费用台账吗？')) return;
  state.ledger = [];
  saveState();
  renderLedger();
  updateStats();
  toast('台账已清空');
}

function exportAll() {
  const blob = new Blob(['\ufeff' + JSON.stringify(state, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = '法务AI3.2_数据备份_' + Date.now() + '.json';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  toast('数据已导出');
}
function importAll(ev) {
  const f = ev.target.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const saved = JSON.parse(reader.result);
      // v3.3：旧版 v1 备份导入时自动迁移，v3 数据规范化后接管
      state = ensureV3State(saved);
      saveState();
      renderCases();
      syncSettingsUI();
      updateModelPill();
      renderLedger();
      updateStats();
      toast('数据导入成功');
    } catch (e) {
      toast('导入失败：文件格式不正确');
    }
  };
  reader.readAsText(f, 'utf-8');
  ev.target.value = '';
}
function clearAll() {
  if (!confirm('确定清空全部数据（案件、设置、台账）吗？建议先导出备份。')) return;
  if (!confirm('再次确认：清空后不可恢复！')) return;
  state = JSON.parse(JSON.stringify(DEFAULT_STATE));
  saveState();
  renderCases();
  syncSettingsUI();
  updateModelPill();
  renderLedger();
  updateStats();
  toast('已清空全部数据');
}

/* ==================== 初始化 ==================== */
loadState();
populateCaseTypes();
renderCases();
syncSettingsUI();
updateModelPill();
renderLedger();
updateStats();
renderGovernGrid();
setDraftMode('complaint');
