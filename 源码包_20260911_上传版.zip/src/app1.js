/* ===== 法务AI 3.2 · 核心逻辑（一） ===== */
'use strict';

const STORE_KEY = 'fawu32_v3';
const PROVIDERS = {
  deepseek: { label: 'DeepSeek', base: 'https://api.deepseek.com/chat/completions', model: 'deepseek-chat', hint: '在 platform.deepseek.com 创建 API Key（格式 sk-…）。如遇“请求过于频繁”可切换到智谱免费通道（glm-4.7-flash）' },
  zhipu: { label: '智谱 GLM（免费）', base: 'https://open.bigmodel.cn/api/paas/v4/chat/completions', model: 'glm-4.7-flash', hint: '在 open.bigmodel.cn 实名认证后创建 API Key，glm-4.7-flash 永久免费，推荐首选' },
  qwen: { label: '通义千问', base: 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions', model: 'qwen-plus', hint: '在阿里云百炼（bailian.console.aliyun.com）创建 API Key' },
  custom: { label: '自定义', base: '', model: '', hint: '填写 OpenAI 兼容的接口地址与模型名称' }
};

const DEFAULT_STATE = {
  schemaVersion: 'v3.3',
  version: 1,
  provider: 'zhipu',
  keys: { deepseek: '', zhipu: '', qwen: '', custom: '' },
  models: { deepseek: 'deepseek-chat', zhipu: 'glm-4-flash', qwen: 'qwen-plus', custom: '' },
  bases: { deepseek: '', zhipu: '', qwen: '', custom: '' },
  rates: { deepseek: { in: 2, out: 3 }, zhipu: { in: 0, out: 0 }, qwen: { in: 0.8, out: 2 }, custom: { in: 1, out: 2 } },
  cases: [],
  documents: {},
  ledger: []
};

const CASE_STATUSES = [
  { v: 'draft', label: '草稿', cls: '#8a8a8a' },
  { v: 'pending_info', label: '材料待补充', cls: '#c77700' },
  { v: 'in_progress', label: '文书生成中', cls: '#1677ff' },
  { v: 'submitted', label: '已完成', cls: '#1a9e4b' },
  { v: 'closed', label: '已关闭', cls: '#666666' }
];
function statusLabel(s) { const f = CASE_STATUSES.find(x => x.v === s); return f ? f.label : (s || '草稿'); }
function statusColor(s) { const f = CASE_STATUSES.find(x => x.v === s); return f ? f.cls : '#888888'; }

const CASE_TYPES = /*__CASE_TYPES__*/[];

let state = JSON.parse(JSON.stringify(DEFAULT_STATE));
let currentDraft = { mode: 'complaint', caseType: '', material: '', analysis: '', docs: [], caseId: null, lastData: null, lastAiMeta: null };
let caseSearchText = '';
let curDocText = '';
let curDocHtml = null;
let curDocName = '';

/* ============ 文书命名：带上当事人称谓与案由（不再只是“法务文书”） ============ */
function docNaming() {
  const mode = (currentDraft && currentDraft.mode) || 'complaint';
  let data = (currentDraft && currentDraft.lastData) || null;
  if (!data) { try { data = readElemForm(); } catch (e) { data = null; } }
  const p = (data && data.plaintiff) || {};
  const d = (data && data.defendant) || {};
  const caseType = String((data && data.caseType) || (currentDraft && currentDraft.caseType) || '').trim();
  let dt = '';
  try { dt = (typeof docTypeForMode === 'function') ? docTypeForMode(mode, caseType) : ''; } catch (e) { dt = ''; }
  let role = '原告';
  let name = p.name || '';
  if (mode === 'answer' || dt === 'answer') { role = '答辩人'; name = d.name || p.name || ''; }
  else if (mode === 'exec' || dt === 'exec') { role = '申请执行人'; name = p.name || ''; }
  else if (dt === 'compensation') { role = '赔偿请求人'; name = p.name || ''; }
  return { mode: mode, caseType: caseType, role: role, name: String(name || '').trim(), docType: dt };
}

/* 生成文件名：<文书名>（<案由>）_<称谓><姓名>_<日期>.doc */
function docFileName(doc, stamp) {
  const info = docNaming();
  let base = String((doc && doc.name) || '法律文书').replace(/（官方模板）|（申请执行用）|（要素式）|（传统式）/g, '');
  base = base.replace(/\s+/g, '');
  const skipCaseType = (info.docType === 'exec' && /申请书/.test(base));
  if (info.caseType && !skipCaseType && base.indexOf(info.caseType) < 0) {
    base = base.replace(/（[^）]*）\s*$/, '') + '（' + info.caseType + '）';
  }
  const who = info.name ? ('_' + info.role + info.name) : (info.role ? '' : '');
  const out = base + who + (stamp ? '_' + stamp : '');
  return out.replace(/[\\/:*?"<>|]/g, '_');
}

/* 文书标题（写进 Word 文档属性/打印标题，与文件名同源） */
function docTitleText() {
  const info = docNaming();
  const base = String(curDocName || '').replace(/_\d{8}$/, '');
  if (base) return base.replace(/_/g, '·');
  const who = info.name ? (info.role + info.name) : info.role;
  return (info.caseType ? info.caseType + '·' : '') + who + ' 法律文书';
}

function loadState() {
  try {
    let saved = null;
    const raw3 = localStorage.getItem(SCHEMA_V3_KEY);
    if (raw3) { try { saved = JSON.parse(raw3); } catch (e) { saved = null; } }
    if (!saved) {
      const r = runMigration();
      if (r && r.ok) {
        const migrated = localStorage.getItem(SCHEMA_V3_KEY);
        if (migrated) { try { saved = JSON.parse(migrated); } catch (e) { saved = null; } }
      }
    }
    state = ensureV3State(saved);
  } catch (e) { console.warn('本地数据读取失败', e); }
  if (!state || !state.cases) state = ensureV3State({});
  saveState();
}
function saveState() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { console.warn('本地保存失败', e); }
}

function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? '' : s); }
function escHtml(s) {
  return esc(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function toast(msg, ms) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), ms || 2400);
}
/* ---------- 全局并发锁（防止“输入过于频繁”） ---------- */
let busy = false;
let rateLimitedUntil = 0;
let lastCallAt = 0;
const REQUEST_GAP_MS = 1200;
function tryLock() {
  if (busy) { toast('上一步还在进行中，请稍候再点'); return false; }
  const wait = rateLimitedUntil - Date.now();
  if (wait > 0) {
    toast('限流冷却中，约 ' + Math.ceil(wait / 1000) + ' 秒后可再试');
    return false;
  }
  busy = true;
  return true;
}
function unlock() { busy = false; }
let activeCtrl = null;
let cancelRequested = false;
function cancelCurrentRequest() {
  if (activeCtrl) {
    cancelRequested = true;
    activeCtrl.abort();
    toast('正在取消…');
  } else {
    toast('当前没有正在进行的请求');
  }
}
function fmtTime(ts) {
  const d = new Date(ts);
  const p = n => (n < 10 ? '0' + n : '' + n);
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}
function today() {
  const d = new Date();
  const p = n => (n < 10 ? '0' + n : '' + n);
  return d.getFullYear() + '年' + p(d.getMonth() + 1) + '月' + p(d.getDate()) + '日';
}

/* ---------- 页面切换 ---------- */
function goTab(name) {
  document.querySelectorAll('.tab').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  const el = $('tab-' + name);
  if (el) el.classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
document.querySelectorAll('.tabs button').forEach(b => {
  b.addEventListener('click', () => goTab(b.dataset.tab));
});

/* ---------- 通用加载提示 ---------- */
function showLoading(container, text) {
  hideLoading();
  const d = document.createElement('div');
  d.className = 'loading';
  d.id = 'loadingBox';
  d.innerHTML = '<span class="spin"></span><span>' + escHtml(text || 'AI 正在处理，请稍候…') + '</span><button class="cancel-btn" onclick="cancelCurrentRequest()">取消</button>';
  (typeof container === 'string' ? $(container) : container).appendChild(d);
}
function hideLoading() {
  const d = $('loadingBox');
  if (d) d.remove();
}

/* ---------- 统一 AI 调用（多模型 + 费用台账） ---------- */
function estCost(p, inT, outT) {
  const r = (state.rates && state.rates[p]) || DEFAULT_STATE.rates[p] || { in: 0, out: 0 };
  return ((inT || 0) * r.in + (outT || 0) * r.out) / 1000000;
}
function abortableSleep(ms, ctrl) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => { ctrl.signal.removeEventListener('abort', onAbort); resolve(); }, ms);
    function onAbort() {
      clearTimeout(t);
      ctrl.signal.removeEventListener('abort', onAbort);
      reject(new DOMException('Aborted', 'AbortError'));
    }
    ctrl.signal.addEventListener('abort', onAbort);
  });
}
/* 429 业务码分类（智谱官方错误码：1302 账户速率 / 1305 平台过载 / 1308-1321 额度上限 / 1113 欠费） */
function classifyRateLimit(code, msg) {
  const t = String(msg || '') + ' ' + String(code || '');
  if (/欠费|1113/.test(t)) return 'balance';
  if (/使用上限|限额|1308|1310|1316|1317|1318|1319|1320|1321/.test(t)) return 'quota';
  if (/访问量过大|服务过载|过载|1305/.test(t)) return 'overload';
  if (/速率限制|并发|请求过于频繁|输入过于频繁|过于密集|限流|1302|1313/.test(t)) return 'account';
  return 'generic';
}
const channelLimitedUntil = {};
function channelLimited(cp) { return (channelLimitedUntil[cp] || 0) > Date.now(); }
function markChannelLimited(cp, ms) { channelLimitedUntil[cp] = Date.now() + ms; }
function providerChain() {
  const primary = state.provider;
  const hasKey = x => !!(state.keys && state.keys[x]) && !!((state.bases && state.bases[x]) || PROVIDERS[x].base);
  const backups = ['qwen', 'deepseek', 'custom'].filter(x => x !== primary && hasKey(x));
  let list = [primary, ...backups];
  if (channelLimited(primary) && backups.length) {
    list = [...backups.filter(b => !channelLimited(b)), primary, ...backups.filter(b => channelLimited(b))];
  }
  return list;
}
async function callLLM(messages, opts) {
  opts = opts || {};
  const primary = state.provider;
  if (!(state.keys && state.keys[primary])) {
    const err = new Error('未配置 API 密钥，请先到「模型与费用」填写');
    err.needSetup = true;
    throw err;
  }
  if (!((state.bases && state.bases[primary]) || PROVIDERS[primary].base)) {
    const err = new Error('未配置接口地址');
    err.needSetup = true;
    throw err;
  }
  const ctrl = new AbortController();
  activeCtrl = ctrl;
  cancelRequested = false;
  const timer = setTimeout(() => ctrl.abort(), opts.timeout || 180000);
  const finish = () => {
    clearTimeout(timer);
    if (activeCtrl === ctrl) activeCtrl = null;
  };
  const timeoutSec = Math.round((opts.timeout || 180000) / 1000);
  const abortMsg = () => cancelRequested ? '已取消本次请求' : '请求超时（' + timeoutSec + ' 秒）：已自动停止，请重试或换更快的模型';
  const abortErr = () => { finish(); return new Error(abortMsg()); };
  const waitAbortable = async ms => {
    try { await abortableSleep(ms, ctrl); } catch (ab) { throw abortErr(); }
  };
  const WAITS = window.__WAITS || { overload: [10000, 25000], generic: [5000, 12000], err: [2000, 5000] };
  const COOLDOWN = { account: 45000, quota: 60000, overload: 30000, generic: 20000 };
  let lastRate = null;
  let lastErr = null;

  const tryProvider = async (cp, pi) => {
    const base = (state.bases && state.bases[cp]) || PROVIDERS[cp].base;
    const model = (state.models && state.models[cp]) || PROVIDERS[cp].model;
    const key = state.keys && state.keys[cp];
    for (let attempt = 0; ; attempt++) {
      let res = null;
      try {
        const gap = lastCallAt + REQUEST_GAP_MS - Date.now();
        if (gap > 0) await waitAbortable(gap);
        lastCallAt = Date.now();
        res = await fetch(base, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
          body: JSON.stringify({
            model: model,
            messages: messages,
            temperature: opts.temp != null ? opts.temp : 0.3,
            max_tokens: opts.maxTokens || 8192,
            stream: false
          }),
          signal: ctrl.signal
        });
      } catch (e) {
        if (e.name === 'AbortError' || ctrl.signal.aborted) throw abortErr();
        if (attempt < WAITS.err.length) {
          const wait = WAITS.err[attempt] + Math.floor(Math.random() * 800);
          toast('网络异常（' + PROVIDERS[cp].label + '），' + Math.round(wait / 1000) + ' 秒后自动重试…');
          await waitAbortable(wait);
          continue;
        }
        lastErr = new Error('网络请求失败：' + e.message);
        return null;
      }
      if (!res.ok) {
        let j = null, msg = '';
        try { j = await res.json(); msg = (j.error && (j.error.message || JSON.stringify(j.error))) || ''; } catch (e) {}
        const code = (j && j.error && String(j.error.code || '')) || '';
        const t = (msg + ' ' + code).toLowerCase();
        if (res.status === 401) { finish(); throw new Error('API 密钥无效或已过期（' + PROVIDERS[cp].label + '）：' + msg.slice(0, 120)); }
        if (res.status === 402 || /insufficient|余额|balance|欠费/.test(t)) { finish(); throw new Error('账户余额不足（' + PROVIDERS[cp].label + '）：请充值或换其他通道'); }
        const rate = classifyRateLimit(code, msg);
        if (res.status === 429 || /(too many requests|rate.?limit|请求过于频繁|输入过于频繁|限流|访问量过大|速率限制|使用上限)/i.test(t)) {
          if (rate === 'balance') { finish(); throw new Error('账户欠费（' + PROVIDERS[cp].label + '）：' + msg.slice(0, 120)); }
          lastRate = lastRate || { type: rate, msg: msg, code: code, provider: cp };
          markChannelLimited(cp, COOLDOWN[rate] || 20000);
          if (rate === 'account' || rate === 'quota') return null;
          const waitArr = rate === 'overload' ? WAITS.overload : WAITS.generic;
          if (attempt >= waitArr.length) return null;
          const retryAfter = parseInt((res.headers && res.headers.get ? res.headers.get('retry-after') : '') || '', 10) * 1000 || 0;
          const wait = Math.max(waitArr[attempt] + Math.floor(Math.random() * 800), retryAfter);
          toast((rate === 'overload' ? '模型当前访问量大' : '请求过多') + '（' + PROVIDERS[cp].label + '），' + Math.round(wait / 1000) + ' 秒后自动重试…');
          await waitAbortable(wait);
          continue;
        }
        if (res.status >= 500 || res.status === 408) {
          if (attempt < WAITS.err.length) {
            const wait = WAITS.err[attempt] + Math.floor(Math.random() * 800);
            toast('服务暂时不稳定（' + res.status + '），' + Math.round(wait / 1000) + ' 秒后自动重试…');
            await waitAbortable(wait);
            continue;
          }
          lastErr = new Error('接口暂时不稳定（' + res.status + '）：请稍后再试');
          return null;
        }
        finish();
        throw new Error('接口返回错误（' + res.status + '）：' + (msg || '未知错误').slice(0, 200));
      }
      let j = null;
      try { j = await res.json(); } catch (e) { finish(); throw new Error('接口返回内容无法解析，请重试'); }
      const errMsg = (j.error && (j.error.message || JSON.stringify(j.error))) || '';
      const errCode = (j.error && String(j.error.code || '')) || '';
      if (!j.choices || !j.choices[0]) {
        const rate = classifyRateLimit(errCode, errMsg);
        if (/使用上限|访问量过大|速率限制|请求过于频繁|限流|限额|1302|1305|1308/.test(errMsg + ' ' + errCode)) {
          lastRate = lastRate || { type: rate, msg: errMsg, code: errCode, provider: cp };
          markChannelLimited(cp, COOLDOWN[rate] || 20000);
          return null;
        }
        finish();
        throw new Error('接口返回异常：' + (errMsg || '无有效内容').slice(0, 200));
      }
      const text = (j.choices[0].message && j.choices[0].message.content) || '';
      const u = j.usage || {};
      const inT = u.prompt_tokens || 0, outT = u.completion_tokens || 0;
      const cost = estCost(cp, inT, outT);
      state.ledger.unshift({ t: Date.now(), provider: cp, model: model, in: inT, out: outT, cost: cost, note: (opts.note || '') + (pi > 0 ? '（备用通道）' : '') });
      if (state.ledger.length > 500) state.ledger.length = 500;
      saveState();
      renderLedger();
      updateStats();
      finish();
      return { ok: true, text: text, inT: inT, outT: outT, cost: cost };
    }
  };

  const doCall = async () => {
    const providers = providerChain();
    for (let pi = 0; pi < providers.length; pi++) {
      const cp = providers[pi];
      if (pi > 0) toast('「' + PROVIDERS[cp].label + '」备用通道重试…');
      const out = await tryProvider(cp, pi);
      if (out && out.ok) return out;
      if (pi < providers.length - 1 && lastRate && lastRate.provider === cp) {
        toast('「' + PROVIDERS[cp].label + '」受限，自动切换备用通道…');
      }
    }
    finish();
    if (lastRate) {
      const r = lastRate;
      rateLimitedUntil = Date.now() + (COOLDOWN[r.type] || 30000);
      const channelName = (PROVIDERS[r.provider] && PROVIDERS[r.provider].label) || '当前通道';
      const resetInfo = (String(r.msg).match(/限额将在\s*([^，。；;]+?)\s*重置/) || [])[1] || '';
      const hints = {
        account: '「' + channelName + '」达到账户速率限制（免费档并发仅 1 路，避免多个页面同时操作），已尝试备用通道仍失败；请等待 1 分钟再试，或在「模型与费用」填好通义千问/DeepSeek 密钥',
        quota: '「' + channelName + '」使用额度已用尽' + (resetInfo ? '，约 ' + resetInfo + ' 重置' : '') + '；请到服务商控制台查看额度，或切换其他通道',
        overload: '「' + channelName + '」模型当前访问量过大（高峰时段常见），已按官方建议延长间隔重试并尝试备用通道仍失败；请稍等 30 秒~1 分钟再试',
        generic: '「' + channelName + '」请求被限流，已尝试备用通道仍失败；请稍后再试'
      };
      throw new Error('AI 请求失败：' + hints[r.type]);
    }
    throw lastErr || new Error('AI 请求失败，请重试');
  };

  const runWithLock = async () => {
    if (!(navigator.locks && navigator.locks.request)) return doCall();
    let entered = false;
    try {
      return await navigator.locks.request('legalai-ai-request-v1', { signal: ctrl.signal }, async () => {
        entered = true;
        return doCall();
      });
    } catch (e) {
      if (e.name === 'AbortError') throw abortErr();
      if (entered) throw e; // doCall 自身的错误原样抛出，禁止重跑
      return doCall();      // 仅锁 API 异常时降级直连
    }
  };
  return await runWithLock();
}

/* ---------- 文书系统提示词 ---------- */
const SYS = '你是“法务AI 3.2”的法律文书助手，服务对象是基层法律工作者和普通群众。严格规则：1）只依据用户提供的素材撰写，不编造事实、金额、日期、案号、人名；2）素材中缺失的信息一律写“（待补充）”，绝不猜测；3）引用法律条文必须真实，不确定就写“依据相关规定”；4）金额、利率、起算日等必须具体明确；5）文书末尾的具状人/申请人姓名与日期留空；6）标题居中，正文规范，段落清晰。';
const SYS_RESEARCH = '你是“法务AI 3.2”的法律研究助手。要求：1）回答必须引用真实存在的法律、行政法规、司法解释名称及条文号；2）不确定的内容明确说明；3）分点作答，便于阅读；4）最后单独一行注明“本回答由 AI 生成，仅供参考，不构成法律意见”。';

/* ==================== 案件档案 ==================== */
function toggleNewCase(show) {
  const f = $('caseForm');
  const showF = show == null ? f.style.display === 'none' : show;
  f.style.display = showF ? '' : 'none';
}
function saveNewCase() {
  const title = $('caseTitle').value.trim() || '未命名案件';
  const material = $('caseMaterial').value.trim();
  if (!material && !confirm('案件没有任何素材，仍要保存吗？')) return;
  const c = createV3Case({ title: title, material: material, source: 'new' });
  state.cases.unshift(c);
  saveState();
  renderCases();
  toggleNewCase(false);
  $('caseTitle').value = '';
  $('caseMaterial').value = '';
  toast('案件已保存');
}
function deleteCase(id) {
  const c = state.cases.find(x => x.id === id);
  if (!c || c.deletedAt) return;
  if (!confirm('确定删除这个案件吗？删除后可在数据备份中找回。')) return;
  c.deletedAt = Date.now();
  c.updatedAt = Date.now();
  c.timeline.push({ t: c.deletedAt, event: 'deleted' });
  saveState();
  renderCases();
  if (typeof closeCockpitIfCase === 'function') closeCockpitIfCase(id);
  toast('案件已删除（软删除）');
}

// v3.3：取案件最新一版文书（供打开案件与展示）
function latestCaseDocs(c) {
  const out = [];
  (c.documents || []).forEach(docId => {
    const g = state.documents && state.documents[docId];
    if (!g || !g.revisions || !g.revisions.length) return;
    const rev = g.revisions[g.revisions.length - 1];
    const d = { name: rev.name || '文书', text: (rev.content && rev.content.text) || '' };
    if (rev.content && rev.content.html) d.html = rev.content.html;
    out.push(d);
  });
  return out;
}

// v3.3：同案同文书名 → 追加 revision；否则新建 document 组并登记引用
function docGroupForCase(caseId, docName) {
  for (const k in state.documents) {
    const g = state.documents[k];
    if (g && g.caseId === caseId && g.revisions && g.revisions.length) {
      const last = g.revisions[g.revisions.length - 1];
      if (last.name === docName) return g;
    }
  }
  return null;
}

function snapshotFromDraft() {
  const d = currentDraft.lastData || null;
  return {
    parties: {
      plaintiffs: (d && d.plaintiff && d.plaintiff.name) ? [d.plaintiff] : [],
      defendants: (d && d.defendant && d.defendant.name) ? [d.defendant] : []
    },
    claims: (d && d.claims) || [],
    evidence: (d && d.evidence) || [],
    facts: (d && d.facts) || [],
    basis: (d && d.basis) || '',
    total: (d && d.total) || '',
    court: (d && d.court) || '',
    caseType: (d && d.caseType) || currentDraft.caseType || ''
  };
}

function openCase(id) {
  const c = state.cases.find(x => x.id === id);
  if (!c || c.deletedAt) return;
  const docs = latestCaseDocs(c);
  currentDraft = { mode: 'complaint', caseType: c.caseType || '', material: c.material || '', analysis: '', docs: docs, caseId: c.id, lastData: null, lastAiMeta: null };
  setDraftMode('complaint');
  $('draftMaterial').value = c.material || '';
  $('draftPrep').style.display = 'none';
  $('draftResult').style.display = 'none';
  if (docs.length) {
    renderDraftDocs(docs);
    $('draftResult').style.display = '';
  }
  goTab('draft');
  toast('已打开案件：' + c.title);
}
function renderCases() {
  const box = $('caseList');
  const q = caseSearchText.trim().toLowerCase();
  let alive = state.cases.filter(c => !c.deletedAt);
  if (q) {
    alive = alive.filter(c => {
      const hay = [c.title, c.caseNo, c.court, c.caseType, (c.tags || []).join(' ')].join(' ').toLowerCase();
      return hay.indexOf(q) >= 0;
    });
  }
  if (!alive.length) {
    box.innerHTML = '<div class="sub" style="margin:8px 0 0">' + (state.cases.some(c => !c.deletedAt) ? '没有符合条件的案件，换个关键词试试。' : '还没有案件。点「新建案件」开始，或在「材料撰写」生成文书后一键存入。') + '</div>';
    return;
  }
  box.innerHTML = alive.map(c => {
    const n = (c.documents || []).length;
    const st = '<span class="case-status" style="background:' + statusColor(c.status) + '22;color:' + statusColor(c.status) + '">' + statusLabel(c.status) + '</span>';
    return '<div class="case-card">' +
      '<div><div class="tt">' + st + escHtml(c.title) + '</div>' +
      '<div class="mt">更新于 ' + fmtTime(c.updatedAt) + ' · 文书 ' + n + ' 份</div></div>' +
      '<div style="display:flex;gap:6px;flex-shrink:0">' +
      '<button class="btn btn-gold btn-sm" onclick="goCockpit(\'' + c.id + '\')">🚀 驾驶舱</button>' +
      '<button class="btn btn-primary btn-sm" onclick="openCase(\'' + c.id + '\')">打开</button>' +
      '<button class="btn btn-red btn-sm" onclick="deleteCase(\'' + c.id + '\')">删除</button></div></div>';
  }).join('');
  if (typeof renderTrash === 'function') renderTrash();
}
function onCaseSearch(v) {
  caseSearchText = String(v || '');
  renderCases();
}
function saveDraftToCase() {
  const texts = currentDraft.docs.map(d => d.text).filter(t => t);
  if (!texts.length) { toast('当前没有可保存的文书'); return; }
  const title = (currentDraft.material || '').split('\n')[0].slice(0, 24) || '未命名案件';
  let c;
  if (currentDraft.caseId) {
    c = state.cases.find(x => x.id === currentDraft.caseId && !x.deletedAt);
  }
  if (!c) {
    // 新建案件：素材一次性写入源数据
    c = createV3Case({ title: title, material: currentDraft.material || '', source: 'draft' });
    state.cases.unshift(c);
  }
  // 关键：已有案件绝不覆盖 case.material（Case=源数据，Document=生成结果）
  const now = Date.now();
  const snap = snapshotFromDraft();
  const ai = currentDraft.lastAiMeta || null;
  // 回填文书组模板元数据（docType / caseType / canonicalKey / templateId）
  const mdCaseType = (currentDraft.lastData && currentDraft.lastData.caseType) || currentDraft.caseType || '';
  const mdDocType = mdCaseType ? docTypeForMode(currentDraft.mode || 'complaint', mdCaseType) : '';
  const mdKey = mdCaseType ? mdDocType + ':' + normalizeCaseType(mdCaseType) : '';
  const mdTpl = mdKey ? findTemplate(mdDocType, mdCaseType) : null;
  currentDraft.docs.forEach((d, i) => {
    const name = d.name || ('文书' + (i + 1));
    let g = docGroupForCase(c.id, name);
    if (!g) {
      const gid = 'doc_' + c.id + '_' + ((c.documents || []).length + 1);
      g = { id: gid, caseId: c.id, templateId: mdTpl ? mdTpl.id : null, canonicalKey: mdKey, revisions: [], createdAt: now, updatedAt: now };
      state.documents[gid] = g;
      c.documents.push(gid);
    } else if (!g.canonicalKey && mdKey) {
      g.templateId = mdTpl ? mdTpl.id : null;
      g.canonicalKey = mdKey;
    }
    const revNo = g.revisions.length + 1;
    g.revisions.push({
      revision: revNo,
      name: name,
      status: 'generated',
      content: { html: d.html || null, text: d.text || '', docx: null },
      snapshot: snap,
      aiMeta: ai || { provider: '', model: '', generatedAt: now, tokens: { in: 0, out: 0 }, cost: 0 },
      checks: [],
      createdAt: now,
      updatedAt: now
    });
    g.updatedAt = now;
  });
  c.updatedAt = now;
  c.status = c.status === 'submitted' || c.status === 'closed' ? c.status : 'in_progress';
  c.timeline.push({ t: now, event: 'document_saved' });
  currentDraft.caseId = c.id;
  saveState();
  renderCases();
  toast('已存入案件档案');
}

/* ==================== 材料撰写 ==================== */
const MODE_NAMES = {
  complaint: '起诉状（双版）', answer: '答辩状', exec: '强制执行申请书（要素式）',
  petition: '信访反映材料', change: '变更诉讼请求申请书', generic: '其他文书'
};
function setDraftMode(mode) {
  currentDraft.mode = mode;
  document.querySelectorAll('#draftModeRow .mode-chip').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
  $('typeRow').style.display = (mode === 'complaint' || mode === 'answer' || mode === 'exec' || mode === 'generic') ? '' : 'none';
  if (mode !== 'complaint' && $('draftElemForm')) {
    $('draftElemForm').style.display = 'none';
    elemFormFilled = false;
  }
  if (typeof applyDraftModeLabels === 'function') applyDraftModeLabels(mode);
}
document.querySelectorAll('#draftModeRow .mode-chip').forEach(b => {
  b.addEventListener('click', () => setDraftMode(b.dataset.mode));
});

function populateCaseTypes() {
  const sel = $('caseTypeSel');
  sel.innerHTML = '<option value="">—— 请选择案由（可留空让 AI 识别）——</option>';
  CASE_TYPES.forEach(g => {
    const og = document.createElement('optgroup');
    og.label = g.g;
    g.items.forEach(n => {
      const o = document.createElement('option');
      o.value = n;
      o.textContent = n;
      og.appendChild(o);
    });
    sel.appendChild(og);
  });
}

/* ============ v3.3 第六批：exec/answer 官方要素表页面链路 ============ */
function officialCanMatchForMode(mode, caseType) {
  const n = String(caseType || '').trim();
  if (!n || typeof findTemplate !== 'function' || typeof docTypeForMode !== 'function') return false;
  const m = String(mode || 'complaint');
  const dt = docTypeForMode(m, n);
  return !!(dt && findTemplate(dt, n));
}

// complaint 走既有双版；exec 需要官方目标；answer 仅在已选官方行政答辩状时进入要素表流程
function elemFlowEligible(mode, selCaseType) {
  if (mode === 'complaint') return true;
  if (mode === 'answer') return true; // 答辩状已按案由挂接官方版式（民事/行政/刑事自诉/国家赔偿四类）
  if (mode === 'exec') {
    if (officialCanMatchForMode('exec', selCaseType)) return true;
    const dt = (typeof docTypeForMode === 'function') ? docTypeForMode('exec', selCaseType) : '';
    return !!(dt && typeof layoutMatchFor === 'function' && layoutMatchFor(selCaseType, dt));
  }
  return false;
}

const ELEM_UI_LABELS = {
  complaint: {
    type: '② 案由（起诉状/答辩状/其他文书选填，AI 也会自动识别）',
    sub: '起诉状双版引擎：AI 已自动提取要素，可修改后一键生成「要素式＋传统式」',
    p: '👤 原告', d: '👥 被告',
    claims: '诉讼请求（每行一项）',
    ev: '证据清单（每行一项：名称｜来源/形式｜证明目的）',
    btn: '✍️ 生成双版文书（要素式＋传统式）'
  },
  exec: {
    type: '② 执行/申请类型（强制执行/参与分配/执行异议等，AI 也会识别）',
    sub: '官方要素表：按法〔2025〕82号《强制执行申请书》示范文本回填',
    p: '👤 申请执行人', d: '👥 被执行人',
    claims: '申请执行事项（每行一项：本金/利息/费用/行为，写明金额）',
    ev: '随附材料与证据（每行一项：名称｜形式｜证明目的）',
    btn: '✍️ 生成官方要素表文书'
  },
  compensation: {
    type: '② 案由（国家赔偿：违法刑事拘留/刑事改判无罪/怠于履行监管职责/错误执行等）',
    sub: '官方要素表：按法〔2025〕82号《国家赔偿申请书》示范文本回填',
    p: '👤 赔偿请求人', d: '👥 赔偿义务机关',
    claims: '赔偿请求（每行一项：项目与金额）',
    ev: '证据材料（每行一项：名称｜形式｜证明目的）',
    btn: '✍️ 生成官方要素表文书'
  },
  answer: {
    type: '② 案由（答辩状：选具体案由即按对应的官方答辩状要素表回填；留空由 AI 判断）',
    sub: '官方要素表：按法〔2025〕82号答辩状示范文本回填（民事 33 类 / 行政 2 类 / 刑事自诉 4 类 / 国家赔偿 4 类）',
    p: '👤 被答辩人（原审原告）', d: '👥 答辩人',
    claims: '答辩请求（每行一项）',
    ev: '证据清单（每行一项：名称｜形式｜证明目的）',
    btn: '✍️ 生成官方要素表文书'
  }
};

function applyDraftModeLabels(mode) {
  const selVal = ($('caseTypeSel') ? $('caseTypeSel').value : '') || currentDraft.caseType || '';
  let fam = 'complaint';
  if (mode === 'exec') fam = 'exec';
  else if (mode === 'answer') fam = (elemOfficialKey(selVal, 'answer') || (typeof layoutMatchFor === 'function' && layoutMatchFor(selVal, docTypeForMode('answer', selVal)))) ? 'answer' : 'complaint';
  else if (mode === 'complaint' && elemOfficialKey(selVal, 'complaint')) {
    const dt = docTypeForMode('complaint', selVal);
    if (dt === 'compensation') fam = 'compensation';
    else if (dt === 'exec') fam = 'exec';
    else if (dt === 'answer') fam = 'answer';
  }
  const L = ELEM_UI_LABELS[fam] || ELEM_UI_LABELS.complaint;
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  set('typeRowLabel', L.type);
  set('elemFormSub', L.sub);
  set('elemPartyP', L.p);
  set('elemPartyD', L.d);
  set('elemClaimsLabel', L.claims);
  set('elemEvidenceLabel', L.ev);
  const b = $('btnElemGen');
  if (b) b.textContent = L.btn;
}

function elemRoleWords(mode, caseType) {
  const fam = mode === 'exec' ? 'exec'
    : (elemOfficialKey(caseType || '', mode) || (mode === 'answer' && caseType ? 'answer' : ''));
  if (fam === 'exec') return { p: '申请执行人', d: '被执行人', claims: '申请执行事项', ev: '随附材料与证据' };
  if (fam === 'compensation') return { p: '赔偿请求人', d: '赔偿义务机关', claims: '赔偿请求', ev: '证据材料' };
  if (fam === 'answer') return { p: '被答辩人', d: '答辩人', claims: '答辩请求', ev: '证据清单' };
  return { p: '原告', d: '被告', claims: '诉讼请求', ev: '证据清单' };
}

function genDraftFromElemForm() {
  const mode = (currentDraft && currentDraft.mode) || 'complaint';
  if (mode === 'complaint') return genDualComplaint();
  return genOfficialElemDoc();
}

async function draftAnalyze(force) {
  if (!tryLock()) return;
  const material = $('draftMaterial').value.trim();
  if (!material) { unlock(); toast('请先粘贴素材'); return; }
  const mode = currentDraft.mode;
  const selNow = $('caseTypeSel').value || currentDraft.caseType || '';
  const officialFlow = elemFlowEligible(mode, selNow);
  currentDraft.material = material;
  const btn = $('btnDraftStart');
  btn.disabled = true;
  elemFormFilled = false;
  $('draftElemForm').style.display = 'none';
  $('draftPrep').style.display = '';
  $('draftPrepText').innerHTML = '<span class="loading"><span class="spin"></span>AI 正在分析素材，识别文书类型与关键要素…<button class="cancel-btn" onclick="cancelCurrentRequest()">取消</button></span>';
  try {
    let prompt = '请分析下面的素材，判断应出具什么文书，并整理关键要素。\n目标文书类型：' + MODE_NAMES[mode] + '\n素材：\n' + material +
      '\n\n请按以下格式输出（不要用表格）：\n文书类型：…\n案由：…\n当事人：…\n关键事实：1)… 2)…\n风险与注意（时效/管辖/证据/利率金额等）：1)… 2)…\n缺失信息（需要当事人补充的）：1)… 2)…';
    if (officialFlow) {
      prompt += '\n\n分析完成后，在最后单独输出一个 JSON 对象（不要 Markdown 代码块，不要额外解释），严格按此结构：\n';
      if (mode === 'complaint') {
        prompt += '{"caseType":"案由名称","plaintiff":{"type":"自然人/法人或其他组织","name":"","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":"","workUnit":"","position":"","legalRep":"","legalRepPosition":"","creditCode":"","regAddr":"","orgType":"","ownership":""},"defendant":{"type":"自然人/法人或其他组织","name":"","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":"","workUnit":"","position":"","legalRep":"","legalRepPosition":"","creditCode":"","regAddr":"","orgType":"","ownership":""},"claims":["诉讼请求1","诉讼请求2"],"evidence":["证据1（名称｜来源/形式｜证明目的）"],"factFields":{"与案由相关的要素标签":"内容"},"elements":{"官方要素表行标签":"该行应填内容"},"factReason":"","court":"受理法院，未知则空"}\n';
        prompt += '当事人说明：原告/被告是公司、机关、事业单位、合作社等单位的，type 填“法人或其他组织”，并尽量给出 legalRep（法定代表人/负责人）、creditCode（统一社会信用代码）、regAddr（注册地/登记地）、orgType（企业类型，如“有限责任公司”）、ownership（所有制性质）；个人则 type 填“自然人”，并给出工作单位（workUnit）、职务（position）。\n';
      } else if (mode === 'exec') {
        prompt += '{"caseType":"执行/申请类型名称（如：强制执行/参与分配/执行异议等）","plaintiff":{"type":"自然人/法人或其他组织","name":"","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":"","workUnit":"","position":"","legalRep":"","creditCode":""},"defendant":{"type":"自然人/法人或其他组织","name":"","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":"","workUnit":"","position":"","legalRep":"","creditCode":""},"claims":["申请执行事项1（本金/利息/费用写明金额）","申请执行事项2"],"evidence":["随附材料或财产线索（名称｜形式｜证明目的）"],"factFields":{"与执行申请书相关的要素标签":"内容"},"elements":{"官方要素表行标签":"该行应填内容"},"factReason":"","court":"执行法院，未知则空"}\n';
        prompt += '说明：plaintiff 为申请执行人（原权利人），defendant 为被执行人；素材未提及的字段一律为空字符串或空数组，绝不编造。\n';
      } else if (mode === 'answer') {
        prompt += '{"caseType":"案由（民事/行政/刑事自诉/国家赔偿，如：买卖合同纠纷、行政答辩状（通用））","plaintiff":{"type":"自然人/法人或其他组织","name":"原审原告/被答辩人","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":"","legalRep":"","creditCode":""},"defendant":{"type":"自然人/法人或其他组织","name":"答辩人","gender":"","birth":"","nation":"","idNo":"","addr":"","liveAddr":"","phone":"","legalRep":"","creditCode":""},"claims":["答辩请求1","答辩请求2"],"evidence":["证据1（名称｜来源/形式｜证明目的）"],"factFields":{"与答辩状相关的要素标签":"内容"},"elements":{"官方要素表行标签":"该行应填内容（如“有☑ 异议内容：…”“无☑”）"},"factReason":"","court":"受理法院，未知则空"}\n';
        prompt += '说明：defendant 为答辩人（行政机关/授权组织），plaintiff 为原审原告；素材未提及的字段一律为空字符串或空数组，绝不编造。\n';
      }
      prompt += '要求：素材未提及的字段一律为空字符串或空数组，绝不编造。\n';
      let labels = [];
      const key = elemKeyOf($('caseTypeSel').value || currentDraft.caseType || '');
      if (mode === 'complaint') {
        labels = []; // complaint 继续用全部要素表提示
      } else if (key && fieldsSource(key)) {
        labels = fieldsSource(key).map(f => f.label);
      }
      if (mode === 'complaint') {
        prompt += 'factFields 的键必须从下面与你所选案由对应的要素表中原样选取（不要改写、不要加标点、不要合并）：\n' + elemLabelSpec();
      } else if (labels.length) {
        prompt += 'factFields 的键必须从下面原样选取（不要改写、不要加标点、不要合并）：\n' + labels.join('、') + '\n';
      }
      // 各文书类型通用：把官方要素表逐行清单交给 AI，直接产出可填入每一行的内容
      const rowLabels = elemOfficialRowLabels($('caseTypeSel').value || currentDraft.caseType || '', mode);
      if (rowLabels.length) {
        prompt += '\n\nelements 用于直接填官方要素表：键必须原样取自下面《本案由官方要素表行清单》，不要改写、不要加标点、不要遗漏案件涉及的项。\n' +
          '值的要求：按该行原本的填写格式给出，模板已有的文字要保留、只把空白处补全（例：本金行 → “截至2024年6月1日止，尚欠本金50000元”；答辩行 → “无☑”或“有☑ 异议内容：…”）；有勾选框的用“☑”表示选中、未选的保留“□”；素材未涉及的行不要编造，直接省略该键。\n' +
          '官方要素表行清单：\n' + rowLabels.join('、');
      }
    }
    const r = await callLLM([
      { role: 'system', content: SYS },
      { role: 'user', content: prompt }
    ], { temp: 0.2, note: '材料分析·' + MODE_NAMES[mode] });
    currentDraft.analysis = r.text;
    currentDraft.lastAiMeta = {
      provider: state.provider,
      model: (state.models && state.models[state.provider]) || '',
      generatedAt: Date.now(),
      tokens: { in: r.inT || 0, out: r.outT || 0 },
      cost: r.cost || 0
    };
    const caseTypeMatch = r.text.match(/案由[：:]\s*(.+)/);
    if (caseTypeMatch && caseTypeMatch[1].replace(/[（(].*?[)）]/g, '').trim().length < 30) {
      currentDraft.caseType = caseTypeMatch[1].trim();
      $('caseTypeSel').value = currentDraft.caseType;
    }
    let displayText = r.text;
    let elemObj = null;
    if (officialFlow) {
      const sp = splitAnalysisJson(r.text);
      elemObj = sp.obj;
      if (elemObj) displayText = sp.text || '（分析完成，请在下方要素表单核对、修改）';
    }
    $('draftPrepText').innerHTML = '<pre style="white-space:pre-wrap;font-family:inherit;font-size:14px;line-height:1.8">' + escHtml(displayText) + '</pre>';
    $('draftPrep').style.display = '';
    if (officialFlow) {
      if (elemObj) {
        fillElemForm(elemObj);
        const issues = checkMaterialCompleteness(material);
        if (issues.length) {
          const mbox = $('elemMissing');
          mbox.style.display = '';
          mbox.innerHTML = '⚠️ ' + issues.map(escHtml).join('<br>');
        }
      } else {
        await runExtractFill();
      }
    }
  } catch (e) {
    if (e.needSetup) { goTab('settings'); }
    $('draftPrepText').innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    btn.disabled = false;
    unlock();
  }
}

function draftPrompt(mode) {
  const material = currentDraft.material;
  const caseType = $('caseTypeSel').value || currentDraft.caseType || '';
  if (mode === 'complaint') {
    return '请根据素材生成起诉状，一案两份、内容一致：\n' +
      '第一份以“【要素式】' + (caseType || '民事起诉状') + '”为标题：按最高法要素式示范文本结构——当事人信息、诉讼请求和依据、事实和理由、证据清单、此致XX人民法院。\n' +
      '第二份以“【传统式】民事起诉状”为标题：完整叙述式——标题、当事人、诉讼请求、事实与理由、证据清单、此致。\n' +
      '两份之间用单独一行“=====要素式完毕=====”分隔。案由（如有）：' + (caseType || '由你判断') + '。\n素材：\n' + material;
  }
  if (mode === 'exec') {
    return '请根据下面的判决书/调解书/裁定书或执行素材，生成《强制执行申请书（要素式）》，按最高法要素式示范文本：申请执行人、被执行人、执行依据（案号、作出机关、生效日期）、申请执行事项（本金、利息、费用等金额明确）、事实与理由、此致XX人民法院、附件提示。缺失信息写（待补充）。\n素材：\n' + material;
  }
  if (mode === 'petition') {
    return '请生成规范的《信访反映材料》：信访人信息、被反映单位/人员、反映事项、事实经过、诉求、联系方式。缺失写（待补充），语气客观。\n素材：\n' + material;
  }
  if (mode === 'change') {
    return '请生成《变更诉讼请求申请书》：申请人、被申请人、案号（如有）、原诉讼请求、变更后诉讼请求、变更理由、此致XX人民法院。缺失写（待补充）。\n素材：\n' + material;
  }
  if (mode === 'answer') {
    return '请生成《民事答辩状》：答辩人、被答辩人、案号（如有）、答辩请求、针对起诉的事实与理由逐项答辩（认可/不认可及依据）、此致XX人民法院。缺失写（待补充）。案由（如有）：' + (caseType || '由你判断') + '。\n素材：\n' + material;
  }
  return '请根据素材生成合适的法律文书（案由：' + (caseType || '由你判断') + '）。缺失信息写（待补充）。\n素材：\n' + material;
}

async function draftGenerate() {
  if (!tryLock()) return;
  if (!currentDraft.material) { toast('请先粘贴素材'); return; }
  const mode = currentDraft.mode;
  if (mode === 'complaint') {
    unlock();
    return genDualComplaint();
  }
  if ((mode === 'exec' || mode === 'answer') &&
      elemFlowEligible(mode, $('caseTypeSel').value || currentDraft.caseType || '')) {
    unlock();
    return genOfficialElemDoc();
  }
  $('draftPrep').style.display = '';
  $('draftPrepText').innerHTML = '<span class="loading"><span class="spin"></span>AI 正在起草文书（' + MODE_NAMES[mode] + '），一般 30~90 秒…<button class="cancel-btn" onclick="cancelCurrentRequest()">取消</button></span>';
  const btn = $('btnDraftGenerate');
  btn.disabled = true;
  try {
    const r = await callLLM([
      { role: 'system', content: SYS },
      { role: 'user', content: draftPrompt(mode) }
    ], { temp: 0.3, note: '生成·' + MODE_NAMES[mode] });
    const docs = splitDocs(r.text, mode);
    currentDraft.docs = docs;
    currentDraft.lastData = null;
    currentDraft.lastAiMeta = {
      provider: state.provider,
      model: (state.models && state.models[state.provider]) || '',
      generatedAt: Date.now(),
      tokens: { in: r.inT || 0, out: r.outT || 0 },
      cost: r.cost || 0
    };
    renderDraftDocs(docs);
    $('draftPrep').style.display = 'none';
    $('draftResult').style.display = '';
    $('selfCheckArea').innerHTML = '';
    window.scrollTo({ top: $('draftResult').offsetTop - 90, behavior: 'smooth' });
  } catch (e) {
    if (e.needSetup) goTab('settings');
    $('draftPrepText').innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    btn.disabled = false;
    unlock();
  }
}

function splitDocs(text, mode) {
  if (mode === 'complaint') {
    const parts = text.split('=====要素式完毕=====');
    if (parts.length >= 2) {
      return [
        { name: '要素式起诉状', text: parts[0].trim() },
        { name: '传统式起诉状', text: parts.slice(1).join(' ').trim() }
      ];
    }
    const m = text.match(/(【传统式】[^]*)/);
    if (m) {
      const idx = text.indexOf(m[1]);
      return [
        { name: '要素式起诉状', text: text.slice(0, idx).trim() },
        { name: '传统式起诉状', text: m[1].trim() }
      ];
    }
    return [{ name: MODE_NAMES[mode], text: text.trim() }];
  }
  return [{ name: MODE_NAMES[mode], text: text.trim() }];
}

function renderDraftDocs(docs) {
  const tabs = $('docTabs');
  tabs.innerHTML = '';
  const showDoc = (d, b) => {
    tabs.querySelectorAll('button').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    if (d.html) {
      $('docBody').innerHTML = d.html;
      curDocText = d.text;
      curDocHtml = d.html;
    } else {
      $('docBody').textContent = d.text;
      curDocText = d.text;
      curDocHtml = null;
    }
    curDocName = docFileName(d, '');
    $('selfCheckArea').innerHTML = '';
  };
  docs.forEach((d, i) => {
    const b = document.createElement('button');
    b.textContent = d.name;
    b.className = i === 0 ? 'active' : '';
    b.onclick = () => {
      showDoc(d, b);
    };
    tabs.appendChild(b);
  });
  showDoc(docs[0], tabs.querySelector('button'));
}

function clearDraft() {
  $('draftMaterial').value = '';
  $('draftPrep').style.display = 'none';
  $('draftResult').style.display = 'none';
  $('selfCheckArea').innerHTML = '';
  $('draftElemForm').style.display = 'none';
  elemFormFilled = false;
  currentDraft = { mode: 'complaint', caseType: '', material: '', analysis: '', docs: [], caseId: null, lastData: null, lastAiMeta: null };
  setDraftMode('complaint');
}

function copyDoc() {
  const text = curDocText || $('docBody').textContent;
  if (!text) { toast('没有可复制的内容'); return; }
  const done = () => toast('已复制到剪贴板');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch (e) { toast('复制失败，请手动选择复制'); }
  ta.remove();
}
function tradTextToHtml(text) {
  const lines = String(text || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (!lines.length) return '<p class="trad-p"></p>';
  const out = [];
  let first = true;
  let rightMode = false;
  const secRe = /^(诉讼请求|请求事项|事实与理由|事实理由|案件事实与理由|答辩请求|答辩事项|答辩依据|证据清单|证据和证据来源|证据及证据来源|法律依据|执行依据|申请执行事项|申请事项)[：:、\s]*$/;
  const rightRe = /^(具状人|起诉人|申请人|赔偿请求人|答辩人|自诉人)[（(]?[签字盖章签名]*[）)]?[：:]|^日期[：:]/;
  for (let ln of lines) {
    if (first && ln.length < 32 && /(起诉状|答辩状|申请书|意见书|自诉状)/.test(ln)) {
      out.push('<p class="trad-title">' + escHtml(ln) + '</p>');
      first = false;
      rightMode = false;
      continue;
    }
    first = false;
    if (rightRe.test(ln) || (rightMode && ln.length < 40 && ln.indexOf('：') < 0 && !secRe.test(ln))) {
      out.push('<p class="trad-right">' + escHtml(ln) + '</p>');
      rightMode = true;
      continue;
    }
    rightMode = false;
    const sec = secRe.test(ln);
    out.push('<p class="trad-p' + (sec ? ' trad-sec' : '') + '">' + escHtml(ln) + '</p>');
  }
  return out.join('\n');
}
function exportDoc() {
  const text = curDocText || $('docBody').textContent;
  if (!text && !curDocHtml) { toast('没有可导出的内容'); return; }
  const stamp = today().replace(/[年月日]/g, '');
  const base = curDocName || docFileName({ name: '法律文书' }, '');
  const title = docTitleText();
  const html = curDocHtml
    ? wordHtmlShell(curDocHtml, title)
    : "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>" + escHtml(title) + "</title></head><body style='font-family:仿宋,SimSun;font-size:16px;line-height:2;'><pre style='white-space:pre-wrap;font-family:仿宋,SimSun;font-size:16px;line-height:2;'>" + escHtml(text) + "</pre></body></html>";
  const blob = new Blob(['\ufeff' + html], { type: 'application/msword' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = base.replace(/_\d{8}$/, '') + '_' + stamp + '.doc';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  toast('已导出 Word（.doc）');
}
function printDoc() {
  const text = curDocText || $('docBody').textContent;
  if (!text && !curDocHtml) { toast('没有可打印的内容'); return; }
  const w = window.open('', '_blank');
  if (!w) { toast('浏览器拦截了打印窗口，请允许弹窗'); return; }
  const title = docTitleText();
  w.document.write(curDocHtml
    ? "<html><head><meta charset='utf-8'><title>" + escHtml(title) + "</title><style>body{font-family:仿宋,SimSun;font-size:16px;line-height:1.8;padding:30px;}table.elem-official{width:100%;border-collapse:collapse;}table.elem-official th,table.elem-official td{border:1px solid #000;padding:5px 8px;vertical-align:top;text-align:left;font-size:14px;}table.elem-official tr.sec-full.sec-ct td{font-size:15pt;}table.elem-official th{text-align:center;}</style></head><body>" + curDocHtml + "<script>window.onload=function(){window.print();}<\/script></body></html>"
    : "<html><head><meta charset='utf-8'><title>" + escHtml(title) + "</title><style>body{font-family:仿宋,SimSun;font-size:16px;line-height:2;padding:40px;}pre{white-space:pre-wrap;font-family:仿宋,SimSun;}</style></head><body><pre>" + escHtml(text) + "</pre><script>window.onload=function(){window.print();}<\/script></body></html>");
  w.document.close();
}
async function selfCheck() {
  const text = curDocText || $('docBody').textContent;
  if (!text) { toast('请先生成文书'); return; }
  if (!tryLock()) return;
  const box = $('selfCheckArea');
  box.innerHTML = '<span class="loading"><span class="spin"></span>AI 正在复核文书…<button class="cancel-btn" onclick="cancelCurrentRequest()">取消</button></span>';
  try {
    const r = await callLLM([
      { role: 'system', content: SYS },
      { role: 'user', content: '请复核以下法律文书，逐条指出：1）事实、金额、日期是否与素材一致；2）法律依据是否准确；3）格式是否规范；4）缺失项。只输出问题清单和修改建议，不要重写全文。\n\n' + text }
    ], { temp: 0.2, note: '自检复核' });
    box.innerHTML = '<div class="ok-box" style="white-space:pre-wrap">' + escHtml(r.text) + '</div>';
  } catch (e) {
    box.innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    unlock();
  }
}

/* ==================== 双引擎：要素式＋传统式（自老工具合并，3.2 版） ==================== */
let elemFormFilled = false;

const ELEM_TITLES = {
  loan: '民间借贷纠纷民事起诉状',
  divorce: '离婚纠纷民事起诉状',
  contract: '买卖合同纠纷民事起诉状',
  lease: '房屋租赁合同纠纷民事起诉状',
  property: '物业服务合同纠纷民事起诉状',
  labor: '劳动争议纠纷民事起诉状',
  traffic: '机动车交通事故责任纠纷民事起诉状',
  finance: '金融借款合同纠纷民事起诉状',
  construction: '建设工程合同纠纷民事起诉状',
  houseSale: '房屋买卖合同纠纷民事起诉状',
  admin: '行政起诉状',
  criminal: '刑事自诉状'
};

const FACT_TEMPLATES = {
  loan: [
    { key: 'relation', label: '原被告关系' },
    { key: 'loanTime', label: '借款时间地点金额' },
    { key: 'loanUse', label: '借款用途' },
    { key: 'agreement', label: '还款约定' },
    { key: 'overdue', label: '逾期情况' },
    { key: 'total', label: '标的总额' },
    { key: 'basis', label: '请求依据' }
  ],
  divorce: [
    { key: 'marriageTime', label: '结婚时间地点' },
    { key: 'childCustody', label: '子女情况' },
    { key: 'marriageStatus', label: '夫妻感情破裂原因' },
    { key: 'separation', label: '分居情况' },
    { key: 'propertySplit', label: '共同财产分割请求' },
    { key: 'debtSplit', label: '共同债务情况' },
    { key: 'support', label: '子女抚养/抚养费/探望权' },
    { key: 'damage', label: '赔偿/补偿/帮助' },
    { key: 'basis', label: '诉请依据' }
  ],
  contract: [
    { key: 'contractTime', label: '合同签订情况' },
    { key: 'subject', label: '标的物数量金额' },
    { key: 'perform', label: '履行情况' },
    { key: 'breach', label: '被告违约情况' },
    { key: 'loss', label: '损失情况' },
    { key: 'total', label: '标的总额' },
    { key: 'basis', label: '请求依据' }
  ],
  lease: [
    { key: 'contractInfo', label: '租赁合同情况' },
    { key: 'houseInfo', label: '租赁房屋情况' },
    { key: 'rentAgreement', label: '租金及押金约定' },
    { key: 'breach', label: '被告违约情况' },
    { key: 'notice', label: '催告情况' }
  ],
  property: [
    { key: 'ownerInfo', label: '业主身份及房屋情况' },
    { key: 'serviceContract', label: '物业服务合同情况' },
    { key: 'servicePerform', label: '服务履行情况' },
    { key: 'arrears', label: '欠费情况' },
    { key: 'notice', label: '催告情况' }
  ],
  labor: [
    { key: 'laborRelation', label: '劳动关系情况' },
    { key: 'contractInfo', label: '合同签订情况' },
    { key: 'wageSocial', label: '工资及社保情况' },
    { key: 'termination', label: '解除劳动关系情况' },
    { key: 'arbitration', label: '仲裁情况' },
    { key: 'injury', label: '工伤情况' },
    { key: 'basis', label: '诉请依据' }
  ],
  traffic: [
    { key: 'accidentInfo', label: '事故发生情况' },
    { key: 'responsibility', label: '事故责任认定' },
    { key: 'casualty', label: '伤亡情况' },
    { key: 'loss', label: '损失情况' },
    { key: 'insurance', label: '保险理赔情况' }
  ],
  finance: [
    { key: 'loanContract', label: '贷款合同情况' },
    { key: 'loanUse', label: '贷款用途' },
    { key: 'repayment', label: '还款约定' },
    { key: 'overdue', label: '逾期情况' },
    { key: 'overdueAmount', label: '逾期金额' },
    { key: 'basis', label: '请求依据' }
  ],
  construction: [
    { key: 'contractSign', label: '合同签订情况' },
    { key: 'projectInfo', label: '工程标的与性质' },
    { key: 'paymentDetail', label: '款项支付情况' },
    { key: 'performStatus', label: '合同履行情况' },
    { key: 'breachDetail', label: '违约情况' },
    { key: 'relationLiability', label: '多被告关系及责任承担' },
    { key: 'noticeDemand', label: '催告与协商情况' },
    { key: 'lossDetail', label: '损失情况' },
    { key: 'legalBasis', label: '法律依据分析' }
  ],
  houseSale: [
    { key: 'contractInfo', label: '合同签订情况' },
    { key: 'houseInfo', label: '房屋信息' },
    { key: 'pricePay', label: '价款与付款情况' },
    { key: 'delivery', label: '交付与过户情况' },
    { key: 'breach', label: '违约情形' },
    { key: 'loss', label: '损失情况' },
    { key: 'basis', label: '请求依据' }
  ],
  admin: [
    { key: 'applyInfo', label: '申请/争议事项' },
    { key: 'govAction', label: '行政机关行为（时间、文号、内容）' },
    { key: 'illegal', label: '违法情形' },
    { key: 'remedy', label: '复议/诉讼情况' },
    { key: 'basis', label: '法律依据' }
  ],
  criminal: [
    { key: 'judgment', label: '生效文书及执行情况' },
    { key: 'refusal', label: '拒执事实（有能力履行而拒不履行）' },
    { key: 'evidence', label: '证据清单' },
    { key: 'basis', label: '法律依据' }
  ]
};

// 要素字段同义/别名兜底表：仅在标准字段名直接匹配失败后启用。
// 匹配规则：归一化后「模型键 == 别名」或「模型键包含别名」，不反向包含，避免单字/泛词串位。
const FACT_ALIASES = {
  relation: ['原被告双方的关系', '原被告双方关系', '双方关系', '双方的关系', '当事人关系', '原被告之间的关系', '原被告间关系'],
  loanTime: ['借款时间地点及金额', '借款时间与地点金额', '借款时间地点数额', '借款时间金额', '出借时间地点金额', '借款金额时间地点'],
  loanUse: ['借款目的', '资金用途', '借款资金用途', '贷款用途'],
  agreement: ['还款约定情况', '还款约定及利息', '还款计划', '约定还款时间', '还款期限约定', '还款方式约定', '还款时间及方式'],
  overdue: ['逾期未还情况', '逾期违约情况', '欠款未还情况', '逾期及催收情况', '还款逾期情况', '逾期未还'],
  total: ['诉讼标的总额', '诉讼标的额', '标的额', '涉案金额', '欠款总额', '诉讼请求金额'],
  basis: ['法律依据', '法律根据', '请求的法律依据', '诉讼依据', '起诉依据', '依据条款'],
  marriageTime: ['结婚时间', '登记结婚时间'],
  marriageStatus: ['夫妻感情状况', '感情状况'],
  separation: ['分居事实'],
  propertySplit: ['财产分割请求', '共同财产情况'],
  debtSplit: ['共同债务'],
  support: ['抚养费情况', '抚养权归属', '抚养及探望情况'],
  contractInfo: ['合同情况', '签订合同情况', '合同主要内容', '合同约定情况'],
  contractSign: ['合同情况', '签订合同情况'],
  subject: ['标的物情况', '标的物数量及金额', '货物数量金额'],
  perform: ['合同履行情况', '履行合同情况', '履约情况'],
  breach: ['违约情况', '违约情形', '被告违约情形', '违约事实'],
  loss: ['损失金额', '损失数额', '赔偿损失情况'],
  rentAgreement: ['租金约定', '押金约定', '租金押金情况', '租金及押金'],
  houseInfo: ['房屋基本情况', '房屋坐落情况'],
  ownerInfo: ['业主情况', '房屋及业主情况'],
  serviceContract: ['物业合同情况', '物业服务合同'],
  servicePerform: ['物业服务情况'],
  arrears: ['欠费金额', '物业费欠费情况', '欠缴费用情况', '欠缴费用'],
  laborRelation: ['用工情况', '劳动关系'],
  wageSocial: ['工资及社保情况', '工资保险情况', '工资社保缴纳情况'],
  termination: ['劳动关系解除情况'],
  arbitration: ['劳动仲裁情况', '仲裁裁决情况', '仲裁结果', '劳动仲裁'],
  injury: ['工伤认定情况'],
  accidentInfo: ['交通事故发生情况', '事故经过'],
  responsibility: ['责任认定情况', '事故责任划分', '责任认定'],
  casualty: ['伤亡人数及伤情'],
  insurance: ['保险情况', '保险理赔情况', '理赔情况'],
  loanContract: ['贷款合同', '贷款合同情况'],
  repayment: ['还款约定情况', '还款计划', '还款期限及利息约定', '还款方式约定'],
  overdueAmount: ['欠款金额', '逾期本息', '逾期欠款金额'],
  projectInfo: ['工程基本情况', '工程概况'],
  paymentDetail: ['付款情况', '款项支付明细'],
  performStatus: ['履行情况', '履约情况'],
  breachDetail: ['违约情况', '违约事实', '违约具体情形'],
  relationLiability: ['各被告关系', '被告之间关系', '多被告关系'],
  noticeDemand: ['催告情况', '协商情况', '催告协商情况'],
  lossDetail: ['损失金额', '损失明细'],
  legalBasis: ['法律依据', '法律依据分析'],
  pricePay: ['价款情况', '付款情况', '房款支付情况'],
  delivery: ['交房情况', '过户情况', '交付过户情况'],
  applyInfo: ['申请事项', '争议事项'],
  govAction: ['行政行为情况', '具体行政行为'],
  illegal: ['违法事实', '违法情形'],
  remedy: ['复议情况', '诉讼情况', '复议诉讼情况'],
  judgment: ['生效文书情况', '执行依据情况'],
  refusal: ['拒不履行情况', '拒执情况', '有能力履行而拒不履行']
};

/* ============ v3.3 第六批：官方执行/国家赔偿/答辩要素表字段族 ============
   仅服务 official_templates（docType exec/compensation/answer），不改写旧 12 组 FACT_TEMPLATES。
   标签刻意避免“依据/标的总额”字样，避免被官方回填器当作法律依据/总额字段吞掉。 */
const OFFICIAL_ELEM_FIELDS = {
  exec: [
    { key: 'basisDoc', label: '生效文书（文书类型/案号/作出机关/生效日期/判项主文）' },
    { key: 'request', label: '申请执行事项（本金/利息/费用/行为，每项金额）' },
    { key: 'facts', label: '事实与理由' },
    { key: 'property', label: '被执行财产线索（含保全情况）' },
    { key: 'evidence', label: '随附材料与证据' }
  ],
  compensation: [
    { key: 'request', label: '赔偿请求（项目与金额）' },
    { key: 'facts', label: '侵权行为与损害事实' },
    { key: 'compOrg', label: '赔偿义务机关与法律适用说明' },
    { key: 'evidence', label: '证据材料' }
  ],
  answer: [
    { key: 'request', label: '答辩请求' },
    { key: 'facts', label: '对起诉状事实与理由的答辩' },
    { key: 'legal', label: '职权、事实、法律与程序合法性说明' },
    { key: 'evidence', label: '证据清单' }
  ]
};

function fieldsSource(key) {
  return (key && (FACT_TEMPLATES[key] || OFFICIAL_ELEM_FIELDS[key])) || null;
}

// 官方 exec/compensation/answer 案由 → 专属字段族键（mode 参与判定，避免“强制执行”串到行政/刑事旧族）
function elemOfficialKey(name, mode) {
  const n = String(name || '').trim();
  if (!n || typeof OFFICIAL_TEMPLATES === 'undefined' || !OFFICIAL_TEMPLATES[n]) return null;
  const m = String(mode || 'complaint');
  const dt = (typeof docTypeForMode === 'function') ? docTypeForMode(m, n) : '';
  if ((dt === 'exec' || dt === 'compensation' || dt === 'answer') && OFFICIAL_ELEM_FIELDS[dt]) return dt;
  return null;
}

const CASE_KEY_MAP = {
  '民间借贷纠纷': 'loan', '民间借贷': 'loan',
  '离婚纠纷': 'divorce', '离婚': 'divorce',
  '买卖合同纠纷': 'contract', '买卖合同': 'contract',
  '房屋租赁合同纠纷': 'lease', '房屋租赁': 'lease', '房屋租赁纠纷': 'lease',
  '物业服务合同纠纷': 'property', '物业服务': 'property', '物业': 'property',
  '劳动争议纠纷': 'labor', '劳动争议': 'labor',
  '机动车交通事故责任纠纷': 'traffic', '交通事故': 'traffic', '交通事故责任纠纷': 'traffic',
  '金融借款合同纠纷': 'finance', '金融借款': 'finance',
  '建设工程合同纠纷': 'construction', '建设工程施工合同纠纷': 'construction', '建设工程': 'construction',
  '房屋买卖合同纠纷': 'houseSale', '房屋买卖': 'houseSale',
  '政府信息公开': 'admin', '行政复议': 'admin', '行政许可': 'admin', '行政处罚': 'admin',
  '行政强制执行': 'admin', '行政协议': 'admin', '不履行法定职责': 'admin',
  '工伤保险资格或者待遇认定': 'admin', '国有土地上房屋征收决定': 'admin', '行政征收': 'admin'
};

function elemLabelSpec() {
  const parts = [];
  for (const k in FACT_TEMPLATES) {
    parts.push(k + '：' + FACT_TEMPLATES[k].map(f => f.label).join('、'));
  }
  return parts.join('；');
}
function elemLabelsFor(key) {
  const t = fieldsSource(key);
  return t ? t.map(f => f.label) : [];
}

function elemKeyOf(name) {
  const n = String(name || '').trim();
  const mode = (typeof currentDraft !== 'undefined' && currentDraft) ? currentDraft.mode : 'complaint';
  const ok = elemOfficialKey(n, mode);
  if (ok) return ok;
  if (CASE_KEY_MAP[n]) return CASE_KEY_MAP[n];
  for (const k in CASE_KEY_MAP) {
    if (n.includes(k) || k.includes(n)) return CASE_KEY_MAP[k];
  }
  if (n.includes('刑事')) return 'criminal';
  return null;
}

function elemTitleOf(key, caseType) {
  if (key === 'exec') return '强制执行申请书';
  if (key === 'compensation') return '国家赔偿申请书';
  if (key === 'answer') return '答辩状';
  if (key === 'admin') return '行政起诉状';
  if (key === 'criminal') return '刑事自诉状';
  return ELEM_TITLES[key] || (caseType || '民事') + '起诉状';
}

function genderBox(g) {
  return (g === '男' ? '☑' : '☐') + '男  ' + (g === '女' ? '☑' : '☐') + '女';
}

function stripMarkdown(s) {
  return String(s == null ? '' : s)
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/^#{1,6}\s*/gm, '')
    .replace(/`/g, '')
    .trim();
}

function checkMaterialCompleteness(raw) {
  const issues = [];
  const t = String(raw || '');
  if (t.length < 20) issues.push('素材内容过短，请提供更完整的案件描述');
  const hasPlaintiff = /原告|上诉人|申请人|答辩人/.test(t);
  const hasDefendant = /被告|被上诉人|被申请人/.test(t);
  if (!hasPlaintiff && !hasDefendant) issues.push('未检测到明确的当事人信息（原告/被告）');
  if (!/纠纷|争议|违约|欠款|借款|离婚|赔偿/.test(t)) issues.push('未检测到明确的纠纷内容');
  return issues;
}

function buildElemTextLines(d) {
  const lines = [];
  function add(s) { lines.push(s); }
  function blank() { lines.push(''); }

  add(d.title || '民事起诉状');
  if (d.title && d.title.includes('纠纷')) {
    const caseLabel = d.title.replace('民事起诉状', '').replace(/（|）/g, '');
    if (caseLabel) add('（' + caseLabel + ' · 要素式）');
  }
  blank();
  add('说明：');
  add('为了方便您更好地参加诉讼，保护您的合法权利，请填写本表。');
  add('1. 起诉时需向人民法院提交证明您身份的材料，如身份证复印件、营业执照复印件等。');
  add('2. 本表所列内容是您提起诉讼以及人民法院查明案件事实所需，请务必如实填写。');
  add('3. 本表有些内容可能与您的案件无关，您认为与案件无关的项目可以填“无”或不填；对于本表中勾选项可以在对应项打“√”。');
  add('4. 本表 word 电子版填写时，相关栏目可复制粘贴或扩容，但不得改变要素内容、格式设置。');
  blank();
  add('★特别提示★');
  add('诉讼参加人应遵守诚信原则如实认真填写表格。如果诉讼参加人违反有关规定，虚假诉讼、恶意诉讼、滥用诉权，人民法院将视违法情形依法追究责任。');
  blank();

  add('【当事人信息】');
  blank();
  add('原告：');
  add('  姓名：' + (d.pName || '') + '　　性别：' + genderBox(d.pGender) + '　　出生日期：' + (d.pBirth || '　　年　　月　　日') + '　　民族：' + (d.pNation || ''));
  add('  工作单位：' + (d.pWork || '') + '　　职务：' + (d.pDuty || '') + '　　联系电话：' + (d.pPhone || ''));
  add('  住所地（户籍所在地）：' + (d.pAddr || ''));
  add('  经常居住地：' + (d.pLive || ''));
  add('  证件类型：' + (d.pIdType || '身份证') + '　　证件号码：' + (d.pIdNo || ''));
  add('  委托诉讼代理人：' + (d.hasAgent ? '☑有  ☐无' : '☐有  ☑无'));
  if (d.hasAgent) {
    add('  代理人姓名：' + (d.agentName || '') + '　　单位：' + (d.agentOrg || '') + '　　电话：' + (d.agentPhone || '') + '　　代理权限：' + (d.agentAuth || ''));
  }
  blank();
  add('被告：');
  add('  姓名：' + (d.dName || '') + '　　性别：' + genderBox(d.dGender) + '　　出生日期：' + (d.dBirth || '　　年　　月　　日') + '　　民族：' + (d.dNation || ''));
  add('  工作单位：' + (d.dWork || '') + '　　职务：' + (d.dDuty || '') + '　　联系电话：' + (d.dPhone || ''));
  add('  住所地（户籍所在地）：' + (d.dAddr || ''));
  add('  经常居住地：' + (d.dLive || ''));
  add('  证件类型：' + (d.dIdType || '身份证') + '　　证件号码：' + (d.dIdNo || ''));
  blank();

  add('【诉讼请求和依据】');
  blank();
  if (d.claims && d.claims.length > 0) {
    d.claims.forEach((c, i) => { add((i + 1) + '. ' + c); });
  } else {
    add('1. '); add('2. '); add('3. ');
  }
  if (d.basis) { blank(); add('依据：' + d.basis); }
  blank();

  add('【事实与理由】');
  blank();
  if (d.facts && d.facts.length > 0) {
    d.facts.forEach((f, i) => {
      if (f.label) {
        add((i + 1) + '. 【' + f.label + '】');
        String(f.content).split('\n').forEach(line => { add('  ' + line); });
      } else {
        add((i + 1) + '. ' + f.content);
      }
      blank();
    });
  } else {
    add('1. '); blank(); add('2. '); blank(); add('3. '); blank();
  }

  add('【证据和证据来源，证人姓名和住所】');
  blank();
  if (d.evidences && d.evidences.length > 0) {
    d.evidences.forEach((e, i) => { add((i + 1) + '. ' + e); });
  } else {
    add('1. '); add('2. '); add('3. ');
  }
  blank();

  add('【送达地址确认】');
  blank();
  add('地址：' + (d.serviceAddr || '') + '　　联系电话：' + (d.servicePhone || ''));
  blank();

  add('此致');
  add(d.court || '人民法院');
  blank();
  add('具状人（签字、盖章）：' + (d.signerName || ''));
  blank();
  add(d.signDate || '　　年　　月　　日');
  return lines;
}

function parseJsonStrict(text) {
  let t = String(text || '').trim();
  t = t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  const s = t.indexOf('{');
  const e = t.lastIndexOf('}');
  if (s < 0 || e < 0 || e <= s) throw new Error('AI 返回格式异常，请重新提取');
  return JSON.parse(t.slice(s, e + 1));
}

function splitAnalysisJson(text) {
  const t = String(text || '');
  const k = t.indexOf('"caseType"');
  if (k < 0) return { text: t, obj: null };
  const s = t.lastIndexOf('{', k);
  if (s < 0) return { text: t, obj: null };
  const e = t.lastIndexOf('}');
  if (e <= s) return { text: t, obj: null };
  try {
    const obj = JSON.parse(t.slice(s, e + 1));
    return { text: t.slice(0, s).replace(/\n+$/, '').trim(), obj: obj };
  } catch (err) {
    return { text: t, obj: null };
  }
}

function renderElemFactFields(key) {
  const box = $('elemFactFields');
  const tpl = fieldsSource(key);
  if (!tpl) {
    box.innerHTML = '<label class="fld">事实与理由（要素，逐条填写）</label>' +
      '<textarea id="eff_facts" placeholder="如：1. 借款时间地点金额…；2. 还款约定…；3. 逾期情况…"></textarea>';
    return;
  }
  box.innerHTML = '<div class="sub" style="margin:12px 0 4px">事实要素（按案由模板）</div>' +
    tpl.map(f => '<label class="fld">' + escHtml(f.label) + '</label>' +
      '<input type="text" id="eff_' + f.key + '" placeholder="' + escHtml(f.label) + '">').join('');
}

function onDraftCaseTypeChange() {
  const v = $('caseTypeSel').value;
  renderElemFactFields(elemKeyOf(v));
  if (typeof applyDraftModeLabels === 'function') applyDraftModeLabels(currentDraft.mode);
}

function readElemForm() {
  const val = id => { const el = $(id); return el ? el.value.trim() : ''; };
  const claims = val('elemClaims').split('\n').map(s => s.replace(/^\d+[.、）)]\s*/, '').trim()).filter(s => s);
  const evidence = val('elemEvidence').split('\n').map(s => s.replace(/^\d+[.、）)]\s*/, '').trim()).filter(s => s);
  const key = elemKeyOf(val('caseTypeSel'));
  const facts = [];
  if (key && fieldsSource(key)) {
    fieldsSource(key).forEach(f => {
      const v = val('eff_' + f.key);
      if (v) facts.push({ label: f.label, content: v });
    });
  }
  const genericFacts = val('eff_facts');
  if (genericFacts) facts.push({ label: '', content: genericFacts });
  const caseType = val('caseTypeSel') || '民事纠纷';
  const plName = val('elemPlName');
  return {
    caseType: caseType,
    key: key,
    plaintiff: {
      name: plName, type: val('elemPlType'), gender: val('elemPlGender'), birth: val('elemPlBirth'),
      nation: val('elemPlEthnic'), idNo: val('elemPlId'), addr: val('elemPlAddr'), liveAddr: val('elemPlLive'),
      phone: val('elemPlPhone'), workUnit: val('elemPlWork'), position: val('elemPlPosition'),
      legalRep: val('elemPlLegalRep'), creditCode: val('elemPlCredit'), regAddr: val('elemPlReg'),
      orgType: val('elemPlOrgType'), ownership: val('elemPlOwnership')
    },
    defendant: {
      name: val('elemDfName'), type: val('elemDfType'), gender: val('elemDfGender'), birth: val('elemDfBirth'),
      nation: val('elemDfEthnic'), idNo: val('elemDfId'), addr: val('elemDfAddr'), liveAddr: val('elemDfLive'),
      phone: val('elemDfPhone'), workUnit: val('elemDfWork'), position: val('elemDfPosition'),
      legalRep: val('elemDfLegalRep'), creditCode: val('elemDfCredit'), regAddr: val('elemDfReg'),
      orgType: val('elemDfOrgType'), ownership: val('elemDfOwnership')
    },
    claims: claims,
    evidence: evidence,
    facts: facts,
    elements: (typeof parseOfficialRowsText === 'function') ? parseOfficialRowsText(val('elemOfficialRows')) : null,
    court: val('elemCourt'),
    signerName: plName,
    signDate: today()
  };
}

function fillElemForm(obj) {
  const set = (id, v) => { const el = $(id); if (el) el.value = v || ''; };
  const p = obj.plaintiff || {};
  const d = obj.defendant || {};
  const setParty = (prefix, party) => {
    const org = (typeof elemIsCompany === 'function') ? elemIsCompany(party.name, party) : false;
    set(prefix + 'Name', party.name);
    set(prefix + 'Type', org ? '法人或其他组织' : (party.name ? '自然人' : ''));
    set(prefix + 'Gender', party.gender); set(prefix + 'Birth', party.birth);
    set(prefix + 'Ethnic', party.nation); set(prefix + 'Id', party.idNo);
    set(prefix + 'Addr', party.addr || party.liveAddr); set(prefix + 'Live', party.liveAddr);
    set(prefix + 'Phone', party.phone);
    set(prefix + 'Work', party.workUnit); set(prefix + 'Position', party.position);
    set(prefix + 'LegalRep', party.legalRep || party.legalPerson); set(prefix + 'Credit', party.creditCode);
    set(prefix + 'Reg', party.regAddr); set(prefix + 'OrgType', party.orgType || party.unitType);
    set(prefix + 'Ownership', party.ownership);
  };
  setParty('elemPl', p);
  setParty('elemDf', d);
  const claims = (obj.claims || []).map((c, i) => (i + 1) + '. ' + c).join('\n');
  const evs = (obj.evidence || []).map((e, i) => (i + 1) + '. ' + (typeof e === 'string' ? e : (e.name || JSON.stringify(e)))).join('\n');
  set('elemClaims', claims);
  set('elemEvidence', evs);
  set('elemCourt', obj.court || '');
  const caseType = obj.caseType || '';
  if (caseType) {
    currentDraft.caseType = caseType;
    const sel = $('caseTypeSel');
    const opts = Array.prototype.slice.call(sel.options);
    const hit = opts.find(o => o.value === caseType) || opts.find(o => caseType.includes(o.value) || o.value.includes(caseType));
    if (hit) sel.value = hit.value;
    else {
      const opt = document.createElement('option');
      opt.value = caseType; opt.textContent = caseType;
      sel.appendChild(opt); sel.value = caseType;
    }
  }
  const key = elemKeyOf(caseType);
  renderElemFactFields(key);
  if (typeof applyDraftModeLabels === 'function') applyDraftModeLabels(currentDraft.mode);
  const ff = obj.factFields || {};
  const normLabel = s => String(s || '').replace(/[\s，。、；：:（）()【】\[\]\/\\·\-—]/g, '').toLowerCase();
  if (key && fieldsSource(key)) {
    fieldsSource(key).forEach(f => {
      let v = ff[f.key] || '';
      if (!v) {
        const nl = normLabel(f.label);
        for (const k in ff) {
          const val = String(ff[k] || '').trim();
          if (!val) continue;
          const nk = normLabel(k);
          if (nk === nl || nk.includes(nl)) { v = val; break; }
        }
      }
      if (!v) {
        const nAliases = (FACT_ALIASES[f.key] || []).map(normLabel);
        if (nAliases.length) {
          for (const k in ff) {
            const val = String(ff[k] || '').trim();
            if (!val) continue;
            const nk = normLabel(k);
            if (nAliases.some(na => nk === na || nk.includes(na))) { v = val; break; }
          }
        }
      }
      set('eff_' + f.key, v);
    });
  } else {
    const lines = [];
    for (const k in ff) { if (String(ff[k]).trim()) lines.push(k + '：' + String(ff[k]).trim()); }
    if (obj.factReason) lines.push('事实与理由：' + obj.factReason);
    set('eff_facts', lines.join('\n'));
  }
  const missing = [];
  const rw = elemRoleWords(currentDraft.mode, caseType);
  if (!p.name) missing.push(rw.p + '姓名/名称');
  if (!d.name) missing.push(rw.d + '姓名/名称');
  if (!(obj.claims || []).length) missing.push(rw.claims);
  if (!(obj.evidence || []).length) missing.push(rw.ev);
  if (key && fieldsSource(key)) {
    const emptyFacts = fieldsSource(key).filter(f => { const el = $('eff_' + f.key); return !el || !el.value.trim(); }).length;
    if (emptyFacts > 0) missing.push('案件要素（' + emptyFacts + ' 项待补充）');
  }
  const mbox = $('elemMissing');
  // 官方要素表逐行内容：AI 提取 + 案由要素映射，落到可编辑文本框，生成时按行覆盖模板
  if (typeof officialRowsTextFromDoc === 'function' && $('elemOfficialRows')) {
    try {
      set('elemOfficialRows', '');
      const dataNow = readElemForm();
      // AI 直接给出的官方要素行内容优先，其次用案由要素映射兜底
      if (obj.elements && Object.keys(obj.elements).length) dataNow.elements = obj.elements;
      const audit = officialRowAudit(dataNow.caseType, null, dataNow);
      if (audit && audit.missing && audit.missing.length) {
        missing.push('官方要素表未填 ' + audit.missing.length + ' 行');
      }
      set('elemOfficialRows', officialRowsTextFromDoc(dataNow));
    } catch (err) { /* 保持表单可用即可 */ }
  }
  if (missing.length) {
    mbox.style.display = '';
    mbox.innerHTML = '⚠️ 以下要素 AI 未能识别，请在表单中补充：<b>' + missing.join('、') + '</b>';
  } else {
    mbox.style.display = 'none';
  }
  elemFormFilled = true;
  $('draftElemForm').style.display = '';
  $('draftElemForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function runExtractFill() {
  const material = currentDraft.material || $('draftMaterial').value.trim();
  if (!material) { toast('请先粘贴素材'); return; }
  currentDraft.material = material;
  const prevHtml = $('draftPrepText').innerHTML;
  $('draftPrep').style.display = '';
  $('draftPrepText').innerHTML = '<span class="loading"><span class="spin"></span>AI 正在提取要素并回填表单…<button class="cancel-btn" onclick="cancelCurrentRequest()">取消</button></span>';
  const mode = (currentDraft && currentDraft.mode) || 'complaint';
  const sel = $('caseTypeSel').value || currentDraft.caseType || '';
  const fam = elemOfficialKey(sel, mode);
  const docName = fam === 'exec' ? '强制执行申请书（要素式）'
    : fam === 'compensation' ? '国家赔偿申请书'
      : fam === 'answer' ? '行政答辩状（通用）'
        : (mode === 'answer' ? '答辩状' : '民事起诉状');
  const caseHint = fam === 'exec'
    ? '案由请从这些中选择：强制执行、参与分配、执行担保、确认优先购买权、暂时解除乘坐飞机、高铁限制措施、执行异议、执行复议、执行监督、不予执行仲裁裁决、调解书或公证债权文书；其他情况按素材判断最接近的类型。\n'
    : fam === 'compensation'
      ? '案由请从这些中选择：违法刑事拘留赔偿、刑事改判无罪赔偿、怠于履行监管职责致伤致死赔偿、错误执行赔偿。\n'
      : fam === 'answer'
        ? '案由请输出：行政答辩状（通用）。\n'
        : '案由请优先从这些中选择：民间借贷纠纷、离婚纠纷、买卖合同纠纷、机动车交通事故责任纠纷、金融借款合同纠纷、劳动争议纠纷、物业服务合同纠纷、房屋租赁合同纠纷、建设工程合同纠纷、房屋买卖合同纠纷、信用卡纠纷、政府信息公开、行政复议、行政许可、行政处罚、刑事自诉；其他情况按素材判断最接近的案由。\n';
  const claimsNote = fam === 'exec' ? '申请执行事项（写明本金/利息/费用/行为）'
    : fam === 'compensation' ? '赔偿请求（项目与金额）'
      : fam === 'answer' ? '答辩请求'
        : '诉讼请求';
  const prompt = '你是法律文书要素提取专家。请从下面的案件素材中提取撰写' + docName + '所需的全部要素，只输出一个 JSON 对象（不要 Markdown 代码块，不要解释）。\n' +
    caseHint +
    'JSON 结构：\n' +
    '{\n' +
    '  "caseType": "案由名称",\n' +
    '  "plaintiff": { "name":"", "gender":"男/女", "birth":"", "nation":"", "idNo":"", "addr":"", "liveAddr":"", "phone":"" },\n' +
    '  "defendant": { "name":"", "gender":"", "birth":"", "nation":"", "idNo":"", "addr":"", "liveAddr":"", "phone":"" },\n' +
    '  "claims": ["' + claimsNote + '1","' + claimsNote + '2"],\n' +
    '  "evidence": ["证据1（名称｜来源/形式｜证明目的）","证据2"],\n' +
    '  "factFields": { "与案由相关的要素标签":"内容", "要素2":"内容" },\n' +
    '  "factReason": "完整事实与理由段落（如 factFields 已充分可留空）",\n' +
    '  "court": "受理法院，未知则空"\n' +
    '}\n' +
    '要求：未提及的字段一律为空字符串或空数组，绝不编造。\n';
  let key = elemKeyOf(sel);
  let labels = elemLabelsFor(key);
  if (!labels.length && fam) labels = (OFFICIAL_ELEM_FIELDS[fam] || []).map(f => f.label);
  if (labels.length) {
    prompt += 'factFields 的键必须严格使用以下名称（原样，不加标点）：' + labels.join('、') + '\n';
  }
  prompt += '素材：\n' + material;
  const r = await callLLM([
    { role: 'system', content: SYS },
    { role: 'user', content: prompt }
  ], { temp: 0.1, maxTokens: 4000, note: '要素提取' });
  const obj = parseJsonStrict(r.text);
  fillElemForm(obj);
  $('draftPrepText').innerHTML = (prevHtml && prevHtml.indexOf('loading') < 0)
    ? prevHtml
    : '<div class="ok-box">要素提取完成，请在下方表单核对、修改，再点「' + (mode === 'complaint' ? '生成双版文书' : '生成文书') + '」。</div>';
  const issues = checkMaterialCompleteness(material);
  if (issues.length) {
    const mbox = $('elemMissing');
    mbox.style.display = '';
    mbox.innerHTML = '⚠️ ' + issues.map(escHtml).join('<br>');
  }
}

async function extractAndFill() {
  if (!tryLock()) return;
  try {
    await runExtractFill();
  } catch (e) {
    if (e.needSetup) goTab('settings');
    $('draftPrepText').innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    unlock();
  }
}

function buildTradPrompt(data) {
  const p = data.plaintiff || {};
  const d = data.defendant || {};
  const claims = (data.claims || []).map((c, i) => (i + 1) + '. ' + c).join('\n') || '（待补充）';
  const facts = (data.facts || []).map(f => (f.label ? '【' + f.label + '】' : '') + (f.content || '')).join('\n');
  const evidence = (data.evidence || []).map((e, i) => (i + 1) + '. ' + e).join('\n') || '（待补充）';
  const title = elemTitleOf(data.key, data.caseType);
  return '请根据以下案件信息，生成一份完整的《' + title + '》（传统叙述式），可直接打印提交。\n' +
    '【原告】姓名：' + (p.name || '（待补充）') + '，性别：' + (p.gender || '（待补充）') + '，出生日期：' + (p.birth || '（待补充）') + '，民族：' + (p.nation || '（待补充）') + '，住：' + (p.addr || '（待补充）') + '，联系电话：' + (p.phone || '（待补充）') + '，身份证号：' + (p.idNo || '（待补充）') + '\n' +
    '【被告】姓名：' + (d.name || '（待补充）') + '，性别：' + (d.gender || '（待补充）') + '，出生日期：' + (d.birth || '（待补充）') + '，民族：' + (d.nation || '（待补充）') + '，住：' + (d.addr || '（待补充）') + '，联系电话：' + (d.phone || '（待补充）') + '，身份证号：' + (d.idNo || '（待补充）') + '\n' +
    '【案由】' + (data.caseType || '由你判断') + '\n' +
    '【诉讼请求】\n' + claims + '\n' +
    '【事实与理由要素】\n' + (facts || '（待补充）') + '\n' +
    '【证据】\n' + evidence + '\n' +
    '【受理法院】' + (data.court || '（待补充）') + '\n\n' +
    '输出要求：1）标题居中；2）完整包含：标题、原告/被告信息、诉讼请求、事实与理由（不少于300字，结合要素展开并引用真实法律依据，不确定写“依据相关规定”）、证据清单、此致XX人民法院、具状人（签字）与日期留空；3）缺失信息写“（待补充）”，绝不编造事实、金额、日期、案号、人名；4）不用 Markdown，不用代码块，不要解释。';
}

async function genDualComplaint() {
  if (!tryLock()) return;
  const btn = $('btnDraftGenerate');
  try {
    if (!currentDraft.material) { toast('请先粘贴素材'); return; }
    if (!elemFormFilled) {
      await runExtractFill();
    }
    const data = readElemForm();
    const key = data.key;
    const title = elemTitleOf(key, data.caseType);
    $('draftPrep').style.display = '';
    $('draftPrepText').innerHTML = '<span class="loading"><span class="spin"></span>正在生成要素式（本地模板）＋传统式（AI）双版文书…<button class="cancel-btn" onclick="cancelCurrentRequest()">取消</button></span>';
    const elemText = buildElemTextLines({
      title: title,
      pName: data.plaintiff.name, pGender: data.plaintiff.gender, pBirth: data.plaintiff.birth,
      pNation: data.plaintiff.nation, pPhone: data.plaintiff.phone, pAddr: data.plaintiff.addr,
      pIdNo: data.plaintiff.idNo, pLive: '',
      dName: data.defendant.name, dGender: data.defendant.gender, dBirth: data.defendant.birth,
      dNation: data.defendant.nation, dPhone: data.defendant.phone, dAddr: data.defendant.addr,
      dIdNo: data.defendant.idNo, dLive: '',
      claims: data.claims, evidences: data.evidence, facts: data.facts,
      court: data.court || '（待补充）', signerName: data.signerName, signDate: data.signDate,
      serviceAddr: data.plaintiff.addr, servicePhone: data.plaintiff.phone
    }).join('\n');
    const official = buildOfficialElemDoc(data);
    const r = await callLLM([
      { role: 'system', content: SYS },
      { role: 'user', content: buildTradPrompt(data) }
    ], { temp: 0.3, maxTokens: 6000, note: '生成·传统式起诉状' });
    const tradText = stripMarkdown(r.text);
    const docs = [
      official
        ? { name: '要素式起诉状（官方模板）', html: official.html, text: official.text }
        : { name: '要素式起诉状', text: elemText },
      { name: '传统式起诉状', text: tradText, html: tradTextToHtml(tradText) }
    ];
    currentDraft.docs = docs;
    // v3.3：记录生成快照与 AI 元数据，供存入 Document 时使用
    const basisFact = (data.facts || []).find(f => elemNormKey(f.label).indexOf('依据') >= 0);
    const totalFact = (data.facts || []).find(f => elemNormKey(f.label).indexOf('标的总额') >= 0);
    currentDraft.lastData = {
      caseType: data.caseType, key: key,
      plaintiff: data.plaintiff, defendant: data.defendant,
      claims: data.claims, evidence: data.evidence, facts: data.facts,
      basis: basisFact ? basisFact.content : '', total: totalFact ? totalFact.content : '',
      court: data.court, signerName: data.signerName, signDate: data.signDate
    };
    currentDraft.lastAiMeta = {
      provider: state.provider,
      model: (state.models && state.models[state.provider]) || '',
      generatedAt: Date.now(),
      tokens: { in: r.inT || 0, out: r.outT || 0 },
      cost: r.cost || 0
    };
    renderDraftDocs(docs);
    $('draftPrep').style.display = 'none';
    $('draftResult').style.display = '';
    $('selfCheckArea').innerHTML = '';
    window.scrollTo({ top: $('draftResult').offsetTop - 90, behavior: 'smooth' });
  } catch (e) {
    if (e.needSetup) goTab('settings');
    $('draftPrepText').innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    if (btn) btn.disabled = false;
    unlock();
  }
}

// v3.3 第六批：exec/answer/compensation 官方要素表单文书生成（本地模板渲染，不覆盖 Case.material）
async function genOfficialElemDoc() {
  if (!tryLock()) return;
  const btn = $('btnDraftGenerate');
  try {
    if (!currentDraft.material) { toast('请先粘贴素材'); return; }
    if (!elemFormFilled) await runExtractFill();
    const data = readElemForm();
    const official = buildOfficialElemDoc(data);
    if (!official) { toast('该案由暂无官方要素表模板，请核对案由后重试'); return; }
    $('draftPrep').style.display = '';
    $('draftPrepText').innerHTML = '<span class="loading"><span class="spin"></span>正在按官方示范文本生成要素表…</span>';
    const docs = [{ name: official.title || data.caseType || '官方要素表文书', html: official.html, text: official.text }];
    currentDraft.docs = docs;
    const basisFact = (data.facts || []).find(f => elemNormKey(f.label).indexOf('依据') >= 0);
    const totalFact = (data.facts || []).find(f => elemNormKey(f.label).indexOf('标的总额') >= 0);
    currentDraft.lastData = {
      caseType: data.caseType, key: data.key || official.key || null,
      plaintiff: data.plaintiff, defendant: data.defendant,
      claims: data.claims, evidence: data.evidence, facts: data.facts,
      basis: basisFact ? basisFact.content : '', total: totalFact ? totalFact.content : '',
      court: data.court, signerName: data.signerName, signDate: data.signDate
    };
    currentDraft.lastAiMeta = currentDraft.lastAiMeta || {
      provider: state.provider,
      model: (state.models && state.models[state.provider]) || '',
      generatedAt: Date.now(),
      tokens: { in: 0, out: 0 },
      cost: 0
    };
    renderDraftDocs(docs);
    $('draftPrep').style.display = 'none';
    $('draftResult').style.display = '';
    $('selfCheckArea').innerHTML = '';
    window.scrollTo({ top: $('draftResult').offsetTop - 90, behavior: 'smooth' });
    toast('已按官方示范文本生成：' + (official.title || ''));
  } catch (e) {
    if (e.needSetup) goTab('settings');
    $('draftPrepText').innerHTML = '<div class="err-box">' + escHtml(e.message) + '</div>';
  } finally {
    if (btn) btn.disabled = false;
    unlock();
  }
}

function exportTextDoc(fileName, text, title) {
  const html = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>" + escHtml(title || fileName || '法律文书') + "</title></head><body style='font-family:仿宋,SimSun;font-size:16px;line-height:2;'><pre style='white-space:pre-wrap;font-family:仿宋,SimSun;font-size:16px;line-height:2;'>" + escHtml(text) + "</pre></body></html>";
  const blob = new Blob(['\ufeff' + html], { type: 'application/msword' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

function wordHtmlShell(inner, title) {
  const css = "@page{size:A4;margin:1.5cm 2.5cm 1.8cm 2cm;}"
    + "body{font-family:仿宋,FangSong,SimSun,serif;font-size:10.5pt;line-height:1.5;}"
    + "table.elem-official{width:100%;border-collapse:collapse;font-family:仿宋,FangSong,SimSun,serif;font-size:10.5pt;table-layout:fixed;}"
    + "table.elem-official col.col-lab{width:24.3%;}table.elem-official col.col-val{width:75.7%;}"
    + "table.elem-official th,table.elem-official td{border:0.5pt solid #000;padding:2px 4px;vertical-align:top;text-align:left;word-wrap:break-word;}"
    + "table.elem-official tr.sec th{background:#fff;text-align:center;font-size:15pt;font-weight:400;font-family:'方正小标宋_GBK',宋体,SimSun,serif;}"
    + "table.elem-official tr.sec2 th{text-align:left;font-weight:400;font-size:10.5pt;}"
    + "table.elem-official td.lab{text-align:center;vertical-align:middle;}"
    + "table.elem-official td.val{vertical-align:top;line-height:1.6;}"
    + "table.elem-official tr.note td{font-size:10.5pt;line-height:1.45;font-family:'方正黑体_GBK',仿宋,FangSong,SimSun,serif;}"
    + "table.elem-official tr.note2 td{font-size:10.5pt;}"
    + "table.elem-official .note-p{text-align:justify;margin:0 0 3px;text-indent:2em;}"
    + "table.elem-official .note-p:first-child{text-indent:0;}"
    + "table.elem-official .note-star{text-align:center;font-weight:700;}"
    + "table.elem-official tr.sec-ct td{text-align:center;font-weight:400;font-size:15pt;font-family:'方正小标宋_GBK',宋体,SimSun,serif;}"
    + ".elem-official-title{text-align:center;font-size:22pt;font-weight:700;font-family:'方正大标宋_GBK',宋体,SimSun,serif;margin:6px 0 4px;line-height:1.25;}"
    + ".elem-official-sub{display:inline-block;font-size:16pt;font-weight:400;font-family:'方正小标宋_GBK',宋体,SimSun,serif;letter-spacing:1px;}"
    + ".elem-sign{display:block;padding:12px 4px 4px;line-height:1.8;text-align:left;font-size:15pt;font-family:'方正小标宋_GBK',仿宋,FangSong,SimSun,serif;}"
    + ".elem-sign-item{white-space:nowrap;}"
    + ".trad-title{text-align:center;font-weight:700;font-size:22pt;font-family:'方正大标宋_GBK',黑体,SimHei,SimSun,serif;margin:8px 0 14px;}"
    + ".trad-p{text-indent:2em;line-height:1.8;margin:0 0 4px;font-family:仿宋,FangSong,SimSun,serif;font-size:10.5pt;}"
    + ".trad-sec{font-weight:700;}"
    + ".trad-right{text-align:right;line-height:1.8;margin:0;padding-right:2em;font-family:仿宋,FangSong,SimSun,serif;font-size:10.5pt;}";
  return "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>" + escHtml(title || '法律文书') + "</title><style>" + css + "</style></head><body>" + inner + "</body></html>";
}

function exportHtmlDoc(fileName, inner, title) {
  const blob = new Blob(['\ufeff' + wordHtmlShell(inner, title || fileName)], { type: 'application/msword' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

function exportBothDocs() {
  const stamp = today().replace(/[年月日]/g, '');
  if (!currentDraft.docs || !currentDraft.docs.length) { toast('请先生成文书'); return; }
  if (currentDraft.docs.length < 2) {
    const d = currentDraft.docs[0];
    const fname = docFileName(d, stamp);
    const t0 = docFileName(d, '').replace(/_/g, '·');
    if (d.html) exportHtmlDoc(fname + '.doc', d.html, t0);
    else exportTextDoc(fname + '.doc', d.text, t0);
    toast('已导出 Word');
    return;
  }
  const [elem, trad] = currentDraft.docs;
  const titleOf = d => docFileName(d, '').replace(/_/g, '·');
  if (elem.html) exportHtmlDoc(docFileName(elem, stamp) + '.doc', elem.html, titleOf(elem));
  else exportTextDoc(docFileName(elem, stamp) + '.doc', elem.text, titleOf(elem));
  setTimeout(() => {
    if (trad && trad.html) exportHtmlDoc(docFileName(trad, stamp) + '.doc', trad.html, titleOf(trad));
    else exportTextDoc(docFileName(trad, stamp) + '.doc', trad ? trad.text : '', titleOf(trad));
  }, 400);
  toast('已导出两份 Word');
}
