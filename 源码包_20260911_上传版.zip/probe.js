/* 端到端探针：材料 → AI 分析回填 → 生成要素式官方模板文书 → 导出诊断
 * 用法: node probe.js [案由] [plaintiffName] [defendantName]
 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PAGE = process.env.PROBE_PAGE
  ? 'file:///' + process.env.PROBE_PAGE.replace(/\\/g, '/')
  : 'file:///' + path.join(__dirname, 'out', 'index.html').replace(/\\/g, '/');
const PORT = 9411;
const OUTDIR = path.join(__dirname, 'out');
const PROFILE = fs.mkdtempSync(path.join(os.tmpdir(), 'probe-'));

const CASE_TYPE = process.argv[2] || '民间借贷纠纷';
const PL_NAME = process.argv[3] || '张三';
const DF_NAME = process.argv[4] || '李四';

const chrome = spawn(CHROME, [
  '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage',
  '--disable-extensions', '--disable-background-networking', '--disable-component-update',
  '--disable-default-apps', '--disable-sync', '--metrics-recording-only', '--no-first-run',
  '--no-default-browser-check', '--password-store=basic',
  `--remote-debugging-port=${PORT}`, `--user-data-dir=${PROFILE}`, 'about:blank'
], { stdio: 'ignore' });

const sleep = ms => new Promise(r => setTimeout(r, ms));

const isOrg = n => /(公司|厂|店|合作社|银行|中心|事务所|学校|医院|局|委员会|协会|商行|经营部|服务部|超市|酒店)$/.test(String(n || ''));
const personParty = (n, id, addr, phone) => ({
  name: n, type: '自然人', gender: '男', birth: '1980年1月1日', nation: '汉族',
  idNo: id, addr: addr, liveAddr: '', phone: phone, workUnit: '', position: ''
});
const orgParty = (n, credit, addr, legalRep) => ({
  name: n, type: '法人或其他组织', gender: '', birth: '', nation: '',
  idNo: credit, creditCode: credit, addr: addr, liveAddr: '', phone: '0558-0000000',
  legalRep: legalRep, legalRepPosition: '经理', regAddr: addr, orgType: '有限责任公司', ownership: '民营'
});

const analysis = {
  caseType: CASE_TYPE,
  plaintiff: isOrg(PL_NAME)
    ? orgParty(PL_NAME, '91341621MA2XXXXXXX', '安徽省涡阳县工业园区XX路8号', '王五')
    : personParty(PL_NAME, '342124198001011234', '安徽省涡阳县义门镇XX村', '13800000000'),
  defendant: isOrg(DF_NAME)
    ? orgParty(DF_NAME, '91341621MA3YYYYYYY', '安徽省涡阳县陈大镇YY村', '赵六')
    : personParty(DF_NAME, '342124197902021234', '安徽省涡阳县陈大镇YY村', '13900000000'),
  claims: [
    '判令被告偿还借款本金50000元',
    '判令被告支付利息（以50000元为基数，自2024年6月1日起按年利率13.8%计至实际清偿之日止）',
    '本案诉讼费用由被告承担'
  ],
  evidence: ['借条（原件）｜证明借贷关系成立', '银行转账记录｜证明50000元已实际交付', '微信催收记录｜证明原告主张过权利'],
  factFields: {
    '原被告关系': '朋友关系',
    '借款时间地点金额': '2023年6月10日，安徽省涡阳县，借款50000元',
    '借款用途': '经营周转',
    '还款约定': '约定月息1分（年利率13.8%），2024年6月1日到期一次性还本付息',
    '逾期情况': '到期后未偿还，多次催收无果',
    '标的总额': '本金50000元及利息',
    '请求依据': '依据《中华人民共和国民法典》第六百六十七条、第六百七十四条、第六百七十五条、第六百七十六条'
  },
  factReason: '',
  court: '涡阳县人民法院',
  elements: {
    '1.本金': '截至2024年6月1日止，尚欠本金50000元（人民币，下同）',
    '2.利息': '截至2024年6月1日止，尚欠利息0元；\n计算方式：以50000元为基数，自2024年6月1日起按年利率13.8%计至实际清偿之日止\n是否请求支付至实际清偿之日止：是☑ 否□',
    '3.是否要求提前还款或解除合同': '否☑',
    '6.是否主张诉讼费用': '是☑',
    '1.合同签订情况（名称、编号、签订时间、地点等）': '2023年6月10日，安徽省涡阳县，双方约定借款50000元，未签订书面借款合同',
    '4.借款期限': '是否到期：是☑ 否□\n约定期限：2023年6月10日起至2024年6月1日止',
    '5.借款利率': '利率☑ 13.8%/年（合同条款：第 条）',
    '10.是否签订物的担保（抵押、质押）合同': '否☑',
    '11.担保人、担保物': '无'
  }
};

const STUB = `
window.__postCount = 0;
window.fetch = async (url, opts) => {
  window.__postCount++;
  const body = JSON.parse(opts.body);
  const userMsg = (body.messages[body.messages.length - 1] || {}).content || '';
  let content = 'AI 模拟回复：' + userMsg.slice(0, 40);
  if (userMsg.indexOf('单独输出一个 JSON 对象') >= 0) {
    content = '案由分析：' + ${JSON.stringify(CASE_TYPE)} + '\\n' + JSON.stringify(${JSON.stringify(analysis)});
  } else if (userMsg.indexOf('传统叙述式') >= 0 || userMsg.indexOf('生成一份完整的') >= 0) {
    content = '民事起诉状\\n\\n原告：${PL_NAME}，男，1980年1月1日出生，汉族，住安徽省涡阳县义门镇XX村，公民身份号码342124198001011234。\\n被告：${DF_NAME}，男，1979年2月2日出生，汉族，住安徽省涡阳县陈大镇YY村。\\n\\n诉讼请求：\\n一、判令被告偿还借款本金50000元；\\n二、判令被告支付利息；\\n三、本案诉讼费用由被告承担。\\n\\n事实与理由：\\n原告与被告系朋友关系，2023年6月10日被告向原告借款50000元，约定月息1分，2024年6月1日到期后未偿还。\\n\\n此致\\n涡阳县人民法院\\n\\n具状人：\\n年 月 日';
  }
  return {
    ok: true, status: 200,
    json: async () => ({ choices: [{ message: { role: 'assistant', content } }], usage: { prompt_tokens: 120, completion_tokens: 260 } })
  };
};
`;

async function getWsUrl() {
  for (let i = 0; i < 80; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`);
      const j = await r.json();
      const page = (j || []).find(t => t.type === 'page');
      if (page && page.webSocketDebuggerUrl) return page.webSocketDebuggerUrl;
    } catch (e) {}
    await sleep(250);
  }
  throw new Error('CDP 未就绪');
}

async function main() {
  const ws = new WebSocket(await getWsUrl());
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pend = new Map();
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) {
      const p = pend.get(m.id); pend.delete(m.id);
      m.error ? p.rej(new Error(m.error.message)) : p.res(m.result);
    }
  };
  const send = (method, params = {}) => new Promise((res, rej) => {
    const i = ++id; pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params }));
  });
  const ev = async expr => {
    const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) throw new Error('页面异常: ' + JSON.stringify(r.exceptionDetails).slice(0, 800));
    return r.result.value;
  };

  await send('Page.enable'); await send('Runtime.enable');
  await send('Page.addScriptToEvaluateOnNewDocument', { source: STUB });
  await send('Page.navigate', { url: PAGE });
  await sleep(2500);
  await ev(`state.keys.deepseek='sk-test'; state.keys.zhipu='sk-test'; state.keys.qwen='sk-test'; state.keys.custom='sk-test'; state.provider='zhipu'; saveState(); 'ok'`);
  await ev(`goTab('draft'); window.confirm = () => true; 'ok'`);
  await ev(`document.getElementById('draftMaterial').value='测试素材'; currentDraft.material='测试素材'; currentDraft.caseType=${JSON.stringify(CASE_TYPE)}; document.getElementById('caseTypeSel').value=${JSON.stringify(CASE_TYPE)}; onDraftCaseTypeChange(); 'ok'`);

  const waitIdle = async () => {
    let w = 0;
    while (w < 30000) { await sleep(200); w += 200; if (!(await ev('busy'))) break; }
  };

  await ev(`(async()=>{ try { await draftAnalyze(); } catch(e){ console.error(e); } })(); 'ok'`);
  await waitIdle();

  const formState = await ev(`JSON.stringify({
    formVisible: document.getElementById('draftElemForm').style.display !== 'none',
    pl: document.getElementById('elemPlName').value,
    plGender: document.getElementById('elemPlGender').value,
    plBirth: document.getElementById('elemPlBirth').value,
    plEthnic: document.getElementById('elemPlEthnic').value,
    plId: document.getElementById('elemPlId').value,
    plAddr: document.getElementById('elemPlAddr').value,
    plPhone: document.getElementById('elemPlPhone').value,
    df: document.getElementById('elemDfName').value,
    dfGender: document.getElementById('elemDfGender').value,
    dfBirth: document.getElementById('elemDfBirth').value,
    dfId: document.getElementById('elemDfId').value,
    dfAddr: document.getElementById('elemDfAddr').value,
    claims: document.getElementById('elemClaims').value,
    evidence: document.getElementById('elemEvidence').value,
    factFieldIds: Array.from(document.querySelectorAll('#elemFactFields input')).map(i => i.id + '=' + i.value),
    court: document.getElementById('elemCourt').value,
    missing: document.getElementById('elemMissing').innerText
  }, null, 1)`);
  console.log('=== 要素表单回填状态 ===');
  console.log(formState);

  await ev(`(async()=>{ try { await genDraftFromElemForm(); } catch(e){ console.error(e); } })(); 'ok'`);
  await waitIdle();

  const docs = await ev(`JSON.stringify((currentDraft.docs||[]).map(d=>({name:d.name, hasHtml:!!d.html, htmlLen:(d.html||'').length, textLen:(d.text||'').length})))`);
  console.log('=== 生成文书 ===');
  console.log(docs);

  const elemHtml = await ev(`(currentDraft.docs && currentDraft.docs[0] && currentDraft.docs[0].html) || ''`);
  const elemText = await ev(`(currentDraft.docs && currentDraft.docs[0] && currentDraft.docs[0].text) || ''`);
  const safe = CASE_TYPE.replace(/[\\/:*?"<>|]/g, '_') + '_' + PL_NAME + '_' + DF_NAME;
  fs.writeFileSync(path.join(OUTDIR, 'doc_elem_' + safe + '.html'), elemHtml, 'utf8');
  fs.writeFileSync(path.join(OUTDIR, 'doc_elem_' + safe + '.txt'), elemText, 'utf8');

  const audit = await ev(`(() => {
    const wrap = document.querySelector('#docBody .elem-official-wrap');
    if (!wrap) return JSON.stringify({error:'no official wrap'});
    const rows = Array.from(wrap.querySelectorAll('tr'));
    return JSON.stringify({
      rowCount: rows.length,
      tableWidthPx: Math.round(wrap.querySelector('table').getBoundingClientRect().width),
      colWidths: Array.from(wrap.querySelector('table').querySelectorAll('tr:not(.sec-full) td')).slice(0,4).map(td=>Math.round(td.getBoundingClientRect().width)),
      emptySections: rows.filter(tr => tr.querySelector('td[colspan]') && !tr.querySelector('td[colspan]').innerText.trim()).map(tr=>tr.innerText.slice(0,30)),
      emptyVals: rows.map(tr => {
        const lab = tr.querySelector('td.lab'), val = tr.querySelector('td.val');
        if (!lab) return null;
        return { lab: lab.innerText.replace(/\\n/g,'/').slice(0,28), valLen: val ? val.innerText.trim().length : -1 };
      }).filter(Boolean)
    }, null, 1);
  })()`);
  console.log('=== 渲染审计 ===');
  console.log(audit);

  await send('Emulation.setDeviceMetricsOverride', { width: 900, height: 1200, deviceScaleFactor: 1, mobile: false });
  await sleep(400);
  const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
  fs.writeFileSync(path.join(OUTDIR, 'preview_' + safe + '.png'), Buffer.from(shot.data, 'base64'));
  console.log('截图: out/preview_' + safe + '.png');

  // 导出两份 Word，供版式核验
  try {
    await send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: path.join(__dirname, 'downloads'), eventsEnabled: true });
  } catch (e) {}
  try {
    await ev(`exportBothDocs(); 'ok'`);
    await sleep(2500);
    const files = fs.existsSync(path.join(__dirname, 'downloads')) ? fs.readdirSync(path.join(__dirname, 'downloads')) : [];
    console.log('下载的 Word：' + files.join('、'));
  } catch (e) { console.log('导出 Word 失败：' + e.message); }

  ws.close();
}

main().then(() => { chrome.kill(); process.exit(0); })
  .catch(e => { console.error('ERR', e.message); chrome.kill(); process.exit(1); });
