"""对比修复前/后渲染结果：逐行判断是否已填写（相对官方空白模板）。"""
import re
import sys

sys.path.insert(0, __file__.rsplit('\\', 1)[0])
from compare_template import html_rows, norm  # noqa: E402


def filled_map(path):
    rows = html_rows(path)
    return {norm(l): (l, c) for l, c in rows if norm(l)}


def main():
    blank = filled_map(sys.argv[1])
    before = filled_map(sys.argv[2])
    after = filled_map(sys.argv[3])

    def filled(rows, key):
        if key not in rows:
            return None
        lab, val = rows[key]
        b = blank.get(key)
        bval = norm(b[1]) if b else ''
        v = norm(val)
        if not v:
            return False
        if bval and v == bval:
            return False          # 与空白模板一致 = 未填
        return True

    keys = [k for k in blank.keys()]
    only_before = only_after = both = neither = 0
    newly = []
    lost = []
    for k in keys:
        fb, fa = filled(before, k), filled(after, k)
        if fb is None and fa is None:
            continue
        if fa and not fb:
            only_after += 1
            newly.append(blank[k][0].replace('\n', ''))
        elif fb and not fa:
            only_before += 1
            lost.append(blank[k][0].replace('\n', ''))
        elif fb and fa:
            both += 1
        else:
            neither += 1

    total = len(keys)
    print('要素行总数 {0}'.format(total))
    print('修复前已填 {0} 行；修复后已填 {1} 行'.format(
        sum(1 for k in keys if filled(before, k)), sum(1 for k in keys if filled(after, k))))
    print('两侧都填 {0} 行；修复后新增填写 {1} 行；修复后丢失 {2} 行；仍未填 {3} 行'.format(
        both, only_after, only_before, neither))
    if newly:
        print('\n修复后新增填写的行：')
        for n in newly:
            print('  + ' + n)
    if lost:
        print('\n修复后不再填写的行（需检查）：')
        for n in lost:
            print('  - ' + n)


if __name__ == '__main__':
    main()
