/* 把官方要素式渲染片段包进导出用的 Word 外壳（复用已导出 .doc 的头部样式），生成可直接打开的 .doc */
const fs = require('fs');
const path = require('path');

const shellSrc = process.argv[2];   // 任一已导出的 .doc（含 wordHtmlShell 头部）
const innerSrc = process.argv[3];   // 要素式渲染片段 html
const outFile = process.argv[4];

const shell = fs.readFileSync(shellSrc, 'utf8');
const inner = fs.readFileSync(innerSrc, 'utf8');
const i = shell.indexOf('<body>');
const j = shell.lastIndexOf('</body>');
if (i < 0 || j < 0) { console.error('外壳文件缺少 body'); process.exit(1); }
const out = shell.slice(0, i + 6) + inner + shell.slice(j);
fs.writeFileSync(outFile, out, 'utf8');
console.log('已生成 ' + outFile + '（' + out.length + ' 字节）');
