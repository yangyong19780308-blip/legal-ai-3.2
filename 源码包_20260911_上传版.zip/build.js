// 构建法务AI 3.2 平台：合并 head/body/app，并嵌入 67 类案由
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const V = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'out');
const MD = 'C:/Users/Administrator/.codex/skills/standard-element-complaint/references/case-types-index.md';

const md = fs.readFileSync(MD, 'utf8');
const entries = [];
for (const line of md.split(/\r?\n/)) {
  const m = line.match(/^- \*\*(.+?)\*\*/);
  if (m) entries.push({ name: m[1].trim(), line });
}
const SKIP = new Set(['起诉状', '答辩状', '实例', '第三人意见陈述书', '申请书']);

function classify(name, line) {
  if (line.includes('行政起诉状')) return '行政起诉状';
  if (line.includes('刑事')) return '刑事自诉状';
  if (line.includes('国家赔偿')) return '国家赔偿申请书';
  if (line.includes('答辩状') && !line.includes('起诉状')) return '答辩状';
  if (line.includes('申请书') && !line.includes('起诉状')) return '执行/申请类申请书';
  return '民事起诉状';
}

const groups = new Map();
for (const e of entries) {
  if (SKIP.has(e.name)) continue;
  const g = classify(e.name, e.line);
  if (!groups.has(g)) groups.set(g, []);
  groups.get(g).push(e.name);
}
const caseTypes = [...groups.entries()].map(([g, items]) => ({ g, items }));

const head = fs.readFileSync(path.join(V, 'head.html'), 'utf8');
const body = fs.readFileSync(path.join(V, 'body.html'), 'utf8');
let app1 = fs.readFileSync(path.join(V, 'app1.js'), 'utf8');
const app2 = fs.readFileSync(path.join(V, 'app2.js'), 'utf8');
const official = fs.readFileSync(path.join(V, 'official_templates.js'), 'utf8');
const layouts = fs.readFileSync(path.join(V, 'official_layouts.js'), 'utf8');
const registry = fs.readFileSync(path.join(V, 'templates_registry.js'), 'utf8');
const app3 = fs.readFileSync(path.join(V, 'app3.js'), 'utf8');
const app4 = fs.readFileSync(path.join(V, 'app4.js'), 'utf8');
const migrate = fs.readFileSync(path.join(V, 'migrate.js'), 'utf8');

if (!app1.includes('/*__CASE_TYPES__*/[]')) throw new Error('未找到案由占位符');
app1 = app1.replace('/*__CASE_TYPES__*/[]', JSON.stringify(caseTypes));

const html = head + '\n' + body + '\n<script>\n' + app1 + '\n' + official + '\n' + layouts + '\n' + registry + '\n' + migrate + '\n' + app2 + '\n' + app3 + '\n' + app4 + '\n</script>\n</body>\n</html>\n';

fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'index.html'), html, 'utf8');
console.log('已生成:', path.join(OUT, 'index.html'), (Buffer.byteLength(html, 'utf8') / 1024).toFixed(0) + ' KB');
console.log('案由组:', caseTypes.map(x => x.g + '=' + x.items.length).join(', '));
